"""
Standalone Telegram Bot Server for MARK LIV JARVIS
Allows remote control and startup of JARVIS without the main application running.

This script runs independently and can:
1. Listen for Telegram commands
2. Start the main JARVIS application remotely
3. Provide basic status information
4. Enable remote communication before JARVIS is active
5. Handle voice messages with speech recognition
6. Provide text-to-speech responses

Usage: python telegram_standalone.py
"""
from __future__ import annotations

import json
import os
import sys
import time
import threading
import subprocess
import tempfile
import urllib.request
from pathlib import Path

# Add project root to path
def get_base_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR = get_base_dir()
CONFIG_FILE = BASE_DIR / "config" / "api_keys.json"

# Import the telegram_remote plugin functions
sys.path.insert(0, str(BASE_DIR))
try:
    from memory.config_manager import get_plugin_config, save_plugin_config
    _HAS_CONFIG = True
except ImportError:
    _HAS_CONFIG = False
    print("⚠️ Config manager not available. Running in limited mode.")
    
    def get_plugin_config(namespace):
        try:
            if CONFIG_FILE.exists():
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                return data.get("plugin_config", {}).get(namespace, {})
        except Exception:
            pass
        return {}
    
    def save_plugin_config(namespace, values):
        try:
            if CONFIG_FILE.exists():
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            else:
                data = {}
            pc = data.get("plugin_config", {})
            if not isinstance(pc, dict):
                pc = {}
            cur = pc.get(namespace, {})
            if not isinstance(cur, dict):
                cur = {}
            cur.update(values)
            pc[namespace] = cur
            data["plugin_config"] = pc
            CONFIG_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
        except Exception as e:
            print(f"Failed to save config: {e}")

# Telegram API
_TELEGRAM_API = "https://api.telegram.org/bot{token}/{method}"
_POLL_TIMEOUT = 20
_HTTP_TIMEOUT = 35

def get_http():
    try:
        import requests
        return requests
    except ImportError:
        print("❌ requests library not available. Install with: pip install requests")
        sys.exit(1)

def api_call(token: str, method: str, **kwargs):
    """Make a Telegram API call."""
    url = _TELEGRAM_API.format(token=token, method=method)
    kwargs.setdefault("timeout", 20)
    http = get_http()
    
    try:
        if "json" in kwargs or "data" in kwargs or "files" in kwargs:
            return http.post(url, **kwargs)
        elif "params" in kwargs:
            return http.get(url, params=kwargs["params"], timeout=kwargs["timeout"])
        else:
            return http.get(url, **kwargs)
    except Exception as e:
        print(f"API call error: {e}")
        return None

def send_message(token: str, chat_id: int, text: str):
    """Send a text message to a Telegram chat."""
    return api_call(
        token,
        "sendMessage",
        json={"chat_id": chat_id, "text": text}
    )

def download_voice_file(token: str, file_id: str) -> bytes | None:
    """Download a voice file from Telegram."""
    try:
        # Get file path
        response = api_call(token, "getFile", params={"file_id": file_id})
        if not response or not response.json().get("ok"):
            return None
        
        file_path = response.json().get("result", {}).get("file_path")
        if not file_path:
            return None
        
        # Download file
        download_url = f"https://api.telegram.org/file/bot{token}/{file_path}"
        
        with urllib.request.urlopen(download_url, timeout=30) as response:
            return response.read()
    except Exception as e:
        print(f"❌ Failed to download voice file: {e}")
        return None

def transcribe_voice(audio_data: bytes) -> str:
    """Transcribe voice audio to text using available speech recognition."""
    try:
        # Try using SpeechRecognition library
        import speech_recognition as sr
        
        # Create a temporary file
        with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as temp_file:
            temp_file.write(audio_data)
            temp_path = temp_file.name
        
        try:
            recognizer = sr.Recognizer()
            
            # Convert OGG to WAV if needed (SpeechRecognition works better with WAV)
            wav_path = temp_path.replace(".ogg", ".wav")
            try:
                import subprocess
                subprocess.run(
                    ["ffmpeg", "-i", temp_path, wav_path],
                    capture_output=True, timeout=10
                )
                audio_source = sr.AudioFile(wav_path)
            except Exception:
                # Fallback to direct OGG reading
                try:
                    audio_source = sr.AudioFile(temp_path)
                except Exception:
                    # If OGG fails, try reading as raw audio
                    print("⚠️ Audio format not supported, trying alternative...")
                    return ""
            
            with audio_source as source:
                audio = recognizer.record(source)
            
            # Try Google Speech Recognition (free, works well)
            try:
                text = recognizer.recognize_google(audio)
                return text
            except Exception as e:
                print(f"⚠️ Google recognition failed: {e}")
                # Fallback to Sphinx (offline) if available
                try:
                    text = recognizer.recognize_sphinx(audio)
                    return text
                except Exception:
                    return ""
        
        finally:
            # Clean up temporary files
            try:
                os.unlink(temp_path)
                if os.path.exists(wav_path):
                    os.unlink(wav_path)
            except Exception:
                pass
    
    except ImportError:
        print("⚠️ SpeechRecognition library not available. Install with: pip install SpeechRecognition")
        return ""
    except Exception as e:
        print(f"❌ Voice transcription failed: {e}")
        return ""

def text_to_speech(text: str, output_path: str) -> bool:
    """Convert text to speech and save as audio file."""
    try:
        # Try using pyttsx3 (offline, cross-platform)
        import pyttsx3
        
        engine = pyttsx3.init()
        
        # Set voice properties for better quality
        voices = engine.getProperty('voices')
        if voices:
            # Try to use a more natural voice if available
            for voice in voices:
                if 'english' in voice.name.lower() or 'en' in voice.languages:
                    engine.setProperty('voice', voice.id)
                    break
        
        engine.setProperty('rate', 150)    # Speed of speech
        engine.setProperty('volume', 0.9)  # Volume level
        
        engine.save_to_file(text, output_path)
        engine.runAndWait()
        return True
    
    except ImportError:
        print("⚠️ pyttsx3 library not available. Install with: pip install pyttsx3")
        return False
    except Exception as e:
        print(f"❌ Text-to-speech failed: {e}")
        return False

def send_voice_response(token: str, chat_id: int, text: str, cfg: dict):
    """Send a voice response to Telegram chat."""
    try:
        # Create temporary file for TTS output
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_file:
            temp_path = temp_file.name
        
        try:
            # Generate speech
            if text_to_speech(text, temp_path):
                # Read the audio file
                with open(temp_path, "rb") as f:
                    audio_data = f.read()
                
                # Send as voice message
                response = api_call(
                    token,
                    "sendVoice",
                    data={"chat_id": chat_id},
                    files={"voice": ("voice.mp3", audio_data, "audio/mpeg")}
                )
                
                if response and response.json().get("ok"):
                    print(f"✅ Voice response sent to chat {chat_id}")
                else:
                    print(f"⚠️ Failed to send voice response")
            else:
                print("⚠️ TTS generation failed, falling back to text")
        
        finally:
            # Clean up temporary file
            try:
                os.unlink(temp_path)
            except Exception:
                pass
    
    except Exception as e:
        print(f"❌ Voice response error: {e}")

def handle_voice_message(chat_id: int, voice_file_id: str, token: str, cfg: dict):
    """Handle incoming voice message from Telegram."""
    print(f"🎤 Voice message received from chat {chat_id}")
    
    # Download voice file
    audio_data = download_voice_file(token, voice_file_id)
    if not audio_data:
        send_message(token, chat_id, "❌ Failed to download voice message.")
        return
    
    # Transcribe to text
    text = transcribe_voice(audio_data)
    if not text:
        send_message(token, chat_id, "❌ Could not understand the voice message. Please try again or use text commands.")
        return
    
    print(f"📝 Transcribed: {text}")
    
    # Show what was understood
    send_message(token, chat_id, f"🎤 You said: \"{text}\"")
    
    # Process as command if it looks like one
    text_lower = text.lower()
    
    # Check for various command patterns
    if any(word in text_lower for word in ["start", "launch", "begin", "run", "turn on", "boot up"]):
        handle_command(chat_id, "start_jarvis", "", token, cfg)
    elif any(word in text_lower for word in ["stop", "end", "close", "shutdown", "turn off", "kill"]):
        handle_command(chat_id, "stop_jarvis", "", token, cfg)
    elif any(word in text_lower for word in ["status", "state", "running", "check", "how is it"]):
        handle_command(chat_id, "jarvis_status", "", token, cfg)
    elif any(word in text_lower for word in ["help", "what can you do", "commands", "capabilities"]):
        handle_command(chat_id, "help", "", token, cfg)
    else:
        # If JARVIS is running, inform user about full processing
        if is_jarvis_running():
            send_message(token, chat_id, f"🔄 Forwarding to JARVIS: \"{text}\"")
            send_message(token, chat_id, "⚠️ For full AI voice processing, use JARVIS directly. Standalone mode supports basic commands only.")
        else:
            send_message(token, chat_id, "⚠️ JARVIS is not running. Start it with /start_jarvis or say 'start JARVIS' for full voice control.")

def clean_token(token: str) -> str:
    """Extract and validate bot token."""
    if not token:
        return ""
    token = str(token).strip()
    if ":" not in token:
        return ""
    return token

def parse_chat_ids(ids_string: str) -> list[int]:
    """Parse comma-separated chat IDs."""
    if not ids_string:
        return []
    try:
        return [int(cid.strip()) for cid in str(ids_string).split(",") if cid.strip()]
    except Exception:
        return []

def is_jarvis_running():
    """Check if JARVIS main application is running."""
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq python.exe", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5
            )
            return "python.exe" in result.stdout.lower()
        else:
            result = subprocess.run(
                ["pgrep", "-f", "main.py"],
                capture_output=True, text=True, timeout=5
            )
            return result.returncode == 0
    except Exception:
        return False

def start_jarvis(jarvis_cmd: str = "python main.py"):
    """Start the JARVIS main application."""
    try:
        base_dir = BASE_DIR
        
        if sys.platform == "win32":
            import subprocess as _subprocess
            startupinfo = _subprocess.STARTUPINFO()
            startupinfo.dwFlags |= _subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = _subprocess.SW_HIDE
            
            subprocess.Popen(
                jarvis_cmd.split(),
                cwd=str(base_dir),
                creationflags=_subprocess.CREATE_NO_WINDOW,
                startupinfo=startupinfo
            )
        else:
            subprocess.Popen(
                jarvis_cmd.split(),
                cwd=str(base_dir),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
        
        print("✅ JARVIS startup command executed")
        return True
    except Exception as e:
        print(f"❌ Failed to start JARVIS: {e}")
        return False

def stop_jarvis():
    """Stop the JARVIS main application."""
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/F", "/IM", "python.exe"],
                capture_output=True, timeout=5
            )
        else:
            subprocess.run(
                ["pkill", "-f", "main.py"],
                capture_output=True, timeout=5
            )
        print("✅ JARVIS stop command executed")
        return True
    except Exception as e:
        print(f"❌ Failed to stop JARVIS: {e}")
        return False

def handle_command(chat_id: int, command: str, args: str, token: str, cfg: dict):
    """Handle incoming Telegram commands."""
    command = command.lower().strip()
    
    # Check authorization
    approved_ids = parse_chat_ids(cfg.get("allowed_chat_ids", ""))
    pairing_code = cfg.get("pairing_code", "").strip()
    
    # If not approved, check for pairing code
    if chat_id not in approved_ids:
        if command == "pair" and args:
            if args.strip() == pairing_code:
                # Approve this chat
                approved_ids.append(chat_id)
                save_plugin_config("telegram_remote", {
                    "allowed_chat_ids": ",".join(map(str, approved_ids))
                })
                send_message(token, chat_id, "✅ Phone successfully paired! You can now control JARVIS remotely.")
                print(f"✅ Chat {chat_id} paired successfully")
                return
            else:
                send_message(token, chat_id, "❌ Invalid pairing code. Please try again.")
                print(f"❌ Invalid pairing attempt from chat {chat_id}")
                return
        else:
            send_message(token, chat_id, "❌ Unauthorized. Send pairing code to pair your device.")
            print(f"❌ Unauthorized command from chat {chat_id}")
            return
    
    # Handle authorized commands
    if command == "start":
        jarvis_cmd = cfg.get("jarvis_command", "python main.py").strip()
        if start_jarvis(jarvis_cmd):
            response = "🚀 JARVIS is starting up remotely..."
            send_message(token, chat_id, response)
            # Add text-to-speech if enabled
            if cfg.get("voice_replies", False):
                send_voice_response(token, chat_id, response, cfg)
        else:
            send_message(token, chat_id, "❌ Failed to start JARVIS. Check logs for details.")
    
    elif command == "stop":
        if stop_jarvis():
            response = "🛑 JARVIS has been stopped."
            send_message(token, chat_id, response)
            if cfg.get("voice_replies", False):
                send_voice_response(token, chat_id, response, cfg)
        else:
            send_message(token, chat_id, "❌ Failed to stop JARVIS.")
    
    elif command == "status":
        running = is_jarvis_running()
        status = "🟢 RUNNING" if running else "🔴 STOPPED"
        response = f"📊 JARVIS Status: {status}"
        send_message(token, chat_id, response)
        if cfg.get("voice_replies", False):
            send_voice_response(token, chat_id, response, cfg)
    
    elif command == "help":
        help_text = """
🤖 JARVIS Standalone Bot Commands:

/start_jarvis - Start JARVIS application
/stop_jarvis - Stop JARVIS application  
/jarvis_status - Check if JARVIS is running
/help - Show this help message

Voice Support:
🎤 Send voice messages for voice commands
🔊 Enable voice replies in settings

Note: Full JARVIS features available when main application is running.
"""
        send_message(token, chat_id, help_text)
    
    else:
        send_message(token, chat_id, f"❓ Unknown command: {command}. Use /help for available commands.")

def process_updates(token: str, cfg: dict):
    """Process incoming Telegram updates."""
    offset = 0
    
    while True:
        try:
            response = api_call(
                token,
                "getUpdates",
                params={"timeout": _POLL_TIMEOUT, "offset": offset}
            )
            
            if response is None:
                time.sleep(5)
                continue
            
            data = response.json()
            
            if not data.get("ok"):
                print(f"⚠️ Telegram API error: {data.get('description')}")
                time.sleep(5)
                continue
            
            updates = data.get("result", [])
            
            for update in updates:
                offset = update.get("update_id", offset) + 1
                
                message = update.get("message")
                if not message:
                    continue
                
                chat = message.get("chat", {})
                chat_id = chat.get("id")
                
                if not chat_id:
                    continue
                
                # Handle voice messages
                voice = message.get("voice")
                if voice:
                    voice_file_id = voice.get("file_id")
                    if voice_file_id:
                        handle_voice_message(chat_id, voice_file_id, token, cfg)
                    continue
                
                # Handle text messages
                text = message.get("text", "")
                if not text:
                    continue
                
                # Parse command
                if text.startswith("/"):
                    parts = text.split(maxsplit=1)
                    command = parts[0][1:]  # Remove /
                    args = parts[1] if len(parts) > 1 else ""
                    handle_command(chat_id, command, args, token, cfg)
                else:
                    # Handle plain text as potential command
                    text_lower = text.lower()
                    if any(word in text_lower for word in ["start", "launch", "begin", "run"]):
                        handle_command(chat_id, "start_jarvis", "", token, cfg)
                    elif any(word in text_lower for word in ["stop", "end", "close", "shutdown"]):
                        handle_command(chat_id, "stop_jarvis", "", token, cfg)
                    elif any(word in text_lower for word in ["status", "state", "running", "check"]):
                        handle_command(chat_id, "jarvis_status", "", token, cfg)
                    elif any(word in text_lower for word in ["help", "what can you do", "commands"]):
                        handle_command(chat_id, "help", "", token, cfg)
                    else:
                        send_message(token, chat_id, f"📝 Received: \"{text}\". Use /help for commands or start JARVIS for full AI processing.")
        
        except KeyboardInterrupt:
            print("\n👋 Shutting down standalone bot...")
            break
        except Exception as e:
            print(f"⚠️ Error processing updates: {e}")
            time.sleep(5)

def main():
    """Main entry point for standalone Telegram bot."""
    print("🤖 JARVIS Standalone Telegram Bot")
    print("=" * 40)
    
    # Load configuration
    cfg = get_plugin_config("telegram_remote")
    token = clean_token(cfg.get("bot_token", ""))
    
    if not token:
        print("❌ No bot token configured.")
        print("Please set up your Telegram bot in the main JARVIS application first:")
        print("1. Start JARVIS normally")
        print("2. Go to Settings → TELEGRAM REMOTE")
        print("3. Configure your bot token and pairing code")
        print("4. Enable standalone mode")
        sys.exit(1)
    
    # Test connection
    print("🔗 Testing Telegram connection...")
    test_response = api_call(token, "getMe")
    if test_response and test_response.json().get("ok"):
        bot_info = test_response.json().get("result", {})
        bot_name = bot_info.get("username", "unknown")
        print(f"✅ Connected as @{bot_name}")
    else:
        print("❌ Failed to connect to Telegram. Check your bot token.")
        sys.exit(1)
    
    # Check standalone mode
    if not cfg.get("standalone_mode", False):
        print("⚠️ Standalone mode is not enabled in settings.")
        print("Enable it in Settings → TELEGRAM REMOTE → standalone_mode")
        print("Starting anyway in limited mode...")
    
    # Show pairing status
    approved_ids = parse_chat_ids(cfg.get("allowed_chat_ids", ""))
    pairing_code = cfg.get("pairing_code", "").strip()
    voice_enabled = cfg.get("voice_replies", False)
    
    if approved_ids:
        print(f"✅ {len(approved_ids)} approved chat(s)")
    else:
        print("⚠️ No approved chats. Pairing code required.")
        if pairing_code:
            print(f"🔑 Pairing code is set. Send it to the bot to pair your device.")
        else:
            print("❌ No pairing code set. Configure in main JARVIS application.")
    
    if voice_enabled:
        print("🔊 Voice replies enabled")
    else:
        print("🔇 Voice replies disabled (enable in settings)")
    
    print("\n🎯 Bot is now listening for commands...")
    print("Available commands: /start_jarvis, /stop_jarvis, /jarvis_status, /help")
    print("Voice support: Send voice messages for voice commands")
    print("Press Ctrl+C to stop\n")
    
    # Start processing updates
    try:
        process_updates(token, cfg)
    except KeyboardInterrupt:
        print("\n👋 Bot stopped.")

if __name__ == "__main__":
    main()
    
    # Start processing updates
    try:
        process_updates(token, cfg)
    except KeyboardInterrupt:
        print("\n👋 Bot stopped.")

if __name__ == "__main__":
    main()
    
    # Start processing updates
    try:
        process_updates(token, cfg)
    except KeyboardInterrupt:
        print("\n👋 Bot stopped.")

if __name__ == "__main__":
    main()