"""Wake-on-LAN — wake a machine on your own network by its MAC address.

"wake my pc aa-bb-cc-dd-ee-ff" → one broadcast magic packet. Only works for
devices on the local network that were previously put to sleep with Wake-on-LAN
enabled — physics, not me, sets that limit, and the reply says so if the
target never shows up.
"""
from __future__ import annotations

import re
import socket

_MAC_RE = re.compile(r"^([0-9a-fA-F]{2}[:\-]){5}[0-9a-fA-F]{2}$")


def _packet(mac: str) -> bytes:
    hexs = mac.replace(":", "").replace("-", "")
    return b"\xff" * 6 + bytes.fromhex(hexs) * 16


def run(parameters: dict, **_ctx) -> str:
    mac = (parameters.get("mac") or "").strip()
    if not _MAC_RE.match(mac):
        return ("Give me the machine's MAC address, sir — six pairs like "
                "aa-bb-cc-dd-ee-ff. It is on the label of the machine, or "
                "the 'wake on lan' entry in its BIOS.")
    try:
        pkt = _packet(mac)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.sendto(pkt, ("<broadcast>", 9))
        return ("Wake packet sent. If the machine was sleeping with "
                "wake-on-LAN enabled, it will be up in a few seconds.")
    except Exception as e:
        return f"Wake packet could not be sent: {e}"


TOOL = {
    "name": "wake_on_lan",
    "description": (
        "Send a Wake-on-LAN magic packet to a MAC address on the local "
        "network: 'wake my pc aa:bb:cc:dd:ee:ff'. Wakes sleeping machines "
        "with WoL enabled; local network only."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mac": {"type": "STRING",
                    "description": "Target MAC, e.g. aa:bb:cc:dd:ee:ff"},
        },
        "required": ["mac"],
    },
    "handler": run,
}
