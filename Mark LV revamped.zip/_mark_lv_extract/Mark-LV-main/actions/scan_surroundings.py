"""Scan the surroundings and REPORT what is nearby — out loud, anonymised.

The companion to the RADAR SCAN dock: where the dock draws the room, this
tells the room in plain English JARVIS can speak. Both read from the same
privacy gate in core.surroundings — SSIDs, IP and MAC addresses never leave
the scan layer, so the report can describe what's around without ever naming
it. Networks are "NET-2 at 62 percent", hosts are "HOST-3"; your own network
is identified only as "your own network".
"""

from __future__ import annotations


def run(parameters: dict, player=None, session_memory=None) -> str:
    try:
        from core.surroundings import get_surroundings
        snap = get_surroundings(wait=True, fresh=True)
    except Exception as e:
        return f"Surroundings scan is unavailable right now: {e}"

    wifi = snap.get("wifi", [])
    lan  = snap.get("lan", [])
    age  = snap.get("age", -1)
    err  = snap.get("err", "")

    if not wifi and not lan:
        return ("I can see nothing around me at the moment, sir — no wireless "
                "networks in range and no local hosts responding. The probes "
                "on this platform may also be restricted.")

    # Strongest first, then describe in operator's English.
    wifi = sorted(wifi, key=lambda b: -b.get("signal", 0))
    parts = []

    n_ours = sum(1 for b in wifi if b.get("ours"))
    others = len(wifi) - n_ours
    if n_ours:
        parts.append(f"your own network is broadcasting, holding a strong "
                     f"{wifi[0]['signal']} percent signal" if n_ours == 1 else
                     f"{n_ours} of the networks in range are ours")
    if others:
        strongest = next((b for b in wifi if not b.get("ours")), None)
        desc = (f"the strongest outside signal is {strongest['name']} at "
                f"{strongest['signal']} percent" if strongest and strongest.get("signal")
                else "")
        parts.append(f"{others} other network{'s are' if others != 1 else ' is'} "
                     f"in range{', ' + desc if desc else ''}")

    if lan:
        parts.append(f"{len(lan)} device{'s are' if len(lan) != 1 else ' is'} "
                     f"active on the local network")

    fresh = "" if age < 0 or age > 20 else " — the picture is only seconds old"
    report = "Around me: " + "; ".join(parts) + fresh + "."

    if err:
        report += f" (One probe is limited on this machine: {err}.)"

    if player and hasattr(player, "show_content"):
        try:
            rows = [f"  {b['name']:<8} {b.get('signal', 0):>3}%  "
                    f"{'YOUR NETWORK' if b.get('ours') else 'network'}"
                    for b in wifi[:10]]
            rows += [f"  {h['name']:<8} local host" for h in lan[:8]]
            player.show_content("RADAR SCAN — SURROUNDINGS",
                                "SURROUNDINGS REPORT (anonymised)\n"
                                + "\n".join(rows))
        except Exception:
            pass

    # The explicit scan also lands in the activity log, like the automatic
    # sweeps do.
    if player and hasattr(player, "write_log"):
        try:
            bits = [f"{b['name']} {b.get('signal', 0)}%"
                    f"{' YOURS' if b.get('ours') else ''}" for b in wifi[:4]]
            if lan:
                bits.append(f"{len(lan)} local hosts")
            player.write_log("RADAR: manual scan — " + " · ".join(bits))
        except Exception:
            pass

    return report


TOOL = {
    "name": "scan_surroundings",
    "description": (
        "Scans the machine's surroundings and reports what is nearby: how many "
        "Wi-Fi networks are in range and how strong, whether your own network is "
        "up, and how many devices are on the local network. Fully anonymised — "
        "never reveals network names, IP or MAC addresses. Use when the user asks "
        "to 'scan the area', 'scan your surroundings', 'what's around you', "
        "'run the radar' or similar."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {},
        "required": [],
    },
    "handler": run,
}
