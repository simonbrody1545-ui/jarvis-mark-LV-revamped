"""Insane mode — the deep threat scan of THIS machine, behind a real gate.

Two locks, exactly as specified:

1. INTENTION-ONLY DETECTION. "He was in insane mode", "what does insane mode
   do", "remember insane mode?" — mentions inside a sentence NEVER trigger.
   Only the command itself ("start insane mode", "insane mode") engages the
   gate. Detection logic mirrors core.modes: the mode words are stripped from
   the utterance and whatever remains must be essentially empty, with
   negations and questions rejected outright.

2. THE CONFIRMATION GATE. Even a genuine command does not scan immediately —
   a banner goes on screen: "Are you sure?" + exactly what the scan does and
   what it produces. The user presses CONFIRM (or says yes) to run it, or
   declines. The token comes from the interface (core.confirm), never from
   the model.

The scan itself reads ONLY this machine: processes, ports, persistence,
hosts file, network devices → Word report in Downloads.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
_HIDDEN  = BASE_DIR / ".iam_secure"
if str(_HIDDEN) not in sys.path:
    sys.path.insert(0, str(_HIDDEN))

# ── intention-only detection ────────────────────────────────────────────────
# Command = the utterance is (essentially) JUST the command. A sentence that
# merely CONTAINS "insane mode" is a mention and never fires.

_LEAD = re.compile(
    r"^(?:hey\s+\w+[,]?\s+)?(?:please\s+)?"
    r"(?:start|begin|enter|engage|activate|enable|run|go\s+into|go|kick\s+off|"
    r"launch|initiate|turn\s+on|switch\s+to)\s+"
    r"(?:the\s+)?(?:insane(?:\s+mode)?)$",
    re.I)
_BARE = re.compile(r"^(?:the\s+)?insane(?:\s+mode)?[!.]?$", re.I)

# A mention marker anywhere → this is a sentence ABOUT insane mode, not a
# command FOR insane mode.
_MENTION = re.compile(
    r"\b(what|whats|what's|how|why|when|who|did|does|do|is|was|were|he|she|they|"
    r"remember|remembers|remind|thinks?|thought|said|says|told|mean|means|meant|"
    r"about|yesterday|earlier|later|before|after|if|maybe|explain|tell|difference|"
    r"know|knew|used)\b",
    re.I)
_NEGATION = re.compile(
    r"\b(don'?t|do\s+not|never|no\s+need|without|stop|forget|except|"
    r"instead\s+of|rather\s+than|cancel)\b", re.I)
# An explicit OFF cue is a stand-down, never an engagement.
_OFF = re.compile(r"\b(off|disable|exit|leave|out\s+of|end|deactivate)\b", re.I)


def is_insane_command(text: str) -> bool:
    """True ONLY when the whole utterance is the insane-mode command itself."""
    if not text:
        return False
    t = text.strip()
    if len(t) > 40:                     # a real command is short
        return False
    if _NEGATION.search(t) or _MENTION.search(t) or _OFF.search(t):
        return False
    if _BARE.match(t) or _LEAD.match(t):
        return True
    # "start insane mode" with a stray trailing word like "now"/"please"
    t2 = re.sub(r"\b(now|please|sir|jarvis)\b", "", t, flags=re.I)
    t2 = re.sub(r"\s+", " ", t2).strip(" !.,?")
    return bool(_LEAD.match(t2) or _BARE.match(t2))


# ── the scan (unchanged behaviour — own machine only) ───────────────────────

_OUTCOME = (
    "INSANE MODE — deep threat scan of THIS computer.\n"
    "It will: scan every running process for scamware / keylogger / miner "
    "signatures; list all listening ports and the programs behind them; "
    "collect every auto-start persistence entry; check the hosts file for "
    "hijacks; fingerprint devices on your network (type only, nothing "
    "personal).\n"
    "Outcome: a threat report (Word file) saved to Downloads with anything "
    "flagged for review. Read-only — it changes nothing and touches no other "
    "device or account.")


def _do_scan() -> str:
    from insane_scan import run_full_scan, write_threat_report
    findings = run_full_scan()
    out = write_threat_report(findings)
    try:
        import subprocess
        subprocess.Popen(["explorer", f"/select,{out}"])
    except Exception:
        pass
    flagged = len(findings.get("processes", []))
    hosts_n = len(findings.get("hosts", []))
    pers_n  = len(findings.get("persistence", []))
    dev_n   = len(findings.get("devices", []))
    return (f"Insane scan complete, sir. Report saved to Downloads: {out.name} "
            f"— flagged processes: {flagged}, hosts-file overrides: {hosts_n}, "
            f"auto-start entries: {pers_n}, network devices: {dev_n}. "
            f"Flagged is not infected — verify before acting.")


def run(parameters: dict = None, response=None, player=None, **_) -> str:
    """Tool entry. Even when called directly, the scan only runs after the
    on-screen CONFIRM — the model can never pre-approve it."""
    try:
        from core import confirm as confirm_gate
    except Exception:
        return "Confirmation gate unavailable — scan refused."

    outcome_short = (
        "WHAT IT DOES: scans every running process for scamware / keylogger / "
        "miner signatures; lists all listening ports and the programs behind "
        "them; collects every auto-start entry; checks the hosts file for "
        "hijacks; fingerprints devices on your network (type only, nothing "
        "personal).\n\n"
        "OUTCOME: a threat report (Word file) saved to Downloads with anything "
        "flagged for review. Read-only — it changes nothing, and it never "
        "touches any other device or account.")
    return confirm_gate.request(
        key="insane_mode_scan",
        title="INSANE MODE — are you sure?",
        detail=f"{outcome_short}\n\nPress CONFIRM to run it now, or CANCEL to decline.",
        run=_do_scan,
    )


TOOL = {
    "name": "insane_mode",
    "description": (
        "INSANE MODE — deep threat scan of THIS computer only. Call ONLY when "
        "the user's whole utterance is the command itself ('start insane mode', "
        "'insane mode'). A mention inside a longer sentence ('he was in insane "
        "mode', 'what is insane mode') must NEVER call this. The scan asks the "
        "user on-screen: are you sure? — with the full outcome listed — and "
        "runs only if they CONFIRM. It reads this machine (processes, ports, "
        "persistence, hosts, network devices) and writes a Word report to "
        "Downloads. It never touches other devices, accounts or people."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "confirm": {"type": "STRING",
                        "description": "ignored — the on-screen gate decides"},
        },
        "required": [],
    },
    "handler": run,
}
