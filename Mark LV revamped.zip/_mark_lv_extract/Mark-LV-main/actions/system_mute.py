"""Mute — JARVIS silences itself, and the whole machine if told.

"mute yourself"  → mic off (same path as the UI mute button; the HUD shows it).
"unmute"         → back.
"mute the pc / system / everything" → the Windows master volume is muted too
    (and restored on "unmute everything"). Uses the Core Audio endpoint
    interface via ctypes.pycaw when available; falls back to nircmd if the
    user has it; otherwise says so honestly instead of pretending.
"""
from __future__ import annotations

import platform

_TOOL = "system_mute"

_OS = platform.system()


def _win_set_system_mute(mute: bool) -> bool:
    """Master endpoint mute via pycaw (COM). Returns False if unavailable."""
    try:
        from pycaw.pycaw import AudioUtilities
        dev = AudioUtilities.GetSpeakers()
        # Newer pycaw wraps the endpoint: AudioDevice.EndpointVolume is the
        # ready IAudioEndpointVolume. Older builds expose .Activate — try both.
        vol = getattr(dev, "EndpointVolume", None)
        if vol is not None:
            vol.SetMute(bool(mute), None)
            return True
        from ctypes import POINTER, cast
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import IAudioEndpointVolume
        interface = dev._dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        vol = cast(interface, POINTER(IAudioEndpointVolume))
        vol.SetMute(bool(mute), None)
        return True
    except Exception:
        pass
    # nircmd fallback (some machines have it on PATH)
    try:
        import subprocess
        subprocess.Popen(["nircmd", "mutesysvolume", "1" if mute else "0"],
                         creationflags=0x08000000)   # CREATE_NO_WINDOW
        return True
    except Exception:
        return False


def run(parameters: dict = None, response=None, player=None,
        set_muted=None, **_) -> str:
    """`set_muted` is injected by main.py — the same callable the UI mute
    button drives, so HUD state, log and the audio gate all stay in sync."""
    params = parameters or {}
    action = (params.get("action") or "").lower().strip()
    scope  = (params.get("scope") or "").lower().strip()

    system = scope in ("system", "pc", "windows", "everything", "all", "computer")

    if action in ("unmute", "off", "restore"):
        if system:
            if _OS != "Windows":
                return "System volume control is Windows-only right now, sir."
            ok = _win_set_system_mute(False)
            return ("System volume restored — you're live again, sir."
                    if ok else
                    "I couldn't reach the system volume (needs pycaw: pip "
                    "install pycaw). The mic side is unmuted though.")
        if set_muted is not None:
            set_muted(False)
        return "Microphone live again — I can hear you, sir."

    # default action: mute
    if system:
        if _OS != "Windows":
            return "System volume control is Windows-only right now, sir."
        if set_muted is not None:
            set_muted(True)          # quiet ourselves too — total silence
        ok = _win_set_system_mute(True)
        return ("Going dark, sir — my mic and the entire system volume are "
                "muted. Say 'unmute everything' when you want sound back."
                if ok else
                "My mic is muted, but the system volume needs pycaw "
                "(pip install pycaw) for me to reach it, sir.")
    else:
        if set_muted is not None:
            set_muted(True)
        return ("Muted, sir. I'm not listening — say 'unmute' when you need me.")


TOOL = {
    "name": "system_mute",
    "description": (
        "Mute or unmute. 'Mute yourself' / 'mute' silences JARVIS's microphone "
        "(HUD shows muted). 'Mute the pc' / 'mute the system' / 'mute everything' "
        "ALSO mutes the Windows master volume. 'Unmute' reverses the mic; "
        "'unmute everything' reverses both. Only call when the user asks to "
        "mute — not for stopping a reply (that's interrupt)."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING",
                       "description": "mute (default) | unmute"},
            "scope":  {"type": "STRING",
                       "description": "self (default) | system | everything — "
                                      "system mutes Windows master volume too"},
        },
        "required": [],
    },
    "handler": run,
}
