"""
Health Advisor — the medical bay display.

When the user mentions a symptom, an illness, a medicine, or asks how to get
cured, JARVIS calls this tool with its medical analysis and the tool renders it
as a full holographic diagnostic — animated human figure with the affliction
pulsing, live EKG, recovery ring, and staged slide-in panels:

  WHAT YOU NEED      — supplies/ingredients, exactly like a crafting list
  REMEDIES           — each with type, how to use, and its own side effects
  SIDE EFFECTS       — aggregated warnings (amber)
  RISKS IF UNTREATED — what can happen to you (red)
  SEE A DOCTOR IF    — escalation banner (red)

The style matches the boot sequence (canvas particles, scanlines, typed
headers, staggered panel reveals) so it feels like the same machine opened a
new bay. Works for real and fictional conditions alike — the display does not
care whether the ailment exists.

MEDICAL-GRADE HONESTY: the page carries a permanent education-only disclaimer;
it is a display layer, the judgement is JARVIS's.
"""
from __future__ import annotations

import html
import json
import time
from pathlib import Path

import webbrowser

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR  = BASE_DIR / "state" / "health"

_TYPE_ICON = {
    "medicine": "💊", "home": "🏠", "food": "🍎", "habit": "🔁",
    "tool": "🔧", "fictional": "✦",
}
_TYPE_COL = {
    "medicine": "#ff6a3d", "home": "#37ffb5", "food": "#ffd23d",
    "habit": "#37d6ff", "tool": "#9a7bff", "fictional": "#ff5ad6",
}
_SEV_COL = {"mild": "#37ffb5", "moderate": "#ffd23d", "serious": "#ff3d5a"}
_SEV_LABEL = {"mild": "LOW THREAT", "moderate": "ELEVATED", "serious": "HIGH ALERT"}


def _esc(s) -> str:
    return html.escape(str(s or ""), quote=True)


def build_html(data: dict) -> str:
    """Render the analysis dict into the holographic HTML page."""
    data = data or {}
    condition = _esc(data.get("condition") or "UNSPECIFIED AILMENT")
    severity  = str(data.get("severity") or "mild").lower()
    sev_col   = _SEV_COL.get(severity, _SEV_COL["moderate"])
    sev_fill  = {"mild": "rgba(55,255,181,.22)", "moderate": "rgba(255,210,61,.22)",
                 "serious": "rgba(255,61,90,.25)", "fictional": "rgba(255,90,214,.22)"}.get(
                     severity, "rgba(255,210,61,.22)")
    sev_label = _SEV_LABEL.get(severity, severity.upper())
    summary   = _esc(data.get("summary") or "")
    recovery  = _esc(data.get("recovery_days") or "—")
    body_part = _esc(data.get("body_part") or "systemic")

    supplies = [str(s) for s in (data.get("supplies") or [])][:10]
    remedies = list(data.get("remedies") or [])[:8]
    risks    = [str(r) for r in (data.get("risks_if_untreated") or [])][:8]
    doctor   = [str(d) for d in (data.get("see_doctor_if") or [])][:8]

    # ---- panel payloads (JSON for JS animation + static <noscript>-safe lists)
    remedies_js = json.dumps(remedies, ensure_ascii=False)
    supplies_js = json.dumps(supplies, ensure_ascii=False)
    risks_html  = "".join(
        f'<div class="row risk"><span class="mark">▸</span><span>{_esc(r)}</span></div>'
        for r in risks) or '<div class="row risk"><span class="mark">▸</span><span>None identified</span></div>'
    doctor_html = "".join(
        f'<div class="row doc"><span class="mark">▸</span><span>{_esc(d)}</span></div>'
        for d in doctor) or '<div class="row doc"><span class="mark">▸</span><span>Seek care if symptoms worry you</span></div>'
    supply_items = "".join(
        f'<div class="supply"><span class="tick">◇</span><span>{_esc(s)}</span></div>'
        for s in supplies)

    ts = time.strftime("%d %b %Y · %H:%M")
    stamp = _esc(f"SCAN {ts}")

    # The template is a plain string with __TOKENS__ — no f-string, so CSS/JS
    # braces never need doubling (the exact trap the old startup died in).
    return _TEMPLATE \
        .replace("__PAYLOAD__", json.dumps({
            "condition": str(data.get("condition") or "UNSPECIFIED AILMENT"),
            "severity": severity,
            "bodyPart": str(data.get("body_part") or "systemic"),
            "remedies": remedies,
            "supplies": supplies,
        }, ensure_ascii=False).replace("</", "<\\/")) \
        .replace("__CONDITION__", condition) \
        .replace("__SEVCOL__", sev_col) \
        .replace("__SEVFILL__", sev_fill) \
        .replace("__SEVLABEL__", _esc(sev_label)) \
        .replace("__SUMMARY__", summary) \
        .replace("__RECOVERY__", recovery) \
        .replace("__BODYPART__", body_part.upper()) \
        .replace("__RISKS__", risks_html) \
        .replace("__DOCTOR__", doctor_html) \
        .replace("__SUPPLIES__", supply_items) \
        .replace("__REMEDIES_JS__", remedies_js.replace("</", "<\\/")) \
        .replace("__SUPPLIES_JS__", supplies_js.replace("</", "<\\/")) \
        .replace("__STAMP__", stamp)


def handler(condition: str, severity: str = "moderate", summary: str = "",
            body_part: str = "systemic", recovery_days: str = "—",
            supplies: list | None = None, remedies: list | None = None,
            risks_if_untreated: list | None = None,
            see_doctor_if: list | None = None, **_) -> str:
    try:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        slug = "".join(c if c.isalnum() else "_" for c in condition.lower())[:48] or "scan"
        path = OUT_DIR / f"health_{slug}_{int(time.time())}.html"
        path.write_text(build_html({
            "condition": condition, "severity": severity, "summary": summary,
            "body_part": body_part, "recovery_days": recovery_days,
            "supplies": supplies or [], "remedies": remedies or [],
            "risks_if_untreated": risks_if_untreated or [],
            "see_doctor_if": see_doctor_if or [],
        }), encoding="utf-8")
        from core.opera import open_path
        open_path(f"file:///{path.as_posix()}")
        n_r = len(remedies or [])
        n_s = len(supplies or [])
        return (f"Holographic health diagnostic for '{condition}' is on screen — "
                f"{n_r} remedy(ies), {n_s} required item(s), side effects and "
                f"risks-if-untreated listed. Severity shown: {severity}.")
    except Exception as e:
        return f"Health display failed to open: {e}"


TOOL = {
    "name": "health_advisor",
    "description": (
        "Opens a full holographic MEDICAL DIAGNOSTIC display. Use whenever the "
        "user mentions feeling ill, a symptom, an injury, a disease (real OR "
        "fictional), asks 'what should I take for X', 'how do I cure X', or "
        "asks about a medicine's effects. Fill it from your own knowledge; the "
        "tool renders it cinematically with a what-you-need list, remedies "
        "each with side effects, and risks if untreated. Always include "
        "see_doctor_if warning signs. Fictional ailments are fine — mark "
        "severity 'fictional' and say so in the summary."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "condition":  {"type": "STRING", "description": "Name of the ailment, e.g. 'Common cold', 'Migraine', 'X-code virus'"},
            "severity":   {"type": "STRING", "description": "mild | moderate | serious | fictional"},
            "summary":    {"type": "STRING", "description": "One-sentence diagnosis summary shown under the title"},
            "body_part":  {"type": "STRING", "description": "Affected area, e.g. head, throat, stomach, arm, systemic"},
            "recovery_days": {"type": "STRING", "description": "Expected recovery time, e.g. '3–7 days'"},
            "supplies":   {"type": "ARRAY", "items": {"type": "STRING"},
                           "description": "WHAT YOU NEED list: medicines, ingredients, tools (e.g. ginger, honey, thermometer, bacta spray)"},
            "remedies":   {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
                                "name": {"type": "STRING"},
                                "type": {"type": "STRING", "description": "medicine | home | food | habit | tool | fictional"},
                                "how":  {"type": "STRING", "description": "How to use / dosage / application"},
                                "side_effects": {"type": "ARRAY", "items": {"type": "STRING"}}}},
                           "description": "Treatment options — each with its own side effects"},
            "risks_if_untreated": {"type": "ARRAY", "items": {"type": "STRING"},
                                   "description": "What can happen if it is not treated"},
            "see_doctor_if": {"type": "ARRAY", "items": {"type": "STRING"},
                              "description": "Red-flag symptoms that need real medical care"},
        },
        "required": ["condition", "remedies"],
    },
    "handler": handler,
}


# ═════════════════════════════════════════════════════════════════════════════
# The display. Plain-string template (tokens, no f-strings). Choreography:
# header types in → figure wireframe sweeps on → EKG starts → panels slide in
# one by one → remedy cards pop with their side-effect chips.
# ═════════════════════════════════════════════════════════════════════════════
_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>MEDICAL BAY · __CONDITION__</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  html,body { height:100%; }
  body {
    background:#00070c; color:#aef4ff; overflow:hidden;
    font-family:"Consolas","Cascadia Mono",monospace;
  }
  #stars { position:fixed; inset:0; z-index:0; }
  .vignette { position:fixed; inset:0; z-index:6; pointer-events:none;
    background:radial-gradient(ellipse at center, transparent 55%, rgba(0,4,8,.78) 100%); }
  .scanlines { position:fixed; inset:0; z-index:6; pointer-events:none; opacity:.5;
    background:repeating-linear-gradient(0deg, rgba(0,229,255,.028) 0 1px, transparent 1px 3px); }
  .sweep { position:fixed; left:0; right:0; height:120px; z-index:6; pointer-events:none;
    background:linear-gradient(180deg, transparent, rgba(0,212,255,.05), transparent);
    animation:sweep 7s linear infinite; }
  @keyframes sweep { from { top:-140px; } to { top:100%; } }

  .bay { position:relative; z-index:2; height:100%; display:flex; flex-direction:column; padding:22px 28px 46px; }

  /* ── header ── */
  header { display:flex; justify-content:space-between; align-items:flex-start; gap:16px;
    border-bottom:1px solid rgba(0,212,255,.28); padding-bottom:12px; }
  .h-left .kicker { font-size:11px; letter-spacing:.35em; color:#5fd6e8; opacity:0; animation:fadeUp .5s .1s forwards; }
  .h-left h1 { font-size:clamp(20px,3.2vw,34px); letter-spacing:.14em; color:#00e5ff; margin-top:6px;
    text-shadow:0 0 18px rgba(0,212,255,.55); white-space:nowrap; }
  .h-left h1 .cursor { display:inline-block; width:.6em; animation:blink 1s steps(1) infinite; }
  @keyframes blink { 50% { opacity:0; } }
  .h-right { text-align:right; font-size:11px; line-height:1.75; color:#4cc3d6; letter-spacing:.12em;
    opacity:0; animation:fadeUp .5s .35s forwards; }
  .sev { display:inline-block; padding:3px 12px; border:1px solid __SEVCOL__; color:__SEVCOL__;
    letter-spacing:.28em; font-size:11px; margin-top:6px;
    text-shadow:0 0 12px __SEVCOL__; box-shadow:0 0 14px rgba(0,212,255,.12), inset 0 0 14px rgba(0,212,255,.06);
    animation:pulseSev 2.2s ease-in-out infinite; }
  @keyframes pulseSev { 50% { box-shadow:0 0 26px rgba(0,212,255,.28), inset 0 0 22px rgba(0,212,255,.12); } }
  .summary { margin-top:10px; font-size:13px; color:#8fdcec; letter-spacing:.05em; max-width:1100px;
    opacity:0; animation:fadeUp .5s .5s forwards; }

  /* ── main grid ── */
  main { flex:1; display:grid; grid-template-columns: 300px 1fr 420px; gap:20px; margin-top:16px;
    min-height:0; overflow-y:auto; }
  main > * { min-width:0; }   /* grid children can shrink — prevents column blowout */
  @media (max-width: 1150px) {
    main { grid-template-columns: 1fr; overflow-y:auto; }
  }

  .panel { border:1px solid rgba(0,212,255,.30); background:rgba(0,16,26,.66);
    box-shadow:inset 0 0 30px rgba(0,212,255,.05), 0 0 18px rgba(0,0,0,.5);
    padding:14px 16px; position:relative; overflow:hidden; opacity:0; transform:translateY(18px);
    animation:panelIn .55s cubic-bezier(.2,.8,.2,1) forwards; }
  @keyframes panelIn { to { opacity:1; transform:none; } }
  .panel::before { content:""; position:absolute; top:0; left:0; width:26px; height:26px;
    border-top:2px solid #00e5ff; border-left:2px solid #00e5ff; opacity:.8; }
  .panel::after { content:""; position:absolute; bottom:0; right:0; width:26px; height:26px;
    border-bottom:2px solid #00e5ff; border-right:2px solid #00e5ff; opacity:.8; }
  .panel h2 { font-size:12px; letter-spacing:.34em; color:#00e5ff; margin-bottom:10px;
    text-shadow:0 0 10px rgba(0,212,255,.6); }
  .panel h2 .dot { color:#ff6a3d; }

  /* left: the body */
  #figure { display:flex; flex-direction:column; align-items:center; animation-delay:.6s; }
  #figTitle { font-size:11px; letter-spacing:.3em; color:#4cc3d6; margin-bottom:4px; }
  svg#body { width:180px; height:430px; overflow:visible; }
  .bp { font-size:10px; letter-spacing:.2em; color:#37d6ff; }
  :root { --sev:__SEVCOL__; --sevFill:__SEVFILL__; }
  .organ { stroke:#0a8aa6; stroke-width:1; fill:rgba(0,212,255,.05);
           transition:fill .5s, stroke .5s; }
  .organ.hit { stroke:var(--sev); fill:var(--sevFill);
               animation:organPulse 1.6s ease-in-out infinite; }
  @keyframes organPulse { 0%,100% { opacity:.55; } 50% { opacity:1; } }
  .org-label { font-size:8.5px; letter-spacing:.16em; fill:var(--sev);
               opacity:0; transition:opacity .5s; }
  .org-label.show { opacity:.95; }
  .org-tick { stroke:var(--sev); stroke-width:.7; opacity:0; transition:opacity .5s; }
  .org-tick.show { opacity:.7; }
  .vitals { width:100%; margin-top:8px; font-size:11px; color:#69c9da; line-height:2; letter-spacing:.1em; }
  .vitals b { color:#00e5ff; float:right; }

  /* centre: EKG + recovery + supplies */
  .mid { display:flex; flex-direction:column; gap:14px; min-height:0; overflow-y:auto; }
  #ekgPanel { animation-delay:.8s; }
  canvas#ekg { width:100%; height:110px; display:block; }
  #recovery { animation-delay:1s; display:flex; align-items:center; gap:18px; }
  .ringWrap { position:relative; width:104px; height:104px; flex:0 0 auto; }
  .ringWrap svg { transform:rotate(-90deg); }
  .ringWrap .pct { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center;
    font-size:11px; color:#00e5ff; letter-spacing:.12em; text-align:center; }
  #supplies { animation-delay:1.2s; overflow:auto; min-height:0; }
  #bodyHolo { animation-delay:.9s; padding:0; }
  #holoBody { width:100%; height:250px; display:block; cursor:grab; }
  #holoBody:active { cursor:grabbing; }
  .holo-note { font-size:9px; letter-spacing:.2em; color:#4cc3d6; padding:4px 12px 8px; }
  .supply { display:flex; gap:10px; padding:6px 2px; font-size:12.5px; letter-spacing:.06em; color:#bfeef8;
    border-bottom:1px dashed rgba(0,212,255,.15); opacity:0; transform:translateX(-10px); }
  .supply .tick { color:#ff6a3d; }
  .supply.in { animation:supplyIn .35s forwards; }
  @keyframes supplyIn { to { opacity:1; transform:none; } }
  .none { color:#4cc3d6; font-size:12px; }

  /* right: remedies + warnings */
  .right { display:flex; flex-direction:column; gap:14px; min-height:0; overflow:auto; }
  #remedies { animation-delay:1.15s; }
  .remedy { border:1px solid rgba(0,212,255,.22); background:rgba(0,20,32,.5); padding:10px 12px; margin-bottom:10px;
    opacity:0; transform:translateX(16px); }
  .remedy.in { animation:remedyIn .4s cubic-bezier(.2,.8,.2,1) forwards; }
  @keyframes remedyIn { to { opacity:1; transform:none; } }
  .r-head { display:flex; align-items:baseline; gap:8px; }
  .r-ico { font-size:15px; }
  .r-name { font-size:13.5px; color:#eafcff; letter-spacing:.06em; }
  .r-type { font-size:9.5px; letter-spacing:.22em; padding:2px 8px; border:1px solid; margin-left:auto; }
  .r-how { font-size:12px; color:#8fdcec; margin-top:6px; line-height:1.55; }
  .r-fx { margin-top:7px; display:flex; flex-wrap:wrap; gap:5px; }
  .chip { font-size:10px; letter-spacing:.08em; padding:2px 8px; border:1px solid rgba(255,210,61,.55);
    color:#ffd23d; background:rgba(255,210,61,.06); }
  .chip.dark { border-color:rgba(255,61,90,.55); color:#ff7d92; background:rgba(255,61,90,.07); }
  .fx-label { font-size:9px; letter-spacing:.26em; color:#4cc3d6; margin-top:8px; }

  #risks { animation-delay:1.35s; border-color:rgba(255,61,90,.4); }
  #risks h2 { color:#ff5d78; text-shadow:0 0 10px rgba(255,61,90,.6); }
  #risks::before { border-color:#ff5d78; }
  #risks::after { border-color:#ff5d78; }
  .row { display:flex; gap:9px; font-size:12.5px; line-height:1.55; padding:4px 0; letter-spacing:.04em; }
  .risk { color:#ffb3c0; } .risk .mark { color:#ff5d78; }
  #doctor { animation-delay:1.55s; border-color:rgba(255,61,90,.55); box-shadow:inset 0 0 30px rgba(255,61,90,.07); }
  #doctor h2 { color:#ff5d78; }
  #doctor::before, #doctor::after { border-color:#ff5d78; }
  .doc { color:#ffd7de; } .doc .mark { color:#ff5d78; }

  footer { position:fixed; left:0; right:0; bottom:0; z-index:5; display:flex; justify-content:space-between;
    padding:7px 28px; font-size:10px; letter-spacing:.22em; color:#3fa9bc;
    border-top:1px solid rgba(0,212,255,.18); background:rgba(0,8,12,.8); }
  footer a { color:#ff6a3d; text-decoration:none; }
  footer a:hover { text-shadow:0 0 8px rgba(255,106,61,.9); }
  footer .warn { color:#ff8d9f; }

  @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:none; } }
  ::-webkit-scrollbar { width:6px; } ::-webkit-scrollbar-thumb { background:rgba(0,212,255,.3); }
</style>
</head>
<body>
<canvas id="stars"></canvas>
<div class="sweep"></div><div class="scanlines"></div><div class="vignette"></div>

<div class="bay">
  <header>
    <div class="h-left">
      <div class="kicker">STARK MEDICAL BAY · VOLUMETRIC DIAGNOSTIC</div>
      <h1><span id="typed"></span><span class="cursor">▊</span></h1>
      <div class="summary">__SUMMARY__</div>
    </div>
    <div class="h-right">
      PATIENT: PRIMARY USER<br>
      SCAN: __STAMP__<br>
      AFFECTED: __BODYPART__<br>
      EST. RECOVERY: __RECOVERY__<br>
      <span class="sev">▸ __SEVLABEL__</span>
    </div>
  </header>

  <main>
    <section class="panel" id="figure">
      <div id="figTitle">SUBJECT SURFACE MAP</div>
      <svg id="body" viewBox="0 0 120 300">
        <g id="organSys">
          <path class="organ" data-organ="systemic" d="M60 3 v294 M12 150 h96" stroke-dasharray="3 4" opacity=".5"/>
          <!-- silhouette -->
          <path d="M60 8 C 66 8, 72 12, 73 19 C 74 25, 72 31, 68 34 L 69 42 C 82 46, 88 54, 90 66 L 93 96 L 97 128 L 93 130 L 86 102 L 84 138 L 88 168 L 88 214 L 80 216 L 74 172 L 72 142 L 68 172 L 67 214 L 80 218 L 82 262 L 84 292 L 66 292 L 63 226 L 60 226 L 57 226 L 54 292 L 36 292 L 38 262 L 40 218 L 53 214 L 66 172 L 65 142 L 63 172 L 57 172 L 55 142 L 53 172 L 46 216 L 38 214 L 38 168 L 42 138 L 40 102 L 34 130 L 30 128 L 33 96 L 36 66 C 38 54, 44 46, 51 42 L 52 34 C 48 31, 46 25, 47 19 C 48 12, 54 8, 60 8 Z"
                fill="rgba(0,212,255,.045)" stroke="#00d4ff" stroke-width="1" opacity=".8"/>
          <!-- head: brain + eyes + throat -->
          <ellipse class="organ" data-organ="brain head mind" cx="60" cy="17" rx="8.5" ry="6.5"/>
          <ellipse class="organ" data-organ="brain head mind" cx="60" cy="18" rx="3.5" ry="2.5"/>
          <circle class="organ" data-organ="eyes vision" cx="55.5" cy="20" r="1.7"/>
          <circle class="organ" data-organ="eyes vision" cx="64.5" cy="20" r="1.7"/>
          <path class="organ" data-organ="throat mouth tonsils" d="M56 25 h8 l-1.5 4 h-5 z"/>
          <!-- chest: heart + lungs -->
          <path class="organ" data-organ="heart chest cardiovascular" d="M60 47 C 55 42, 47 45, 48 52 C 49 58, 56 62, 60 65 C 64 62, 71 58, 72 52 C 73 45, 65 42, 60 47 Z"/>
          <path class="organ" data-organ="lungs respiratory breath" d="M53 45 C 48 44, 45 50, 45 58 C 45 65, 48 70, 52 70 L 53 45 Z"/>
          <path class="organ" data-organ="lungs respiratory breath" d="M67 45 C 72 44, 75 50, 75 58 C 75 65, 72 70, 68 70 L 67 45 Z"/>
          <!-- liver, stomach, kidneys, gut -->
          <path class="organ" data-organ="liver" d="M62 74 L 76 72 C 79 76, 78 82, 73 84 L 63 81 Z"/>
          <path class="organ" data-organ="stomach gut abdomen belly" d="M57 74 C 51 74, 47 79, 49 85 C 50 89, 55 91, 58 88 L 58 74 Z"/>
          <ellipse class="organ" data-organ="kidneys back flank" cx="71" cy="92" rx="3" ry="4.5"/>
          <ellipse class="organ" data-organ="kidneys back flank" cx="49" cy="92" rx="3" ry="4.5"/>
          <path class="organ" data-organ="gut intestines abdomen belly" d="M50 96 h20 v14 c0 4 -5 6 -10 6 s-10 -2 -10 -6 z"/>
          <!-- joints / limbs -->
          <circle class="organ" data-organ="shoulder joints arm" cx="39" cy="70" r="2.6"/>
          <circle class="organ" data-organ="shoulder joints arm" cx="81" cy="70" r="2.6"/>
          <circle class="organ" data-organ="elbow joints arm" cx="33" cy="104" r="2.2"/>
          <circle class="organ" data-organ="elbow joints arm" cx="87" cy="104" r="2.2"/>
          <circle class="organ" data-organ="hand wrist arm" cx="31" cy="128" r="2.4"/>
          <circle class="organ" data-organ="hand wrist arm" cx="89" cy="128" r="2.4"/>
          <circle class="organ" data-organ="hip joints leg" cx="46" cy="150" r="2.6"/>
          <circle class="organ" data-organ="hip joints leg" cx="74" cy="150" r="2.6"/>
          <circle class="organ" data-organ="knee joints leg" cx="41" cy="196" r="2.4"/>
          <circle class="organ" data-organ="knee joints leg" cx="79" cy="196" r="2.4"/>
          <circle class="organ" data-organ="foot ankle leg" cx="38" cy="284" r="2.4"/>
          <circle class="organ" data-organ="foot ankle leg" cx="82" cy="284" r="2.4"/>
          <!-- spine -->
          <g class="organ" data-organ="spine back posture">
            <circle cx="60" cy="52" r="1.4"/><circle cx="60" cy="58" r="1.4"/>
            <circle cx="60" cy="64" r="1.4"/><circle cx="60" cy="70" r="1.4"/>
            <circle cx="60" cy="76" r="1.4"/><circle cx="60" cy="82" r="1.4"/>
            <circle cx="60" cy="88" r="1.4"/><circle cx="60" cy="94" r="1.4"/>
            <circle cx="60" cy="100" r="1.4"/><circle cx="60" cy="106" r="1.4"/>
            <circle cx="60" cy="112" r="1.4"/><circle cx="60" cy="118" r="1.4"/>
            <circle cx="60" cy="124" r="1.4"/><circle cx="60" cy="130" r="1.4"/>
          </g>
        </g>
        <g id="bodyGlow" opacity="0">
          <circle id="afflict" cx="60" cy="70" r="6" fill="__SEVCOL__" opacity=".9">
            <animate attributeName="r" values="4;11;4" dur="1.6s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values=".9;.15;.9" dur="1.6s" repeatCount="indefinite"/>
          </circle>
        </g>
        <line id="figScan" x1="6" x2="114" y1="0" y2="0" stroke="#00e5ff" stroke-width="1" opacity="0"/>
      </svg>
      <div class="bp">▸ __BODYPART__</div>
      <div class="vitals">
        STATUS <b>DIAGNOSTIC COMPLETE</b><br>
        THREAT <b style="color:__SEVCOL__">__SEVLABEL__</b><br>
        PROTOCOL <b>RECOVERY PLAN READY</b>
      </div>
    </section>

    <div class="mid">
      <section class="panel" id="ekgPanel">
        <h2><span class="dot">●</span> VITAL WAVEFORM — LIVE</h2>
        <canvas id="ekg"></canvas>
      </section>
      <section class="panel" id="bodyHolo">
        <div style="padding:10px 12px 0;"><h2 style="margin:0;"><span class="dot">●</span> VOLUMETRIC BODY PROJECTION — LIVE 3D</h2></div>
        <div id="holoBody"></div>
        <div class="holo-note">▸ DRAG TO ORBIT · AFFECTED TISSUE GLOWS __SEVLABEL__</div>
      </section>
      <section class="panel" id="recovery">
        <div class="ringWrap">
          <svg width="104" height="104" viewBox="0 0 104 104">
            <circle cx="52" cy="52" r="44" stroke="rgba(0,212,255,.15)" stroke-width="6" fill="none"/>
            <circle id="ring" cx="52" cy="52" r="44" stroke="#00e5ff" stroke-width="6" fill="none"
              stroke-linecap="round" stroke-dasharray="276.5" stroke-dashoffset="276.5"
              style="filter:drop-shadow(0 0 6px rgba(0,229,255,.8));
                     transition:stroke-dashoffset 1.6s cubic-bezier(.2,.8,.2,1) 1.4s;"/>
          </svg>
          <div class="pct"><span style="font-size:16px;">✚</span><span>TREAT</span></div>
        </div>
        <div>
          <h2 style="margin-bottom:6px;">TREATMENT FEASIBILITY</h2>
          <div class="none" style="line-height:1.7;">Recovery plan synthesised.<br>
          Follow the remedies panel; each lists its side effects.<br>
          <span class="warn" style="color:#ff8d9f;">If anything feels wrong — stop and seek help.</span></div>
        </div>
      </section>
      <section class="panel" id="supplies">
        <h2><span class="dot">●</span> WHAT YOU NEED <span style="color:#ff6a3d;">— GATHER FIRST</span></h2>
        __SUPPLIES__
        <div class="none" id="noSupplies" style="display:none;">No special items required.</div>
      </section>
    </div>

    <div class="right">
      <section class="panel" id="remedies">
        <h2><span class="dot">●</span> REMEDIES — HOW TO CURE IT</h2>
        <div id="remedyList"></div>
      </section>
      <section class="panel" id="risks">
        <h2>⚠ RISKS IF UNTREATED — WHAT CAN HAPPEN</h2>
        __RISKS__
      </section>
      <section class="panel" id="doctor">
        <h2>⚑ SEE A REAL DOCTOR IF</h2>
        __DOCTOR__
      </section>
    </div>
  </main>
</div>

<footer>
  <span><a href="library.html">◂ DISEASE INDEX</a> · <span id="clock"></span></span>
  <span class="warn">▸ EDUCATIONAL DISPLAY — NOT MEDICAL ADVICE. IN EMERGENCIES CALL YOUR LOCAL EMERGENCY NUMBER.</span>
  <span>STARK PROTOCOL: ONLINE</span>
</footer>

<script>
const PAY = __PAYLOAD__;

/* starfield */
(function () {
  const c = document.getElementById('stars'), x = c.getContext('2d');
  let W, H, pts = [];
  function size () {
    W = c.width = innerWidth; H = c.height = innerHeight;
    pts = Array.from({length: 90}, () => ({
      x: Math.random() * W, y: Math.random() * H,
      s: Math.random() * 1.6 + .4, v: Math.random() * .25 + .05,
      tw: Math.random() * Math.PI * 2
    }));
  }
  addEventListener('resize', size); size();
  // 30 fps cap + hidden-tab pause: 90 drifting dots do not need 60 fps —
  // and this page's starfield previously burned a full core at all times.
  let lastStar = 0, sT = 0;
  (function draw (t) {
    requestAnimationFrame(draw);
    t = t || performance.now();
    if (document.hidden) return;
    if (t - lastStar < 33) return;
    lastStar = t; sT += 33;
    x.clearRect(0, 0, W, H);
    for (const p of pts) {
      p.y -= p.v; if (p.y < -4) { p.y = H + 4; p.x = Math.random() * W; }
      const a = .25 + .55 * Math.abs(Math.sin(sT / 900 + p.tw));
      x.fillStyle = 'rgba(0,212,255,' + a.toFixed(3) + ')';
      x.fillRect(p.x, p.y, p.s, p.s);
    }
  })(0);
})();

/* title typing */
(function () {
  const el = document.getElementById('typed'), txt = PAY.condition.toUpperCase();
  let i = 0;
  (function tick () {
    el.textContent = txt.slice(0, ++i);
    if (i < txt.length) setTimeout(tick, 42 + Math.random() * 40);
  })();
})();

/* figure scan sweep + organ highlight */
(function () {
  const line = document.getElementById('figScan'), glow = document.getElementById('bodyGlow');
  // which organs does body_part point at?
  const ORGANS = [
    ['brain',        ['brain', 'mind', 'head', 'skull', 'migraine', 'concussion', 'mental']],
    ['eyes',         ['eye', 'vision', 'sight']],
    ['throat',       ['throat', 'tonsil', 'mouth', 'voice', 'sore throat']],
    ['heart',        ['heart', 'cardio', 'chest', 'blood pressure']],
    ['lungs',        ['lung', 'respiratory', 'breath', 'asthma', 'cough']],
    ['liver',        ['liver']],
    ['stomach',      ['stomach', 'gut', 'abdomen', 'belly', 'nausea', 'food']],
    ['kidneys',      ['kidney', 'flank', 'urin']],
    ['gut',          ['gut', 'intestine', 'bowel', 'colon']],
    ['spine',        ['spine', 'back', 'posture', 'neck']],
    ['shoulder',     ['shoulder']],
    ['elbow',        ['elbow']],
    ['hand',         ['hand', 'wrist', 'finger']],
    ['hip',          ['hip']],
    ['knee',         ['knee', 'leg']],
    ['foot',         ['foot', 'ankle', 'feet']],
    ['systemic',     ['systemic', 'whole', 'body', 'virus', 'infection', 'fever', 'flu', 'cold']],
  ];
  const bp = (PAY.bodyPart || 'systemic').toLowerCase();
  let hit = 'systemic';
  outer:
  for (const [key, words] of ORGANS) {
    for (const w of words) {
      if (bp.includes(w)) { hit = key; break outer; }
    }
  }
  // mark every organ whose key (or data-organ list) matches
  document.querySelectorAll('#body .organ').forEach(el => {
    const keys = (el.dataset.organ || '').toLowerCase();
    if (keys.includes(hit)) {
      el.classList.add('hit');
      el.querySelectorAll('circle,path,ellipse').forEach(c => c.classList.add('hit'));
    }
  });
  if (hit === 'systemic') {
    document.querySelectorAll('#body .organ').forEach(el => el.classList.add('hit'));
  }
  const label = document.getElementById('figTitle');
  label.textContent = 'SUBJECT SURFACE MAP — AFFECTED: ' + hit.toUpperCase();
  // sweep once, then reveal glow
  let y = 0, dir = 1;
  const iv = setInterval(() => {
    y += dir * 7;
    if (y > 300) { y = 300; dir = -1; }
    if (y < 0)   { y = 0;   dir = 1; clearInterval(iv); glow.setAttribute('opacity', '1');
                   setTimeout(() => line.setAttribute('opacity', '0'), 500); return; }
    line.setAttribute('y1', y); line.setAttribute('y2', y); line.setAttribute('opacity', '.85');
  }, 26);
})();

/* EKG */
(function () {
  const c = document.getElementById('ekg'), x = c.getContext('2d');
  let W, H, t = 0;
  const trace = [];
  function beat (u) {
    // one PQRST-ish complex per unit cycle
    const cycle = u % 1;
    let v = 0;
    v += Math.exp(-Math.pow((cycle - .16) * 26, 2)) * .18;    // P
    v -= Math.exp(-Math.pow((cycle - .30) * 60, 2)) * .12;    // Q
    v += Math.exp(-Math.pow((cycle - .34) * 22, 2)) * 1.0;    // R
    v -= Math.exp(-Math.pow((cycle - .40) * 48, 2)) * .25;    // S
    v += Math.exp(-Math.pow((cycle - .60) * 14, 2)) * .30;    // T
    return v;
  }
  // Grid is pre-rendered once into an offscreen layer — redrawing it every
  // frame is pure waste. The glow is faked with a wide translucent stroke under
  // the bright one (no shadowBlur — the single most expensive canvas op).
  // Order matters: layer declared first, then bake, then the first size() —
  // calling size() before gridLayer existed threw TDZ errors every load.
  const dpr = Math.min(1.5, devicePixelRatio || 1);
  const gridLayer = document.createElement('canvas');
  function bakeGrid () {
    gridLayer.width = W; gridLayer.height = H;
    const g = gridLayer.getContext('2d');
    g.strokeStyle = 'rgba(0,212,255,.12)'; g.lineWidth = 1;
    for (let gx = 0; gx < W; gx += 26 * dpr) { g.beginPath(); g.moveTo(gx, 0); g.lineTo(gx, H); g.stroke(); }
  }
  function size () {
    // Panels animate in and narrow viewports collapse columns — clientWidth can
    // legitimately be 0 at script time. Never bake a zero-size layer: fall
    // back, and re-sync from a ResizeObserver when the real size arrives.
    const cw = c.clientWidth || c.parentNode.clientWidth || 320;
    W = Math.max(2, Math.round(cw * dpr));
    H = Math.max(2, Math.round(110 * dpr));
    c.width = W; c.height = H;
    bakeGrid();
  }
  addEventListener('resize', size);
  if (window.ResizeObserver) new ResizeObserver(size).observe(c);
  size();
  const sevFast = PAY.severity === 'serious' ? 1.5 : PAY.severity === 'moderate' ? 1.18 : 1.0;
  let lastEkg = 0;
  (function draw (now) {
    requestAnimationFrame(draw);
    now = now || performance.now();
    if (document.hidden) return;            // hidden tab — zero cost
    if (now - lastEkg < 33) return;         // ~30 fps cap — EKG reads better slow
    lastEkg = now;
    if (W < 4 || H < 4) return;             // canvas not laid out yet — skip frame
    t += .024 * sevFast;                    // 2× step keeps the same sweep speed
    trace.push(beat(t));
    if (trace.length > 460) trace.shift();
    x.clearRect(0, 0, W, H);
    try { x.drawImage(gridLayer, 0, 0); } catch (e) { bakeGrid(); }
    const mid = H * .62, amp = H * .34;
    x.beginPath();
    trace.forEach((v, i) => {
      const px = i / 460 * W, py = mid - v * amp;
      i ? x.lineTo(px, py) : x.moveTo(px, py);
    });
    x.globalCompositeOperation = 'lighter';
    x.strokeStyle = 'rgba(0,229,255,.28)';  // fake glow: wide soft pass
    x.lineWidth = 5 * dpr;
    x.stroke();
    x.globalCompositeOperation = 'source-over';
    x.strokeStyle = '#00e5ff';              // bright core line
    x.lineWidth = 1.6 * dpr;
    x.stroke();
  })();
})();

/* recovery ring sweep-in */
setTimeout(() => { document.getElementById('ring').style.strokeDashoffset = '34'; }, 300);

/* supplies staggered reveal */
(function () {
  const rows = document.querySelectorAll('#supplies .supply');
  if (!rows.length) { document.getElementById('noSupplies').style.display = 'block'; return; }
  rows.forEach((r, i) => setTimeout(() => r.classList.add('in'), 1300 + i * 160));
})();

/* remedy cards */
(function () {
  const TYPES = {"medicine":"#ff6a3d","home":"#37ffb5","food":"#ffd23d","habit":"#37d6ff","tool":"#9a7bff","fictional":"#ff5ad6"};
  const ICONS = {"medicine":"💊","home":"🏠","food":"🍎","habit":"🔁","tool":"🔧","fictional":"✦"};
  const host = document.getElementById('remedyList');
  (PAY.remedies || []).forEach((r, i) => {
    const type = (r.type || 'home').toLowerCase();
    const col = TYPES[type] || '#37d6ff';
    const el = document.createElement('div');
    el.className = 'remedy';
    const fx = (r.side_effects || []);
    el.innerHTML =
      '<div class="r-head">' +
        '<span class="r-ico">' + (ICONS[type] || '✚') + '</span>' +
        '<span class="r-name"></span>' +
        '<span class="r-type" style="color:' + col + ';border-color:' + col + ';">' + type.toUpperCase() + '</span>' +
      '</div>' +
      '<div class="r-how"></div>' +
      (fx.length ? '<div class="fx-label">SIDE EFFECTS ▾</div><div class="r-fx">' +
        fx.map(f => '<span class="chip"></span>').join('') + '</div>' : '');
    el.querySelector('.r-name').textContent = r.name || 'Remedy';
    el.querySelector('.r-how').textContent  = r.how  || '';
    el.querySelectorAll('.chip').forEach((ch, j) => ch.textContent = fx[j]);
    host.appendChild(el);
    setTimeout(() => el.classList.add('in'), 1500 + i * 260);
  });
  if (!(PAY.remedies || []).length)
    host.innerHTML = '<div class="none">Rest and hydration — no active treatment listed.</div>';
})();

/* ── volumetric body projection (3D) ─────────────────────────────────── */
(function () {
  if (typeof THREE === 'undefined') return;   // CDN down — 2D map still works
  const host = document.getElementById('holoBody');
  const SEVCOL = {mild:'#37ffb5', moderate:'#ffd23d', serious:'#ff3d5a', fictional:'#ff5ad6'};
  const hitCol = new THREE.Color(SEVCOL[PAY.severity] || SEVCOL.moderate);
  const cyan   = new THREE.Color('#00d4ff');

  const W0 = host.clientWidth || 380, H0 = host.clientHeight || 250;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, W0 / H0, 0.1, 100);
  camera.position.set(0, 0.6, 17);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(1.5, devicePixelRatio || 1));
  renderer.setSize(W0, H0);
  host.appendChild(renderer.domElement);

  // stage sizing that never trusts a zero-size host (same lesson as the main viewer)
  function fit() {
    const w = Math.max(1, host.clientWidth || W0), h = Math.max(1, host.clientHeight || H0);
    renderer.setSize(w, h, true);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  fit();
  if (window.ResizeObserver) new ResizeObserver(fit).observe(host);
  [200, 800].forEach(ms => setTimeout(fit, ms));

  scene.add(new THREE.AmbientLight(0x0a2a38, 1.2));

  // ── the body, assembled from primitives (units ~ decimetres) ──────────
  const body = new THREE.Group();
  scene.add(body);
  body.position.y = -7.5;
  const skin = new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: 0.10,
                                             blending: THREE.AdditiveBlending, depthWrite: false });
  const wire = new THREE.MeshBasicMaterial({ color: cyan, wireframe: true, transparent: true, opacity: 0.28,
                                             blending: THREE.AdditiveBlending, depthWrite: false });
  function part(geo, x, y, z, rx, ry, rz, sx, sy, sz) {
    const m = new THREE.Mesh(geo, skin); m.position.set(x, y, z);
    m.rotation.set(rx || 0, ry || 0, rz || 0); if (sx) m.scale.set(sx, sy, sz);
    body.add(m);
    const w = new THREE.Mesh(geo, wire); w.position.copy(m.position);
    w.rotation.copy(m.rotation); if (sx) w.scale.set(sx, sy, sz);
    body.add(w);
    return m;
  }
  // head + torso + limbs (hollow, additive — the hologram look)
  part(new THREE.SphereGeometry(1.55, 18, 14), 0, 13.4, 0);
  part(new THREE.CylinderGeometry(1.9, 2.6, 5.4, 14), 0, 5.4, 0);           // neck+upper chest
  part(new THREE.CylinderGeometry(2.7, 2.2, 6.4, 14), 0, -0.4, 0);          // torso
  part(new THREE.CylinderGeometry(2.2, 2.5, 4.2, 12), 0, -5.4, 0);          // hips
  part(new THREE.CylinderGeometry(0.95, 0.8, 8.6, 10), -3.6, 2.2, 0, 0, 0, 0.16);  // arms
  part(new THREE.CylinderGeometry(0.95, 0.8, 8.6, 10),  3.6, 2.2, 0, 0, 0, -0.16);
  part(new THREE.SphereGeometry(0.95, 10, 8), -4.5, -2.6, 0);               // hands
  part(new THREE.SphereGeometry(0.95, 10, 8),  4.5, -2.6, 0);
  part(new THREE.CylinderGeometry(1.25, 1.05, 9.4, 10), -1.5, -11.0, 0);    // legs
  part(new THREE.CylinderGeometry(1.25, 1.05, 9.4, 10),  1.5, -11.0, 0);
  part(new THREE.BoxGeometry(1.3, 0.8, 3.2), -1.5, -16.0, 0.5);             // feet
  part(new THREE.BoxGeometry(1.3, 0.8, 3.2),  1.5, -16.0, 0.5);

  // ── organ markers, positions matching the 2D map ─────────────────────
  const ORGANS = {
    brain:   [0, 14.2, 0.4, 1.05],
    eyes:    [0, 13.7, 1.3, 0.35],
    throat:  [0, 11.9, 0.3, 0.55],
    heart:   [-0.4, 7.6, 0.6, 0.8],
    lungs:   [0, 7.8, 0, 1.35],
    liver:   [0.9, 3.4, 0.4, 0.85],
    stomach: [-0.8, 3.2, 0.4, 0.8],
    kidneys: [0, 1.0, -0.8, 0.95],
    gut:     [0, -1.6, 0.5, 1.15],
    spine:   [0, 4.5, -1.3, 0.5],
    shoulder:[-3.6, 8.6, 0, 0.6],
    elbow:   [-4.6, 4.4, 0, 0.45],
    hand:    [-4.5, -2.6, 0, 0.55],
    hip:     [-1.5, -6.4, 0, 0.6],
    knee:    [-1.5, -10.6, 0, 0.5],
    foot:    [-1.5, -15.9, 0.5, 0.55],
    systemic:[0, 3.0, 0, 2.6],
  };
  // which organ(s) does body_part point at? same keyword logic as the 2D map
  const MATCH = [
    ['brain', ['brain','mind','head','skull','migraine','concussion','mental']],
    ['eyes', ['eye','vision','sight']], ['throat', ['throat','tonsil','mouth','voice']],
    ['heart', ['heart','cardio','chest','blood pressure']],
    ['lungs', ['lung','respiratory','breath','asthma','cough']],
    ['liver', ['liver']], ['stomach', ['stomach','abdomen','belly','nausea','food']],
    ['kidneys', ['kidney','flank','urin']], ['gut', ['gut','intestine','bowel','colon']],
    ['spine', ['spine','back','posture','neck']], ['shoulder', ['shoulder']],
    ['elbow', ['elbow']], ['hand', ['hand','wrist','finger']], ['hip', ['hip']],
    ['knee', ['knee','leg']], ['foot', ['foot','ankle','feet']],
    ['systemic', ['systemic','whole','body','virus','infection','fever','flu','cold']],
  ];
  const bp = (PAY.bodyPart || 'systemic').toLowerCase();
  let hit = 'systemic';
  outer: for (const [key, words] of MATCH) for (const w of words) if (bp.includes(w)) { hit = key; break outer; }

  const hitMat = new THREE.MeshBasicMaterial({ color: hitCol, transparent: true, opacity: 0.5,
                                               blending: THREE.AdditiveBlending, depthWrite: false });
  const hitWire = new THREE.MeshBasicMaterial({ color: hitCol, wireframe: true, transparent: true, opacity: 0.85,
                                                blending: THREE.AdditiveBlending, depthWrite: false });
  const hits = [];
  Object.entries(ORGANS).forEach(([k, [x, y, z, r]]) => {
    if (k !== hit && !(hit === 'systemic')) return;
    const g = new THREE.SphereGeometry(r, 14, 10);
    const core = new THREE.Mesh(g, hitMat); core.position.set(x, y, z);
    const wr = new THREE.Mesh(g, hitWire); wr.position.set(x, y, z);
    body.add(core, wr); hits.push(core);
  });

  // projection pad + orbit ring, the Stark signature
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(6.5, 7.2, 0.4, 40),
    new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: 0.14,
                                  blending: THREE.AdditiveBlending, depthWrite: false }));
  pad.position.y = -17.6; body.add(pad);
  const padRing = new THREE.Mesh(new THREE.TorusGeometry(7.2, 0.06, 6, 60),
    new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: 0.5 }));
  padRing.rotation.x = Math.PI / 2; padRing.position.y = -17.4; body.add(padRing);

  // slow auto-orbit + drag to orbit
  let ang = 0.5, dragging = false, px = 0;
  host.addEventListener('pointerdown', e => { dragging = true; px = e.clientX; });
  addEventListener('pointerup', () => dragging = false);
  addEventListener('pointermove', e => { if (dragging) { ang += (e.clientX - px) * 0.008; px = e.clientX; } });

  // 30 fps, pause when hidden — the cheap-animation rule
  let last = 0;
  (function loop(t) {
    requestAnimationFrame(loop);
    t = t || performance.now();
    if (document.hidden) return;
    if (t - last < 33) return;
    last = t;
    if (!dragging) ang += 0.004;
    body.rotation.y = ang;
    const p = 0.5 + 0.5 * Math.sin(t / 400);
    hitMat.opacity = 0.28 + 0.30 * p;
    hits.forEach(h => h.scale.setScalar(1 + 0.12 * p));
    renderer.render(scene, camera);
  })(0);
})();

/* clock */
setInterval(() => {
  document.getElementById('clock').textContent =
    new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'});
}, 1000);
</script>
</body>
</html>
"""


if __name__ == "__main__":   # manual preview
    handler(
        condition="Common Cold",
        severity="mild",
        summary="Viral upper-respiratory infection — self-limiting, treat the symptoms.",
        body_part="throat",
        recovery_days="3–7 days",
        supplies=["Tissue box", "Thermometer", "Honey", "Fresh ginger", "Lemons", "Water bottle"],
        remedies=[
            {"name": "Paracetamol", "type": "medicine", "how": "500–1000 mg every 6 h, max 4 g/day, with food.",
             "side_effects": ["Nausea", "Liver strain if overdosed"]},
            {"name": "Ginger-honey tea", "type": "home", "how": "Steep sliced ginger 10 min, add honey, drink 3× daily.",
             "side_effects": ["Heartburn in excess"]},
            {"name": "Steam inhalation", "type": "habit", "how": "Bowl of hot water, towel over head, 10 min, 2× daily.",
             "side_effects": ["Rare burns if water too hot"]},
            {"name": "Medigel pack", "type": "fictional", "how": "Apply to chest; fine, it is not real — demo of fictional entries.",
             "side_effects": ["Temporary blue glow"]},
        ],
        risks_if_untreated=["Sinus infection", "Ear infection", "Bronchitis in rare cases"],
        see_doctor_if=["Fever above 39°C for 3+ days", "Shortness of breath", "Symptoms worsen after day 10"],
    )
