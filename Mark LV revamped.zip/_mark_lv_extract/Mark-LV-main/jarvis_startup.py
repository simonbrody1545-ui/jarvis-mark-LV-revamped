"""
JARVIS Startup Introduction — cinematic boot sequence.

A single self-contained HTML file, no GPU, no network, no external assets:
the arc reactor is drawn frame-by-frame on a 2D canvas (triangular core,
counter-rotating arc segments, tick ring, cross-bars, radar sweep and a
scan line), around it a Stark-style HUD — corner brackets, telemetry panels
that populate as systems come online, a boot log that types itself out and
a progress bar synced to it.

The soundtrack is synthesized live with the Web Audio API (reactor hum,
power-up swell, interface blips, online chime) and JARVIS himself greets
the user with a spoken line — a British-English system voice when one
exists, a synthesized chord motif standing in when none does.

The window closes itself when the sequence completes; a click or any
keypress skips it immediately (and silences the audio).
"""
from __future__ import annotations

import sys
import tempfile
import webbrowser
from pathlib import Path


def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_base_dir()

# Total animation length before the window closes itself (ms).
SEQUENCE_MS = 8600


def _signature_track_b64() -> str:
    """The signature startup soundtrack (the user's chosen clip), embedded as
    base64 data so the generated page stays a single self-contained file that
    works over file:// with no side-car assets. Respects the STARTUP SEQUENCE
    setting (sound off → no track). Missing file → empty string; the
    synthesised soundtrack still plays, nothing breaks."""
    try:
        import base64
        if not _startup_sound_enabled():
            return ""
        src = Path(__file__).resolve().parent / "assets" / "jarvis_startup_sound.mp3"
        if src.exists():
            return base64.b64encode(src.read_bytes()).decode("ascii")
    except Exception:
        pass
    return ""


def _startup_sound_enabled() -> bool:
    """The BOOT SOUND toggle from the STARTUP SEQUENCE settings section."""
    try:
        import json
        cfg = Path(__file__).resolve().parent / "config" / "api_keys.json"
        prefs = (json.loads(cfg.read_text(encoding="utf-8"))
                 .get("startup_sequence", {}) or {})
        return bool(prefs.get("sound", True))
    except Exception:
        return True


def generate_startup_html() -> str:
    """Generate the JARVIS startup animation HTML (plain string — the braces
    below are real CSS/JS braces, which is why this is NOT an f-string)."""

    html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>J.A.R.V.I.S — Initialising</title>
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    html, body {
        width: 100%; height: 100%;
        background: #00060a;
        overflow: hidden;
        font-family: 'Consolas', 'Courier New', monospace;
        color: #00d8ff;
        cursor: crosshair;
        user-select: none;
    }

    #reactor { position: absolute; inset: 0; display: block; }

    /* faint blueprint grid */
    #grid {
        position: absolute; inset: 0; pointer-events: none;
        background-image:
            linear-gradient(rgba(0, 168, 204, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 168, 204, 0.05) 1px, transparent 1px);
        background-size: 54px 54px;
        mask-image: radial-gradient(circle at 50% 46%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.35) 70%, transparent 100%);
        -webkit-mask-image: radial-gradient(circle at 50% 46%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.35) 70%, transparent 100%);
    }

    /* CRT scanlines + vignette */
    #crt {
        position: absolute; inset: 0; pointer-events: none; z-index: 40;
        background: repeating-linear-gradient(0deg,
            rgba(0, 0, 0, 0.16) 0px, rgba(0, 0, 0, 0.16) 1px,
            transparent 1px, transparent 3px);
    }
    #vignette {
        position: absolute; inset: 0; pointer-events: none; z-index: 41;
        background: radial-gradient(circle at 50% 46%, transparent 55%, rgba(0, 3, 6, 0.85) 100%);
    }

    .hud { position: absolute; z-index: 20; pointer-events: none;
           text-shadow: 0 0 8px rgba(0, 216, 255, 0.55); }

    /* corner brackets */
    .corner { position: absolute; width: 34px; height: 34px; z-index: 20;
              border: 2px solid rgba(0, 184, 230, 0.55); }
    .c-tl { top: 16px; left: 16px; border-right: none; border-bottom: none; }
    .c-tr { top: 16px; right: 16px; border-left: none; border-bottom: none; }
    .c-bl { bottom: 16px; left: 16px; border-right: none; border-top: none; }
    .c-br { bottom: 16px; right: 16px; border-left: none; border-top: none; }

    /* top identity strip */
    #id-block { top: 26px; left: 62px; font-size: 12px; line-height: 1.7; letter-spacing: 1px; }
    #id-block .big { font-size: 15px; font-weight: bold; color: #00e8ff;
                     letter-spacing: 4px; }
    #id-block .dim { color: #0088aa; }

    /* top-right status strip */
    #stat-block { top: 26px; right: 62px; text-align: right; font-size: 11px;
                  line-height: 1.7; letter-spacing: 1px; }
    #stat-block .k { color: #0088aa; }
    #stat-block .v { color: #00e8ff; }

    /* side telemetry panels */
    .tele { top: 50%; transform: translateY(-50%); font-size: 10.5px;
            line-height: 1.9; letter-spacing: 1px; opacity: 0;
            transition: opacity 1.2s ease; }
    .tele.live { opacity: 1; }
    #tele-l { left: 34px; }
    #tele-r { right: 34px; text-align: right; }
    .tele .k { color: #0088aa; }
    .tele .v { color: #00d8ff; }
    .tele .hi { color: #ff6600; }

    /* boot log */
    #bootlog {
        position: absolute; left: 62px; bottom: 96px; z-index: 20;
        width: 46ch; font-size: 12px; line-height: 1.62;
        letter-spacing: 0.5px; pointer-events: none;
        text-shadow: 0 0 7px rgba(0, 216, 255, 0.45);
    }
    #bootlog .ln { white-space: pre; }
    #bootlog .ok   { color: #00ffaa; text-shadow: 0 0 6px rgba(0,255,170,0.6); }
    #bootlog .warn { color: #ff6600; text-shadow: 0 0 6px rgba(255,102,0,0.6); }
    #bootlog .caret { display: inline-block; width: 8px; background: #00d8ff;
                      animation: blink 0.8s steps(1) infinite; }
    @keyframes blink { 50% { opacity: 0; } }

    /* progress */
    #boot-bar {
        position: absolute; left: 50%; bottom: 52px; transform: translateX(-50%);
        width: 46%; z-index: 20; pointer-events: none;
    }
    #boot-bar .lbl { display: flex; justify-content: space-between;
                     font-size: 10px; letter-spacing: 2px; color: #0088aa;
                     margin-bottom: 6px; }
    #boot-bar .lbl .v { color: #00e8ff; }
    #boot-bar .track { height: 5px; background: #001018;
                       border: 1px solid rgba(0, 184, 230, 0.6); }
    #boot-bar .fill {
        height: 100%; width: 0%;
        background: linear-gradient(90deg, #005f7a, #00d8ff 60%, #7df4ff);
        box-shadow: 0 0 12px rgba(0, 216, 255, 0.8);
        transition: width 0.18s linear;
    }

    #skip-note {
        position: absolute; right: 62px; bottom: 26px; z-index: 20;
        font-size: 10px; letter-spacing: 2px; color: rgba(0, 136, 170, 0.75);
        pointer-events: none;
    }

    #done-note {
        position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);
        z-index: 60; font-size: 12px; letter-spacing: 3px; color: #0088aa;
        display: none;
    }

    /* fade the whole HUD out when the sequence finishes */
    body.done #wrap { opacity: 0; transition: opacity 0.45s ease; }
    #wrap { position: absolute; inset: 0; }
</style>
</head>
<body>
<div id="wrap">
    <canvas id="reactor"></canvas>
    <div id="grid"></div>

    <div class="corner c-tl"></div><div class="corner c-tr"></div>
    <div class="corner c-bl"></div><div class="corner c-br"></div>

    <div class="hud" id="id-block">
        <div class="big">J.A.R.V.I.S</div>
        <div class="dim">STARK INDUSTRIES &nbsp;//&nbsp; MARK LIV</div>
        <div class="dim">OS v7.4 &nbsp;·&nbsp; BUILD 2026.09</div>
    </div>

    <div class="hud" id="stat-block">
        <div><span class="k">DESIGNATION&nbsp; </span><span class="v">PENDING</span></div>
        <div><span class="k">CORE&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="v">ARC-VII</span></div>
        <div><span class="k">STATUS&nbsp; &nbsp; &nbsp; &nbsp;</span><span class="v" id="stat-main">BOOTING</span></div>
        <div><span class="k">OUTPUT&nbsp; &nbsp; &nbsp; &nbsp;</span><span class="v" id="stat-out">0.00 GJ/s</span></div>
    </div>

    <div class="hud tele" id="tele-l"></div>
    <div class="hud tele" id="tele-r"></div>

    <div id="bootlog"></div>

    <div id="boot-bar">
        <div class="lbl"><span id="boot-cmd">SYSTEM BOOT</span><span class="v" id="boot-pct">0%</span></div>
        <div class="track"><div class="fill" id="boot-fill"></div></div>
    </div>

    <div id="skip-note">CLICK TO POWER AUDIO · ESC TO SKIP</div>
    <div id="done-note">SEQUENCE COMPLETE — YOU MAY CLOSE THIS TAB</div>
</div>
<div id="crt"></div>
<div id="vignette"></div>

<script>
(function () {
    'use strict';

    // ── canvas setup ─────────────────────────────────────────────────────
    var canvas = document.getElementById('reactor');
    var ctx = canvas.getContext('2d');
    var W = 0, H = 0, CX = 0, CY = 0, R = 0;
    var DPR = Math.min(1.5, window.devicePixelRatio || 1);

    function resize() {
        W = window.innerWidth; H = window.innerHeight;
        canvas.width = W * DPR; canvas.height = H * DPR;
        canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        CX = W / 2; CY = H * 0.46;
        R = Math.min(W, H) * 0.21;
    }
    window.addEventListener('resize', resize);
    resize();

    function col(rgb, a) {
        return 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + a + ')';
    }
    var CYAN = [0, 216, 255], DEEP = [0, 168, 204], ORANGE = [255, 102, 0],
        WHITE = [200, 246, 255], GREEN = [0, 255, 170];

    // ── drifting particles ───────────────────────────────────────────────
    var parts = [];
    for (var i = 0; i < 70; i++) {
        parts.push({
            x: Math.random(), y: Math.random(),
            s: 0.6 + Math.random() * 1.8,
            v: 0.008 + Math.random() * 0.03,
            a: 0.12 + Math.random() * 0.4,
            ph: Math.random() * 6.28
        });
    }

    // ── boot progress (drives the reactor scale-up and the bar) ─────────
    var T0 = performance.now();
    var BOOT_LEN = 7600;               // ms until the reactor is fully online
    function bootP(now) {
        var p = Math.min(1, (now - T0) / BOOT_LEN);
        return 1 - Math.pow(1 - p, 2.4);   // ease-out: fast rise, gentle settle
    }

    // ── sound design — the JARVIS boot soundtrack ─────────────────────────
    // Everything is synthesized with the Web Audio API: no files, no network,
    // works on file:// in every Chromium browser. Browsers block autoplay
    // until the user interacts, so the first click/keypress both powers the
    // audio on AND skips nothing — the sequence keeps running.
    var SND = (function () {
        var ctx = null, master = null, humOsc = null, humGain = null,
            humOsc2 = null, humLfo = null, started = false, dead = false;
        // The signature track: the real soundtrack embedded as base64 (see
        // __SIGNATURE_TRACK__). Present → it IS the boot sound and the
        // synthesised elements duck under it; absent → synthesised only.
        var SIG = "__SIGNATURE_TRACK__";
        var sigEl = null;

        function power() {
            if (started || dead) return;
            started = true;
            try {
                var AC = window.AudioContext || window.webkitAudioContext;
                if (!AC) return;
                ctx = new AC();
                master = ctx.createGain();
                master.gain.value = 0.55;
                master.connect(ctx.destination);
                if (SIG) playSignature();
                bootHum();
                if (!SIG) powerSwell();       // track carries the swell itself
                if (ctx.state === 'suspended') ctx.resume();
            } catch (e) { dead = true; }
        }

        // The user's signature clip, decoded and played once through the
        // master bus. An <audio> element keeps the mp3 decode in the browser's
        // own hands (smaller and more reliable than a hand-rolled mp3 decoder);
        // it routes into the WebAudio graph so ducking stays in one place.
        function playSignature() {
            try {
                sigEl = new Audio('data:audio/mpeg;base64,' + SIG);
                sigEl.crossOrigin = 'anonymous';
                var src = ctx.createMediaElementSource(sigEl);
                var g = ctx.createGain();
                g.gain.value = 0.9;
                src.connect(g); g.connect(master);
                sigEl.play().catch(function () {});
            } catch (e) { sigEl = null; }
        }

        function duckSignature(level, backAfterSec) {
            if (!sigEl) return;
            try {
                var v = sigEl.volume;
                sigEl.volume = level;
                if (backAfterSec)
                    setTimeout(function () {
                        if (sigEl) sigEl.volume = v;
                    }, backAfterSec * 1000);
            } catch (e) {}
        }

        // Deep arc-reactor hum: two detuned low sines through a low-pass,
        // with a slow LFO breathing on the gain — the standing sound of the
        // whole sequence.
        function bootHum() {
            humGain = ctx.createGain();
            humGain.gain.value = 0.0;
            var lp = ctx.createBiquadFilter();
            lp.type = 'lowpass'; lp.frequency.value = 220; lp.Q.value = 0.8;
            humOsc  = ctx.createOscillator(); humOsc.type  = 'sine';
            humOsc.frequency.value = 48;
            humOsc2 = ctx.createOscillator(); humOsc2.type = 'sine';
            humOsc2.frequency.value = 55.5;              // detune = slow beating
            var lfoGain = ctx.createGain(); lfoGain.gain.value = 0.035;
            humLfo = ctx.createOscillator(); humLfo.frequency.value = 0.5;
            humLfo.connect(lfoGain); lfoGain.connect(humGain.gain);
            humOsc.connect(lp); humOsc2.connect(lp); lp.connect(humGain);
            humGain.connect(master);
            humOsc.start(); humOsc2.start(); humLfo.start();
            humGain.gain.linearRampToValueAtTime(0.16, ctx.currentTime + 2.2);
        }

        // Power-up: rising filtered saw + sub-sine glide, the reactor spinning
        // up over the first seconds.
        function powerSwell() {
            var t = ctx.currentTime;
            var o = ctx.createOscillator(); o.type = 'sawtooth';
            o.frequency.setValueAtTime(30, t);
            o.frequency.exponentialRampToValueAtTime(160, t + 3.2);
            var f = ctx.createBiquadFilter(); f.type = 'lowpass';
            f.frequency.setValueAtTime(120, t);
            f.frequency.exponentialRampToValueAtTime(900, t + 3.2);
            var g = ctx.createGain();
            g.gain.setValueAtTime(0.0001, t);
            g.gain.exponentialRampToValueAtTime(0.20, t + 1.6);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 4.2);
            var sub = ctx.createOscillator(); sub.type = 'sine';
            sub.frequency.setValueAtTime(24, t);
            sub.frequency.exponentialRampToValueAtTime(55, t + 3.4);
            var sg = ctx.createGain();
            sg.gain.setValueAtTime(0.0001, t);
            sg.gain.exponentialRampToValueAtTime(0.24, t + 1.8);
            sg.gain.exponentialRampToValueAtTime(0.0001, t + 4.4);
            o.connect(f); f.connect(g); g.connect(master);
            sub.connect(sg); sg.connect(master);
            o.start(t); o.stop(t + 4.5); sub.start(t); sub.stop(t + 4.5);
        }

        // Short interface blip when a boot-log line lands; warning lines get
        // a lower, sharper tone.
        function lineDone(warn) {
            if (!ctx || dead) return;
            var t = ctx.currentTime;
            var o = ctx.createOscillator(); o.type = 'sine';
            o.frequency.setValueAtTime(warn ? 620 : 1500, t);
            o.frequency.exponentialRampToValueAtTime(warn ? 300 : 880, t + 0.07);
            var g = ctx.createGain();
            g.gain.setValueAtTime(warn ? 0.10 : 0.075, t);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
            o.connect(g); g.connect(master);
            o.start(t); o.stop(t + 0.12);
        }

        // Rising 'systems coming online' sweep mid-boot.
        function riseSweep() {
            if (!ctx || dead) return;
            var t = ctx.currentTime;
            var o = ctx.createOscillator(); o.type = 'triangle';
            o.frequency.setValueAtTime(180, t);
            o.frequency.exponentialRampToValueAtTime(1400, t + 1.1);
            var g = ctx.createGain();
            g.gain.setValueAtTime(0.0001, t);
            g.gain.exponentialRampToValueAtTime(0.08, t + 0.5);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 1.3);
            o.connect(g); g.connect(master);
            o.start(t); o.stop(t + 1.35);
        }

        // British system voice, preferred in JARVIS order.
        function pickVoice() {
            var vs = window.speechSynthesis ? speechSynthesis.getVoices() : [];
            var prefs = [
                /daniel/i, /google uk english male/i, /ryan/i, /george/i,
                /arthur/i, /oliver/i
            ];
            for (var i = 0; i < prefs.length; i++)
                for (var j = 0; j < vs.length; j++)
                    if (prefs[i].test(vs[j].name)) return vs[j];
            for (var k = 0; k < vs.length; k++)
                if (/en[-_]GB/i.test(vs[k].lang)) return vs[k];
            for (var m = 0; m < vs.length; m++)
                if (/^en/i.test(vs[m].lang)) return vs[m];
            return vs[0] || null;
        }

        // The greeting: spoken when every system reports nominal.
        function greeting() {
            if (dead || !window.speechSynthesis) return false;
            try {
                var h = new Date().getHours();
                var day = h < 12 ? 'morning' : (h < 18 ? 'afternoon' : 'evening');
                var u = new SpeechSynthesisUtterance(
                    'Good ' + day + ', sir. All systems are now online.');
                var v = pickVoice();
                if (v) u.voice = v;
                u.lang = (v && v.lang) || 'en-GB';
                u.pitch = 0.92; u.rate = 0.95; u.volume = 0.95;
                // duck the hum AND the signature track under the voice
                if (humGain && ctx) {
                    humGain.gain.cancelScheduledValues(ctx.currentTime);
                    humGain.gain.linearRampToValueAtTime(0.05, ctx.currentTime + 0.3);
                    humGain.gain.linearRampToValueAtTime(0.14, ctx.currentTime + u.text.length * 0.075 + 1.2);
                }
                duckSignature(0.25, u.text.length * 0.075 + 1.2);
                speechSynthesis.speak(u);
                return true;
            } catch (e) { return false; }
        }

        // Completion: three-note rising motif + soft boom — the 'JARVIS is
        // online' jingle. If no speech voice exists this stands in for it.
        function online() {
            if (!ctx || dead) return;
            var t = ctx.currentTime;
            [523.25, 659.25, 783.99].forEach(function (f, i) {   // C5 E5 G5
                var o = ctx.createOscillator(); o.type = 'sine';
                o.frequency.value = f;
                var g = ctx.createGain();
                var st = t + i * 0.16;
                g.gain.setValueAtTime(0.0001, st);
                g.gain.exponentialRampToValueAtTime(0.16, st + 0.03);
                g.gain.exponentialRampToValueAtTime(0.0001, st + 0.9);
                o.connect(g); g.connect(master);
                o.start(st); o.stop(st + 1.0);
            });
            var b = ctx.createOscillator(); b.type = 'sine';
            b.frequency.setValueAtTime(70, t);
            b.frequency.exponentialRampToValueAtTime(38, t + 0.8);
            var bg = ctx.createGain();
            bg.gain.setValueAtTime(0.0001, t);
            bg.gain.exponentialRampToValueAtTime(0.30, t + 0.06);
            bg.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
            b.connect(bg); bg.connect(master);
            b.start(t); b.stop(t + 1.2);
            // fade the reactor hum out over the close
            if (humGain) {
                humGain.gain.cancelScheduledValues(t);
                humGain.gain.setValueAtTime(humGain.gain.value, t);
                humGain.gain.linearRampToValueAtTime(0.0, t + 2.4);
            }
            if (!greeting()) {
                // no voice available — extend the motif so it still lands
                [783.99, 1046.5].forEach(function (f, i) {
                    var o = ctx.createOscillator(); o.type = 'sine';
                    o.frequency.value = f;
                    var g = ctx.createGain();
                    var st = t + 0.55 + i * 0.22;
                    g.gain.setValueAtTime(0.0001, st);
                    g.gain.exponentialRampToValueAtTime(0.14, st + 0.03);
                    g.gain.exponentialRampToValueAtTime(0.0001, st + 1.1);
                    o.connect(g); g.connect(master);
                    o.start(st); o.stop(st + 1.2);
                });
            }
        }

        function silence() {
            dead = true;
            try {
                if (sigEl) { sigEl.pause(); sigEl = null; }
                if (humGain && ctx) {
                    humGain.gain.cancelScheduledValues(ctx.currentTime);
                    humGain.gain.setValueAtTime(humGain.gain.value, ctx.currentTime);
                    humGain.gain.linearRampToValueAtTime(0.0, ctx.currentTime + 0.15);
                }
                if (window.speechSynthesis) speechSynthesis.cancel();
                if (ctx) setTimeout(function () { try { ctx.close(); } catch (e) {} }, 250);
            } catch (e) {}
        }

        // Autoplay unlocking: Chrome blocks audio until an interaction, so
        // every click/keypress (re)tries powering the soundtrack — power()
        // guards itself, so retries are free.
        function unlock() { power(); }
        window.addEventListener('pointerdown', unlock, { passive: true });
        window.addEventListener('keydown', unlock);
        if (window.speechSynthesis)
            speechSynthesis.onvoiceschanged = function () {};   // warm the cache

        return {
            lineDone: lineDone,
            riseSweep: riseSweep,
            online: online,
            silence: silence
        };
    })();

    // ── the reactor ──────────────────────────────────────────────────────
    function drawReactor(now) {
        var t = (now - T0) / 1000;
        var p = bootP(now);
        var r = R * (0.12 + 0.88 * p);
        var online = p >= 1;

        ctx.clearRect(0, 0, W, H);

        // particles first (behind everything)
        for (var i = 0; i < parts.length; i++) {
            var pt = parts[i];
            pt.y -= pt.v / 60;
            if (pt.y < -0.02) { pt.y = 1.02; pt.x = Math.random(); }
            var tw = pt.a * (0.6 + 0.4 * Math.sin(t * 2 + pt.ph));
            ctx.fillStyle = col(CYAN, tw);
            ctx.fillRect(pt.x * W, pt.y * H, pt.s, pt.s);
        }

        // atmosphere — two soft radial bodies of light
        for (var g = 0; g < 2; g++) {
            var gr = r * (g === 0 ? 1.55 : 0.85);
            var grad = ctx.createRadialGradient(CX, CY, 0, CX, CY, gr);
            var base = g === 0 ? 0.16 : 0.34;
            var boost = online ? (0.10 + 0.06 * Math.sin(t * 2.1)) : 0;
            grad.addColorStop(0.00, col(CYAN, base + boost));
            grad.addColorStop(0.45, col(DEEP, base * 0.5 + boost));
            grad.addColorStop(1.00, col(CYAN, 0));
            ctx.fillStyle = grad;
            ctx.beginPath(); ctx.arc(CX, CY, gr, 0, 6.2832); ctx.fill();
        }

        // radar sweep wedge
        var sweep = t * 0.9;
        ctx.beginPath();
        ctx.moveTo(CX, CY);
        ctx.arc(CX, CY, r * 1.32, sweep, sweep + 0.85);
        ctx.closePath();
        ctx.fillStyle = col(CYAN, 0.05);
        ctx.fill();

        // outer tick ring — every 4th tick longer and brighter
        for (var k = 0; k < 48; k++) {
            var a = (k / 48) * 6.2832 - t * 0.12;
            var long = (k % 4 === 0);
            var r1 = r * 1.06, r2 = r * (long ? 1.16 : 1.11);
            var al = (long ? 0.55 : 0.25) * (0.7 + 0.3 * Math.sin(t * 3 - k * 0.35));
            ctx.strokeStyle = col(CYAN, al * p);
            ctx.lineWidth = long ? 1.6 : 1;
            ctx.beginPath();
            ctx.moveTo(CX + Math.cos(a) * r1, CY + Math.sin(a) * r1);
            ctx.lineTo(CX + Math.cos(a) * r2, CY + Math.sin(a) * r2);
            ctx.stroke();
        }

        // counter-rotating arc segments — the signature Iron Man rings
        var rings = [
            { rr: 1.00, span: 96,  n: 2, spd:  0.9, dir:  1, w: 2.6, a: 0.85 },
            { rr: 0.90, span: 56,  n: 3, spd:  1.5, dir: -1, w: 1.6, a: 0.50 },
            { rr: 0.79, span: 148, n: 1, spd:  0.6, dir:  1, w: 1.3, a: 0.35 },
            { rr: 0.64, span: 58,  n: 4, spd:  1.1, dir: -1, w: 1.1, a: 0.28 }
        ];
        for (var ri = 0; ri < rings.length; ri++) {
            var rg = rings[ri];
            var rad = r * rg.rr;
            var spd = rg.spd * (online ? 1.5 : (0.35 + p));
            var base = (t * spd * rg.dir * 42) % 360;
            ctx.lineWidth = rg.w * Math.max(0.7, r / 190);
            for (var s = 0; s < rg.n; s++) {
                var a0 = (base + s * (360 / rg.n)) * 0.0174533;
                var a1 = a0 + rg.span * 0.0174533;
                var ac = ctx.createLinearGradient(
                    CX + Math.cos(a0) * rad, CY + Math.sin(a0) * rad,
                    CX + Math.cos(a1) * rad, CY + Math.sin(a1) * rad);
                ac.addColorStop(0, col(CYAN, 0));
                ac.addColorStop(0.25, col(CYAN, rg.a * p));
                ac.addColorStop(0.75, col(WHITE, rg.a * p));
                ac.addColorStop(1, col(CYAN, 0));
                ctx.strokeStyle = ac;
                ctx.beginPath();
                ctx.arc(CX, CY, rad, a0, a1);
                ctx.stroke();
            }
        }

        // cross-bars through the reactor, broken around the core
        var gap = r * 0.46, barW = r * 1.34;
        ctx.fillStyle = col(DEEP, 0.5 * p);
        ctx.fillRect(CX - barW, CY - 1.6, barW - gap, 3.2);
        ctx.fillRect(CX + gap, CY - 1.6, barW - gap, 3.2);
        ctx.fillRect(CX - 1.6, CY - barW, 3.2, barW - gap);
        ctx.fillRect(CX - 1.6, CY + gap, 3.2, barW - gap);

        // inner coil ring (dashed, slow)
        ctx.save();
        ctx.setLineDash([6, 9]);
        ctx.lineDashOffset = -t * 14;
        ctx.strokeStyle = col(DEEP, 0.5 * p);
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(CX, CY, r * 0.545, 0, 6.2832); ctx.stroke();
        ctx.restore();

        // core disc
        var coreR = r * 0.40;
        var cg = ctx.createRadialGradient(CX, CY, 0, CX, CY, coreR);
        cg.addColorStop(0, col(WHITE, 0.85 * p));
        cg.addColorStop(0.35, col(CYAN, 0.35 * p));
        cg.addColorStop(1, col(DEEP, 0.06 * p));
        ctx.fillStyle = cg;
        ctx.beginPath(); ctx.arc(CX, CY, coreR, 0, 6.2832); ctx.fill();

        // coil segments around the core (8 small coils, like the real one)
        for (var c = 0; c < 8; c++) {
            var ca = (c / 8) * 6.2832 + 0.3927 + t * 0.05;
            var crx = CX + Math.cos(ca) * r * 0.47;
            var cry = CY + Math.sin(ca) * r * 0.47;
            ctx.save();
            ctx.translate(crx, cry); ctx.rotate(ca + 1.5708);
            ctx.strokeStyle = col(WHITE, 0.5 * p);
            ctx.lineWidth = 2.2;
            ctx.beginPath(); ctx.moveTo(-4.5, 0); ctx.lineTo(4.5, 0); ctx.stroke();
            ctx.strokeStyle = col(DEEP, 0.4 * p);
            ctx.lineWidth = 1;
            ctx.strokeRect(-4.5, -5, 9, 10);
            ctx.restore();
        }

        // the triangle — pulses; during boot it "charges" (spins up, snaps in)
        var wob = Math.sin(t * 1.3) * 0.05;
        var spin = online ? 0 : (1 - p) * (1 - p) * 4.2;
        var tr = r * 0.265 * (0.6 + 0.4 * Math.min(1, p * 1.4));
        ctx.save();
        ctx.translate(CX, CY);
        ctx.rotate(wob + spin);
        ctx.lineJoin = 'round';
        ctx.shadowColor = col(CYAN, 0.9);
        ctx.shadowBlur = 18 + (online ? 10 * Math.sin(t * 2.1) : 0);
        ctx.strokeStyle = col(CYAN, 0.95 * p);
        ctx.lineWidth = 3;
        ctx.beginPath();
        for (var v = 0; v < 3; v++) {
            var va = -1.5708 + v * 2.0944;
            var vx = Math.cos(va) * tr, vy = Math.sin(va) * tr;
            if (v === 0) ctx.moveTo(vx, vy); else ctx.lineTo(vx, vy);
        }
        ctx.closePath(); ctx.stroke();
        // inner filled triangle — arc-orange, the hot part
        ctx.shadowColor = col(ORANGE, 0.9);
        ctx.shadowBlur = online ? 22 : 8 * p;
        ctx.fillStyle = col(ORANGE, (online ? 0.85 : 0.5) * p);
        var tr2 = tr * 0.42;
        ctx.beginPath();
        for (var v2 = 0; v2 < 3; v2++) {
            var va2 = -1.5708 + v2 * 2.0944;
            var vx2 = Math.cos(va2) * tr2, vy2 = Math.sin(va2) * tr2;
            if (v2 === 0) ctx.moveTo(vx2, vy2); else ctx.lineTo(vx2, vy2);
        }
        ctx.closePath(); ctx.fill();
        ctx.restore();

        // white-hot centre dot
        var dot = online ? (0.65 + 0.35 * Math.sin(t * 5)) : p * 0.5;
        ctx.fillStyle = col(WHITE, dot);
        ctx.beginPath(); ctx.arc(CX, CY, 2.6, 0, 6.2832); ctx.fill();

        // horizontal scan line crossing the reactor
        var sy = CY + Math.sin(t * 0.7) * r * 0.85;
        var sg = ctx.createLinearGradient(CX - r * 1.4, 0, CX + r * 1.4, 0);
        sg.addColorStop(0, col(CYAN, 0));
        sg.addColorStop(0.5, col(CYAN, 0.30 * p));
        sg.addColorStop(1, col(CYAN, 0));
        ctx.fillStyle = sg;
        ctx.fillRect(CX - r * 1.4, sy - 0.8, r * 2.8, 1.6);
    }

    // ── boot log ─────────────────────────────────────────────────────────
    var LINES = [
        ['STARK OS 7.4 ................. KERNEL LOADED',        'ok'],
        ['ARC REACTOR .................. OUTPUT 3.2 GJ/s',      'ok'],
        ['NEURAL INTERFACE ............. SYNCED',               'ok'],
        ['HOLOGRAPHIC DISPLAY .......... CALIBRATED',           'ok'],
        ['AUDIO ARRAY .................. 8 CHANNELS LIVE',      'ok'],
        ['VISION SYSTEM ................ 2 SENSOR FEEDS',       'ok'],
        ['GEMINI LINK .................. HANDSHAKE ACCEPTED',   'ok'],
        ['SKILL MODULES ................ ALL DISCOVERED',       'ok'],
        ['MEMORY CORE .................. INDEX REBUILT',        'ok'],
        ['DEFENSE PROTOCOLS ............ ARMED',                'warn'],
        ['J.A.R.V.I.S .................. ONLINE',               'ok']
    ];

    var logEl = document.getElementById('bootlog');
    var fillEl = document.getElementById('boot-fill');
    var pctEl = document.getElementById('boot-pct');
    var cmdEl = document.getElementById('boot-cmd');
    var statEl = document.getElementById('stat-main');
    var outEl = document.getElementById('stat-out');

    var li = 0, ci = 0, curDiv = null, curTxt = null;
    var finished = false;

    function newLine(cls) {
        curDiv = document.createElement('div');
        curDiv.className = 'ln';
        curTxt = document.createElement('span');
        curDiv.appendChild(curTxt);
        if (cls === 'ok' || cls === 'warn') {
            var tag = document.createElement('span');
            tag.className = cls;
            tag.textContent = cls === 'ok' ? '  [ OK ]' : '  [ARM]';
            curDiv.appendChild(tag);
        }
        var caret = document.createElement('span');
        caret.className = 'caret'; caret.innerHTML = '&nbsp;';
        curDiv.appendChild(caret);
        if (logEl.lastChild && logEl.lastChild.querySelector) {
            var old = logEl.lastChild.querySelector('.caret');
            if (old) old.remove();
        }
        logEl.appendChild(curDiv);
    }

    function typeStep() {
        if (finished) return;
        if (li >= LINES.length) { finish(); return; }
        if (ci === 0) newLine(LINES[li][1]);
        var text = LINES[li][0];
        ci += 2;                                    // 2 chars per tick
        curTxt.textContent = text.slice(0, ci);
        var prog = (li + Math.min(1, ci / text.length)) / LINES.length;
        fillEl.style.width = (prog * 100).toFixed(1) + '%';
        pctEl.textContent = Math.round(prog * 100) + '%';
        cmdEl.textContent = LINES[li][0].split('.......')[0].trim();
        if (ci >= text.length) {
            li++; ci = 0;
            SND.lineDone(LINES[li - 1][1] === 'warn');
            if (li === Math.floor(LINES.length / 2)) SND.riseSweep();
            setTimeout(typeStep, 130);              // beat between lines
        } else {
            setTimeout(typeStep, 14);
        }
    }

    // ── side telemetry panels fill in as systems come online ────────────
    var TELE = {
        'tele-l': [
            ['POWER', 'value-out'],
            ['COOLANT', 'nominal'],
            ['FLYING CAP', 'unavailable'],
            ['TARGETING', 'standby'],
            ['CALC. MASS', '0.84 g/cc']
        ],
        'tele-r': [
            ['PERIPHERALS', 'linked'],
            ['NETWORK', 'encrypted'],
            ['SENSORS', 'calibrated'],
            ['UPLINK', 'gemini-live'],
            ['LOCATION', 'residence']
        ]
    };
    function buildTele() {
        ['tele-l', 'tele-r'].forEach(function (id) {
            var el = document.getElementById(id);
            TELE[id].forEach(function (row) {
                var d = document.createElement('div');
                d.innerHTML = '<span class="k">' + row[0] +
                    '</span> <span class="v" data-v="' + row[1] + '">--</span>';
                el.appendChild(d);
            });
        });
    }
    function jitterTelemetry() {
        var out = document.querySelector('[data-v="value-out"]');
        if (out) {
            var v = (2.6 + Math.random() * 0.9);
            out.textContent = v.toFixed(2) + ' GJ/s';
            out.className = 'v hi';
        }
        outEl.textContent = (2.6 + Math.random() * 0.9).toFixed(2) + ' GJ/s';
    }
    function revealTelemetry() {
        buildTele();
        document.getElementById('tele-l').classList.add('live');
        document.getElementById('tele-r').classList.add('live');
        setInterval(jitterTelemetry, 700);
        jitterTelemetry();
    }
    setTimeout(revealTelemetry, 2600);

    // ── finish / skip ────────────────────────────────────────────────────
    function finish() {
        if (finished) return;
        finished = true;
        statEl.textContent = 'ONLINE';
        statEl.style.color = '#00ffaa';
        fillEl.style.width = '100%';
        pctEl.textContent = '100%';
        cmdEl.textContent = 'ALL SYSTEMS NOMINAL';
        SND.online();                               // chime + JARVIS greeting
        // The greeting now plays natively in the app (see ui._BootAudio), so
        // the page only stands in when opened standalone (PREVIEW, __main__).
        setTimeout(function () {
            document.body.classList.add('done');
            // Wait out the greeting (~3.5 s) before closing, so it is never
            // cut off mid-sentence when this page is opened on its own.
            try { window.close(); } catch (e) { /* popup blockers */ }
            setTimeout(function () {
                var n = document.getElementById('done-note');
                if (n) n.style.display = 'block';
            }, 500);
        }, 4300);
    }
    setTimeout(finish, 12000);                      // auto-close (past the greeting)
    // Clicking no longer skips — it POWERS THE SOUNDTRACK (browser autoplay
    // rules forbid audio before interaction). ESC, or the corner note, skips.
    function skip() {
        SND.silence();                              // skip = mute everything
        document.body.classList.add('done');
        try { window.close(); } catch (e) {}
    }
    window.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') skip(); });
    var _skipNote = document.getElementById('skip-note');
    if (_skipNote) {
        _skipNote.style.pointerEvents = 'auto';
        _skipNote.style.cursor = 'pointer';
        _skipNote.addEventListener('click', function (ev) { ev.stopPropagation(); skip(); });
        _skipNote.textContent = 'CLICK TO POWER AUDIO · ESC / HERE TO SKIP';
    }

    // ── main loop ────────────────────────────────────────────────────────
    setTimeout(typeStep, 500);
    // Auto-power the audio: when opened from the app (not double-clicked), the
    // ?audio=1 query marks a user-gesture context already granted, and several
    // Chromium builds still allow programmatic AudioContext start from it.
    // The click-to-power fallback stays for strict browsers.
    try {
        if (new URLSearchParams(location.search).get('audio') === '1')
            SND.power();
    } catch (e) {}
    // Light-footed main loop: the boot animation still looks smooth, but the
    // tab costs a fraction of the CPU — draws are capped at ~30 fps, paused
    // completely when the tab is hidden or the boot has finished, instead of
    // redrawing every display refresh forever.
    var _lastDraw = 0;
    (function loop(now) {
        requestAnimationFrame(loop);
        now = now || performance.now();
        if (document.body.classList.contains('done')) return;   // boot done — stop drawing
        if (document.hidden) return;                            // hidden tab — zero cost
        if (now - _lastDraw < 33) return;                       // ~30 fps cap
        _lastDraw = now;
        drawReactor(now);
    })(performance.now());
})();
</script>
</body>
</html>"""

    # Embed the signature track (base64) without f-string brace pain: a plain
    # replace on a placeholder the JS reads. Empty string = no clip, and the
    # synthesised soundtrack covers the sequence as before.
    html = html.replace("__SIGNATURE_TRACK__", _signature_track_b64())
    return html


def show_startup() -> str:
    """Display the JARVIS startup animation in the default browser."""
    try:
        html_content = generate_startup_html()

        temp_dir = Path(tempfile.gettempdir())
        html_file = temp_dir / "jarvis_startup.html"
        html_file.write_text(html_content, encoding="utf-8")

        try:
            from core.opera import open_url
            if not open_url(f"file:///{html_file.as_posix()}?audio=1"):
                webbrowser.open(f"file:///{html_file.as_posix()}?audio=1")
        except Exception:
            webbrowser.open(f"file:///{html_file.as_posix()}?audio=1")

        return "✅ JARVIS startup sequence initiated"
    except Exception as e:
        return f"❌ Startup display failed: {e}"


if __name__ == "__main__":
    show_startup()
