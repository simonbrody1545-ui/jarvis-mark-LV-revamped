"""Dynamic gesture recognition — what a hand is DOING over time.

The shape engine (core.hand_shapes) reads one frame: fist, point, web-shooter.
This module reads a WINDOW of frames: a hello wave, a swipe, a clap, a push.
JARVIS-level eye contact needs both — a wave is not a pose, it is a motion.

Method: every analysed frame appends one compact sample to a short history —

    (time, palm x, palm y, apparent size, open-finger count, second-hand distance)

— and a set of cheap detectors look for temporal patterns in that window:

    wave        x oscillates around its mean while y stays put
    swipe_*     one decisive directional travel, then stillness
    push/pull   apparent size grows/shrinks past 1.35x / below 0.75x
    come_here   two or more pull cycles in a row
    circle      the palm's bearing around its own centroid keeps turning
    fist_pump   open <-> closed hand toggling twice
    raise_hand  the palm travels up into the top of the frame
    clap        two hands, the gap between them collapsing to almost nothing
    zoom        push/pull while BOTH hands are up (the pinch-zoom motion)

Every detector is arithmetic over the history — no model, no per-frame cost
beyond a tuple append, far below 1 ms. All decisions are made from the
SAMPLES' own timestamps (never the wall clock), so the module is deterministic
and the synthetic corpus in core.dynamic_corpus can examine it honestly.

Cooldowns: each label can fire again only after its own quiet period, and a
global motion cooldown keeps one gesture family from crowding out the others.
"""
from __future__ import annotations

import math
import time

# ── the window ────────────────────────────────────────────────────────────────
_WIN = 2.2          # seconds of history a detector may look at
_MAX = 132          # hard cap on samples (~60 Hz x 2.2 s), memory bound

# ── thresholds (all in normalised-image units unless noted) ──────────────────
_WAVE_MIN_VAR   = 0.050     # total x travel across the window
_WAVE_Y_MAX     = 0.050     # y may not wander more than this (a wave is level)
_WAVE_CYCLES    = 2         # mean crossings needed
_SWIPE_DIST     = 0.17      # decisive travel
_SWIPE_TIME     = 1.0       # ...within this many seconds
_SCALE_PUSH     = 1.33      # apparent-size growth = pushing toward the lens
_SCALE_PULL     = 0.76      # apparent-size shrink = pulling away
_CYCLE_MIN      = 2         # pull cycles that make "come here"
_CIRCLE_RAD     = 4.2       # accumulated bearing (rad) ~ 240 degrees
_PUMP_FLIPS     = 2         # open->closed transitions
_OPEN_N         = 3         # fingers up = open hand
_CLOSED_N       = 1         # fingers up = closed hand
_RAISE_TRAVEL   = 0.13      # upward travel
_RAISE_TOP      = 0.40      # and finish in the top two fifths
_CLAP_NEAR      = 0.045     # palm gap that counts as contact
_CLAP_FAR       = 0.09      # gap it must start from

# Cooldowns per label, seconds — a wave repeats fast, a clap should not.
_COOLDOWN = {
    "wave": 4.0, "swipe_left": 2.0, "swipe_right": 2.0,
    "push": 2.5, "pull": 2.5, "come_here": 4.0, "circle": 3.0,
    "fist_pump": 3.0, "raise_hand": 4.0, "clap": 2.5, "zoom": 2.5,
}
_MOTION_QUIET = 1.2         # after any motion, shapes stay quiet this long


def _dist(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


class MotionTracker:
    """Accumulates per-frame hand samples and names the motion they make.

    feed() with one sample per analysed frame; update() after each feed (or
    on a timer) returns a freshly-triggered label or "". `now` defaults to
    the newest sample's own timestamp, keeping the class deterministic.
    """

    def __init__(self):
        self._hist: list[tuple] = []      # (t, cx, cy, size, n_open, second)
        self._last_fire: dict[str, float] = {}
        self._last_any = 0.0
        self.active = ""                  # label currently being performed
        self.active_at = 0.0

    # ── state ────────────────────────────────────────────────────────────
    def reset(self) -> None:
        self._hist.clear()
        self._last_fire.clear()
        self._last_any = 0.0
        self.active = ""
        self.active_at = 0.0

    def feed(self, t: float, cx: float, cy: float, size: float,
             n_open: int, second: float = 0.0) -> None:
        """One analysed frame: (timestamp, palm x, palm y, apparent size,
        open-finger count, other hand's palm distance — 0 if none)."""
        self._hist.append((float(t), float(cx), float(cy),
                           max(1e-4, float(size)), int(n_open), float(second)))
        if len(self._hist) > _MAX:
            del self._hist[:len(self._hist) - _MAX]

    # ── detection ────────────────────────────────────────────────────────
    def update(self, now: float | None = None) -> str:
        if not self._hist:
            return ""
        if now is None:
            now = self._hist[-1][0]
        t0 = now - _WIN
        h = [s for s in self._hist if s[0] >= t0]
        if len(h) < 6:
            self.active = ""
            return ""
        ts   = [s[0] for s in h]
        xs   = [s[1] for s in h]
        ys   = [s[2] for s in h]
        sz   = [s[3] for s in h]
        no   = [s[4] for s in h]
        sec  = [s[5] for s in h]
        span = max(ts[-1] - ts[0], 1e-3)
        if span < 0.35:                    # need a real window, not a blink
            self.active = ""
            return ""

        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        dx = xs[-1] - xs[0]
        dy = ys[-1] - ys[0]
        span_x = max(xs) - min(xs)
        span_y = max(ys) - min(ys)

        label = ""
        if self._is_wave(xs, ys, span_x, span_y):
            label = "wave"
        elif sec[-1] > 0.0:
            # Two hands up. A clap COLLAPSES the gap (from wide to touching);
            # a zoom keeps the hands close while the size grows.
            if max(sec) >= _CLAP_FAR and sec[-1] <= _CLAP_NEAR:
                label = "clap"
            elif sec[-1] <= _CLAP_FAR and self._size_ratio(sz) >= _SCALE_PUSH:
                label = "zoom"
        # Circle outranks swipe: a circle's straight-line travel across the
        # window can out-measure its vertical span (the turn truncates at the
        # window edge), and calling that a swipe steals every circle.
        if not label and self._is_circle(xs, ys, cx, cy):
            label = "circle"
        if not label and self._is_swipe(dx, span_x, span_y, xs, ts):
            label = "swipe_right" if dx > 0 else "swipe_left"
        if not label and self._is_raise(dy, ys):
            label = "raise_hand"
        if not label:
            if sec[-1] > 0.0:
                # two hands, no clap/zoom — the gap envelope only
                pulls = self._pull_cycles(sz)
                ratio = self._size_ratio(sz)
                if pulls >= _CYCLE_MIN and ratio <= 1.0:
                    label = "come_here"
                elif ratio >= _SCALE_PUSH:
                    label = "push"
                elif ratio <= _SCALE_PULL:
                    label = "pull"
            else:
                # one hand: size oscillation is "come here" (>= 2 shrink-regrow
                # cycles); a one-way envelope is push/pull; finger toggling is
                # the fist pump. A pull must SETTLE low for half a second — the
                # way a real pull ends — which is exactly what a come-here dip
                # never does (it regrows at once).
                pulls = self._pull_cycles(sz)
                ratio = self._size_ratio(sz)
                settled = self._settled_low(sz, ts)
                if pulls >= _CYCLE_MIN:
                    label = "come_here"
                elif pulls == 1:
                    # One dip-regrow done, the second still forming: every
                    # interim verdict here is wrong (the regrow reads as a
                    # push, the dip as a pull). A real push/pull is a ONE-WAY
                    # envelope — zero cycles — so hold the verdict instead.
                    pass
                elif settled and ratio <= _SCALE_PULL:
                    label = "pull"
                elif ratio >= _SCALE_PUSH:
                    label = "push"
                elif self._pump_flips(no, ts) >= _PUMP_FLIPS:
                    label = "fist_pump"

        if not label:
            self.active = ""
            return ""
        if not self._cooldown_ok(label, now):
            # still report what the window holds, for the HUD panel
            self.active = label
            self.active_at = now
            return ""
        self._last_fire[label] = now
        self._last_any = now
        self.active = label
        self.active_at = now
        return label

    def shape_quiet(self, now: float) -> bool:
        """True while a motion owns the floor — static-shape announcements
        hold their tongue so the wave is not drowned by open/closed chatter."""
        return (now - self._last_any) < _MOTION_QUIET

    # ── individual detectors ─────────────────────────────────────────────
    @staticmethod
    def _is_wave(xs, ys, span_x, span_y) -> bool:
        if span_x < _WAVE_MIN_VAR or span_y > _WAVE_Y_MAX:
            return False
        mean = sum(xs) / len(xs)
        crossings = 0
        prev_side = xs[0] >= mean
        for x in xs[1:]:
            side = x >= mean
            if side != prev_side:
                crossings += 1
                prev_side = side
        return crossings >= _WAVE_CYCLES

    @staticmethod
    def _is_swipe(dx, span_x, span_y, xs, ts) -> bool:
        # Decisive, horizontal-dominant travel — AND a still tail. A swipe
        # ENDS: the hand stops where it landed. A circle's first swing also
        # covers big horizontal distance, but it never stops moving, so the
        # still-tail requirement is what keeps every circle from being read
        # as a swipe halfway through.
        if abs(dx) < _SWIPE_DIST or abs(dx) <= span_y * 1.8:
            return False
        horizon = ts[-1] - 0.25
        tail = [x for x, t in zip(xs, ts) if t >= horizon]
        if not tail:
            return False
        return (max(tail) - min(tail)) < 0.045

    @staticmethod
    def _size_ratio(sz) -> float:
        return max(sz[-3:]) / max(min(sz[:5]), 1e-4)

    @staticmethod
    def _pull_cycles(sz) -> int:
        """Shrink-then-regrow cycles with REAL amplitude: the apparent size
        must dip at least 18% below its running peak, then regrow at least
        20% above the dip. Noise wobble of a few percent crosses neither
        bar — which is what keeps idle hands, taps and drifts silent (the
        mean-crossing version counted their jitter as cycles and fired
        come-here at everything)."""
        if len(sz) < 8:
            return 0
        peak = sz[0]
        trough = None
        cycles = 0
        for s in sz[1:]:
            if trough is None:
                if s >= peak * 0.82:        # still riding high
                    peak = max(peak, s)
                else:
                    trough = s              # a real dip begins
            else:
                if s < trough:
                    trough = s              # deeper still
                elif s >= trough * 1.20:    # decisive regrow
                    cycles += 1
                    trough = None
                    peak = s
        return cycles

    @staticmethod
    def _pump_flips(no, ts) -> int:
        """Open<->closed transitions that DWELL — both phases must last at
        least 0.18 s. Quick flickers (a tap, a half-formed gesture) never
        count, which is what keeps the negative class quiet."""
        if len(no) < 8:
            return 0
        # segment the finger counts into runs of open/closed
        segs: list[tuple[bool, float]] = []   # (is_open, duration)
        state = no[0] >= _OPEN_N
        seg_start = ts[0]
        for i in range(1, len(no)):
            cur = no[i] >= _OPEN_N
            if cur != state:
                segs.append((state, ts[i] - seg_start))
                state = cur
                seg_start = ts[i]
        segs.append((state, ts[-1] - seg_start))
        # transitions between two dwelling segments
        flips = 0
        for a, b in zip(segs, segs[1:]):
            if a[1] >= 0.18 and b[1] >= 0.18:
                flips += 1
        return flips // 2 if flips >= 2 else 0

    @staticmethod
    def _settled_low(sz, ts) -> bool:
        """The last 0.5 s of size stayed below 88% of the window's peak —
        the hand came close and STAYED close (a pull), rather than dipping
        and regrowing (come-here) or swelling (push)."""
        peak = max(sz)
        if peak <= 0:
            return False
        horizon = ts[-1] - 0.5
        tail = [s for s, t in zip(sz, ts) if t >= horizon]
        return bool(tail) and max(tail) < peak * 0.88

    @staticmethod
    def _is_circle(xs, ys, cx, cy) -> bool:
        if max(max(xs) - min(xs), max(ys) - min(ys)) < 0.08:
            return False
        total = 0.0
        prev = math.atan2(ys[0] - cy, xs[0] - cx)
        for x, y in zip(xs[1:], ys[1:]):
            a = math.atan2(y - cy, x - cx)
            d = a - prev
            if d > math.pi:
                d -= 2 * math.pi
            elif d < -math.pi:
                d += 2 * math.pi
            total += d
            prev = a
        return abs(total) >= _CIRCLE_RAD

    @staticmethod
    def _is_raise(dy, ys) -> bool:
        return (-dy) >= _RAISE_TRAVEL and min(ys) < _RAISE_TOP

    # ── cooldowns ────────────────────────────────────────────────────────
    def _cooldown_ok(self, label: str, now: float) -> bool:
        if now - self._last_any < _MOTION_QUIET and self.active != label:
            return False
        return now - self._last_fire.get(label, -1e9) >= _COOLDOWN.get(label, 2.5)


# What JARVIS says. The wave is a greeting — it deserves a greeting back.
ANNOUNCE = {
    "wave":        "Hello, sir — good to see you",
    "swipe_left":  "Swiping left",
    "swipe_right": "Swiping right",
    "push":        "Pushing me away",
    "pull":        "Pulling back",
    "come_here":   "Come here — on my way",
    "circle":      "Drawing a circle",
    "fist_pump":   "Fist pump — good news, I take it",
    "raise_hand":  "Hand raised — I'm listening",
    "clap":        "Clap — well done, sir",
    "zoom":        "Zooming",
}


def phrase(label: str) -> str:
    return ANNOUNCE.get(label, "")
