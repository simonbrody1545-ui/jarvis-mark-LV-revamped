"""The eye — camera vision with hands, gestures and object recognition.

Camera source: DroidCam is preferred when present (the phone becomes the
webcam), then any virtual camera, then the system default. Windows device
names come from DirectShow via pygrabber — cv2 alone cannot tell a DroidCam
from an OBS scene.

Tracking runs locally (MediaPipe Hands + Gesture Recognizer, CPU, a few ms
per frame at ~5 Hz — light enough to leave on all day). Openness/finger
states and named gestures (fist, palm, victory, thumbs up/down, point,
ILY) come from the model; nothing here uploads video — the ONLY thing that
ever leaves the machine is a single compressed snapshot, and only when the
user asks "what am I holding" (via actions/vision_scan.py) or holds a
thumbs-up at the camera. That snapshot goes to Gemini for one sentence,
like a quick glance — not a stream.
"""
from __future__ import annotations

import io
import threading
import time

from core import hand_shapes as _shapes
from core.dynamic_gestures import MotionTracker, phrase as _motion_phrase

# ── wake hook — main.py registers _check_hand_wake here ────────────────────
_wake_hook = None


def set_wake_hook(cb) -> None:
    """Register the callback that decides whether a held hand-sign wakes the
    assistant (hand-sign wake while asleep). Called from the analysis thread."""
    global _wake_hook
    _wake_hook = cb


def say_now(text: str) -> None:
    """Speak a line through the configured speaker bridge, if any."""
    if _say:
        try:
            _say(text)
        except Exception:
            pass

_CAM_LOCK = threading.Lock()
_cam_state = {
    "want": False,        # user/UI asked for the eye
    "running": False,
    "src_name": "",
    "src_kind": "",       # droidcam | virtual | default
    "err": "",
}

_last = {
    "frame": None,          # last raw BGR frame (numpy)
    "jpeg": None,           # annotated snapshot cache (bytes)
    "jpeg_at": 0.0,
    "hands": 0,
    "gesture": "",
    "fingers": 0,           # extended-finger count
    "object": "",
    "object_at": 0.0,
    "seen_at": 0.0,
}

_eye = None            # singleton VisionEye
_say = None            # injected: callable(str) — JARVIS's speaker bridge
_speak_direct = False  # True → the bridge speaks verbatim (no "Sir," added)

# Hand-shape state: what the hand is DOING, updated by _analyse().
_shape = {"label": "", "spoken": "", "last": "", "last_spoken": "",
          "at": 0.0, "spoken_at": 0.0, "scanning": False}


def set_speaker(cb) -> None:
    global _say, _speak_direct
    # main.py's bridge prepends "Sir, " — a shape label is one word and must
    # be spoken verbatim, so the eye knows which style it is getting.
    _speak_direct = bool(getattr(cb, "direct", False))
    _say = cb


def set_scanning(on: bool) -> None:
    """Raise/lower the SCANNING flag the HUD overlay reads."""
    _shape["scanning"] = bool(on)


def is_scanning() -> bool:
    return bool(_shape.get("scanning"))


# ── device discovery ─────────────────────────────────────────────────────────

def _devices() -> list[str]:
    """DirectShow input device names, best-effort (empty on failure)."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        return [n for n in FilterGraph().get_input_devices() if n]
    except Exception:
        return []


def _pick_source() -> tuple[int | None, str, str]:
    """(cv2 index, friendly name, kind). DroidCam first, then virtual cams,
    then the first DirectShow device, then the OS default (index None)."""
    names = _devices()
    for i, n in enumerate(names):
        if "droidcam" in n.lower():
            return i, n, "droidcam"
    for i, n in enumerate(names):
        if any(t in n.lower() for t in ("virtual", "obs", "streamlabs")):
            return i, n, "virtual"
    if names:
        return 0, names[0], "default"
    return None, "system default", "default"


def _open_camera(idx: int):
    """Open idx on the first backend that actually delivers a frame.
    OpenCV 5 on this machine refuses capture-by-index on DirectShow; MSMF
    works — so backends are tried in order and a backend only counts once
    a real frame comes back, not merely an open()."""
    import cv2
    for be in (cv2.CAP_MSMF, cv2.CAP_ANY, cv2.CAP_DSHOW):
        try:
            cap = cv2.VideoCapture(int(idx), be)
            if cap.isOpened():
                ret, _f = cap.read()
                if ret:
                    return cap
            try:
                cap.release()
            except Exception:
                pass
        except Exception:
            continue
    return None


# ── the eye ──────────────────────────────────────────────────────────────────

class VisionEye:
    """Owns the capture, the models and the low-rate poll loop."""

    def __init__(self):
        self._cap = None
        self._hands = None
        self._gest = None
        self._models_ok = False
        self._models_tried = False
        self._busy = threading.Lock()      # one inference at a time
        self._ident_busy = False           # one Gemini identify at a time
        self._thumbs_at = 0.0
        self._tick = 0
        self._loop_thread = None
        self._motion = MotionTracker()     # temporal gestures: wave, swipe, clap…

    # -- lifecycle ------------------------------------------------------------
    def start(self) -> tuple[bool, str]:
        with _CAM_LOCK:
            _cam_state["want"] = True
            if _cam_state["running"]:
                return True, _cam_state["src_name"]
        try:
            import cv2
        except Exception:
            self._fail("OpenCV is missing (pip install opencv-python)")
            return False, ""

        idx, name, kind = _pick_source()
        cap = None
        if idx is not None:
            cap = _open_camera(idx)
        if cap is None and idx != 0:
            cap = _open_camera(0)
            if cap.isOpened() if cap else False:
                name, kind = (name, kind) if idx == 0 else ("camera 0", "default")
        if cap is None:
            self._fail("no camera could be opened")
            return False, ""
        for _ in range(3):                 # let exposure settle
            cap.read()
        self._cap = cap
        with _CAM_LOCK:
            _cam_state.update(running=True, src_name=name, src_kind=kind, err="")
        self._ensure_models()
        if self._loop_thread is not None and self._loop_thread.is_alive():
            return True, name
        self._loop_thread = threading.Thread(target=self._loop, daemon=True,
                                             name="vision-eye")
        self._loop_thread.start()
        return True, name

    def stop(self) -> None:
        with _CAM_LOCK:
            _cam_state["want"] = False

    def _fail(self, msg: str) -> None:
        with _CAM_LOCK:
            _cam_state.update(running=False, err=msg)

    # -- models (lazy, once) ----------------------------------------------------
    def _ensure_models(self) -> None:
        if self._models_tried:
            return
        self._models_tried = True
        try:
            import mediapipe as mp
            from mediapipe.tasks.python import vision as mpv
            import urllib.request
            from pathlib import Path
            mdir = Path("state/models"); mdir.mkdir(parents=True, exist_ok=True)
            gp = mdir / "gesture_recognizer.task"
            hp = mdir / "hand_landmarker.task"
            if not gp.exists():
                urllib.request.urlretrieve(
                    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/"
                    "gesture_recognizer/float16/1/gesture_recognizer.task", gp)
            if not hp.exists():
                urllib.request.urlretrieve(
                    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
                    "hand_landmarker/float16/1/hand_landmarker.task", hp)
            base = mp.tasks.BaseOptions
            self._gest = mpv.GestureRecognizer.create_from_options(
                mpv.GestureRecognizerOptions(base_options=base(model_asset_path=str(gp)),
                                             running_mode=mpv.RunningMode.IMAGE,
                                             num_hands=2))
            self._hands = mpv.HandLandmarker.create_from_options(
                mpv.HandLandmarkerOptions(base_options=base(model_asset_path=str(hp)),
                                          running_mode=mpv.RunningMode.IMAGE,
                                          num_hands=2))
            self._models_ok = True
        except Exception as e:
            print(f"[Eye] models unavailable ({e}) — frames only")

    # -- the loop (5 Hz — plenty for gestures, cheap on CPU) --------------------
    def _loop(self):
        import cv2
        while True:
            with _CAM_LOCK:
                if not _cam_state["want"]:
                    break
            try:
                ok, frame = self._cap.read()
                if not ok or frame is None:
                    time.sleep(0.5)
                    continue
                small = cv2.resize(frame, (640, int(640 * frame.shape[0] / max(1, frame.shape[1]))))
                _last["frame"] = small
                _last["seen_at"] = time.time()
                self._tick += 1
                if self._models_ok and self._tick % 2 == 0 and self._busy.acquire(False):
                    try:
                        self._analyse(small)
                    finally:
                        self._busy.release()
                if self._tick % 24 == 0 and _last["hands"] > 0 and not self._ident_busy:
                    # every ~5 s with a hand in view: refresh "what is held"
                    threading.Thread(target=self.identify, daemon=True).start()
                # thumbs-up hold → speak the object unprompted
                if (_last["gesture"] == "Thumb_Up" and _last["object"]
                        and not self._ident_busy):
                    now = time.time()
                if self._thumbs_at == 0.0:
                    self._thumbs_at = now
                elif now - self._thumbs_at > 1.5:
                    self._thumbs_at = 0.0
                    if _say:
                        _say(f"Sir, you are holding {_last['object']}")
                else:
                    self._thumbs_at = 0.0
            except Exception:
                time.sleep(0.5)
        # teardown
        try:
            self._cap.release()
        except Exception:
            pass
        with _CAM_LOCK:
            _cam_state.update(running=False, src_name="")

    def _analyse(self, bgr) -> None:
        import cv2
        import numpy as np
        import mediapipe as mp
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        hres = self._hands.detect(img)
        n = len(hres.hand_landmarks or [])
        _last["hands"] = n
        ges = ""
        shape = ""
        if n:
            # Geometric shape first — it knows the mouse grip, which the
            # stock recogniser cannot name. Stock gestures are the fallback.
            try:
                shape = _shapes.classify(hres.hand_landmarks[0])
            except Exception:
                shape = ""
            if not shape:
                gres = self._gest.detect(img)
                if gres and gres.gestures:
                    top = gres.gestures[0][0]
                    if top.category_name and top.category_name != "None" and top.score > 0.55:
                        ges = top.category_name
            _last["fingers"] = self._count_fingers(hres)
        _last["gesture"] = ges

        # Shape bookkeeping + the spoken announcement. A NEW shape is spoken
        # once, with a cooldown so a wavering hand cannot chatter.
        now = time.time()
        label = shape or ges
        if label != _shape["last"]:
            _shape["last"] = label
            _shape["at"] = now
        sp = _shapes.spoken(shape) or (_shapes.spoken(ges) if ges else "")
        _shape["label"] = label
        _shape["spoken"] = sp

        # Hand-sign wake: the held-sign counter in main.py sees every label,
        # including "" (hand gone) so its counter resets properly.
        if _wake_hook is not None:
            try:
                _wake_hook(label)
            except Exception:
                pass

        # A NEW shape earns one line, spoken once with a cooldown so a
        # wavering hand cannot chatter.
        if (sp and sp != _shape.get("last_spoken")
                and now - _shape["spoken_at"] > 8.0 and _say
                and not self._motion.shape_quiet(now)):
            _shape["last_spoken"] = sp
            _shape["spoken_at"] = now
            try:
                _say(f"You are showing a {sp}, sir.")
            except Exception:
                pass

        # ── Motion: what the hand is DOING over time ────────────────────
        # One sample per analysed frame from the primary hand. Palm centre =
        # wrist↔middle-knuckle midpoint; apparent size = that same distance
        # (grows as the hand nears the lens). Both hands visible → the other
        # palm's distance feeds clap/zoom. Purely arithmetic — the ML runs
        # above regardless; this costs microseconds.
        try:
            lms0 = hres.hand_landmarks[0]
            mcx = (lms0[0].x + lms0[9].x) / 2
            mcy = (lms0[0].y + lms0[9].y) / 2
            msize = max(1e-4, ((lms0[0].x - lms0[9].x) ** 2
                               + (lms0[0].y - lms0[9].y) ** 2) ** 0.5)
            msec = 0.0
            if n > 1:
                lms1 = hres.hand_landmarks[1]
                msec = ((lms1[0].x - lms1[9].x) ** 2
                        + (lms1[0].y - lms1[9].y) ** 2) ** 0.5
            self._motion.feed(now, mcx, mcy, msize, _last.get("fingers", 0), msec)
            fired = self._motion.update(now)
            if fired:
                _shape["motion"] = fired
                _shape["motion_at"] = now
                if _say:
                    ph = _motion_phrase(fired)
                    if ph:
                        try:
                            _say(ph)
                        except Exception:
                            pass
        except Exception:
            pass

    @staticmethod
    def _count_fingers(hres) -> int:
        try:
            n = 0
            for lms in hres.hand_landmarks:
                tips = (8, 12, 16, 20)
                n += sum(1 for t in tips if lms[t].y < lms[t - 2].y)
                n += 1 if lms[4].x < lms[3].x else 0   # rough thumb test
            return min(10, n)
        except Exception:
            return 0

    # -- object identification (the only cloud call) -----------------------------
    def identify(self) -> str:
        """One snapshot → one Gemini sentence about what the camera sees.
        The SCANNING flag is up for the whole call, so the HUD overlay can
        show the scan as it happens."""
        set_scanning(True)
        try:
            return self._identify_locked()
        finally:
            set_scanning(False)

    def _identify_locked(self) -> str:
        frame = _last.get("frame")
        if frame is None or self._ident_busy:
            return _last.get("object", "")
        self._ident_busy = True
        try:
            import cv2
            ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 72])
            if not ok:
                return _last.get("object", "")
            from core import gemini
            try:
                from google.genai import types as gtypes
                part = gtypes.Part.from_bytes(data=buf.tobytes(), mime_type="image/jpeg")
            except Exception:
                part = {"inline_data": {"mime_type": "image/jpeg",
                                        "data": buf.tobytes()}}
            ans = gemini.call(
                [part, "One short spoken sentence: what is the person holding "
                       "or doing? Name the object plainly. If nothing notable, "
                       "say what the scene shows."],
                tier=gemini.FAST)
            if ans and getattr(ans, "text", ""):
                _last["object"] = ans.text.strip()[:220]
                _last["object_at"] = time.time()
        except Exception:
            pass
        finally:
            self._ident_busy = False
        return _last.get("object", "")

    # -- annotated snapshot for the HUD / tools ----------------------------------
    def annotated_jpeg(self, max_age: float = 1.5) -> bytes | None:
        if _last.get("frame") is None:
            return None
        if time.time() - _last.get("jpeg_at", 0) < max_age and _last.get("jpeg"):
            return _last["jpeg"]
        import cv2
        frame = _last["frame"].copy()
        try:
            if self._models_ok and self._busy.acquire(False):
                try:
                    import mediapipe as mp
                    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                    res = self._hands.detect(img)
                    # A fixed subset of the hand skeleton — no dependency on
                    # the legacy solutions API (removed in newer mediapipe).
                    CONN = ((0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6),
                            (6, 7), (7, 8), (5, 9), (9, 10), (10, 11),
                            (11, 12), (9, 13), (13, 14), (14, 15), (15, 16),
                            (13, 17), (17, 18), (18, 19), (19, 20), (0, 17))
                    h, w = frame.shape[:2]
                    for lms in (res.hand_landmarks or []):
                        for a, b in CONN:
                            cv2.line(frame,
                                     (int(lms[a].x * w), int(lms[a].y * h)),
                                     (int(lms[b].x * w), int(lms[b].y * h)),
                                     (255, 216, 0), 1)
                        for lm in lms:
                            cv2.circle(frame, (int(lm.x * w), int(lm.y * h)),
                                       2, (0, 255, 255), -1)
                    if _last["gesture"]:
                        cv2.putText(frame, _last["gesture"].replace("_", " "),
                                    (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                                    (0, 255, 255), 1)
                finally:
                    self._busy.release()
        except Exception:
            pass
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        if ok:
            _last["jpeg"] = buf.tobytes()
            _last["jpeg_at"] = time.time()
        return _last.get("jpeg")


def get_eye() -> VisionEye:
    global _eye
    if _eye is None:
        _eye = VisionEye()
    return _eye


def request_start() -> tuple[bool, str]:
    ok, name = get_eye().start()
    return ok, name


def request_stop() -> None:
    get_eye().stop()


def frame_age() -> float:
    """Seconds since the eye last held a frame (999 if it never has)."""
    seen = _last.get("seen_at", 0.0)
    return time.time() - seen if seen else 999.0


def status() -> dict:
    with _CAM_LOCK:
        st = dict(_cam_state)
    st["hands"] = _last.get("hands", 0)
    st["gesture"] = _last.get("gesture", "")
    st["object"] = _last.get("object", "")
    st["shape"] = _shape.get("label", "")
    st["spoken"] = _shape.get("spoken", "")
    st["motion"] = _shape.get("motion", "")
    st["scanning"] = bool(_shape.get("scanning"))
    return st
