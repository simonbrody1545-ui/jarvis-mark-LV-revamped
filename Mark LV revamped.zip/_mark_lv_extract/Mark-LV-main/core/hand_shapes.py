"""Hand-shape classification from MediaPipe landmarks — the layer that lets
JARVIS name what a hand is DOING, not just which stock gesture it matches.

The stock recogniser knows fist/palm/victory/thumbs. It cannot tell a hand
gripping a MOUSE from a plain fist — the one shape that matters when someone
sits at this desk — and it has no web-shooter sign. So landmarks are
classified here with geometric rules: extension tests per finger (tip farther
from the wrist than its middle joint), grip tests on the thumb's posture, and
tip-to-tip contact tests for pinch and OK. Pure arithmetic on normalised
coordinates: no model, no latency, no deps beyond math.

The vocabulary is verified against a procedurally generated corpus of ten
thousand-plus synthetic hands (core.gesture_corpus) — rotated, scaled,
mirrored, noised — so every label below has been proven readable before it
ever reaches the user.

Landmarks in: any sequence of objects with .x/.y (MediaPipe NormalizedLandmark)
or (x, y) tuples, 21 points in MediaPipe hand order. Coordinates are image-
normalised with y increasing DOWNWARD (the camera convention).
"""
from __future__ import annotations

import math

# MediaPipe hand landmark indices
WRIST, THUMB_TIP, THUMB_MCP = 0, 4, 2
INDEX_MCP, INDEX_PIP, INDEX_TIP = 5, 6, 8
MID_MCP, MID_PIP, MID_TIP = 9, 10, 12
RING_MCP, RING_PIP, RING_TIP = 13, 14, 16
PINKY_MCP, PINKY_PIP, PINKY_TIP = 17, 18, 20


def _pts(lms):
    out = []
    for lm in lms:
        try:
            out.append((float(lm.x), float(lm.y)))
        except AttributeError:
            out.append((float(lm[0]), float(lm[1])))
    return out


def _d(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def classify(lms) -> str:
    """Return a shape label key, or '' when nothing can be said.

    All thresholds are in palm units (wrist-to-middle-knuckle = 1.0) and were
    calibrated against core.gesture_corpus's measured distance table, so the
    numbers below are data, not vibes:
      thumb tip -> wrist:   fist 1.6-1.8 · mouse 0.5 · thumbs-up 4.0 · gun/call 3.3
      thumb tip -> idx tip: fist 0.8 (rides the folded fingertips) · mouse 1.3
    """
    try:
        p = _pts(lms)
        if len(p) < 21:
            return ""
        palm = max(_d(p[WRIST], p[MID_MCP]), 1e-4)

        def ext(tip, pip):
            return _d(p[tip], p[WRIST]) > _d(p[pip], p[WRIST]) * 1.12

        f_idx = ext(INDEX_TIP, INDEX_PIP)
        f_mid = ext(MID_TIP, MID_PIP)
        f_rng = ext(RING_TIP, RING_PIP)
        f_pky = ext(PINKY_TIP, PINKY_PIP)
        n_ext = sum((f_idx, f_mid, f_rng, f_pky))

        # Thumb posture, in palm units:
        #   raised: tip stands far above the wrist (thumbs-up, gun, call-me)
        #   centre: tip sits on the palm centre (fist-over, four)
        th_raised = _d(p[THUMB_TIP], p[WRIST]) > 2.2 * palm
        cx = (p[WRIST][0] + p[MID_MCP][0]) / 2
        cy = (p[WRIST][1] + p[MID_MCP][1]) / 2
        th_centre = _d(p[THUMB_TIP], (cx, cy)) < 0.45 * palm

        # tip-contact signs first. A closed ring between thumb and index is
        # PINCH when the other fingers stay down, OK when they stand up.
        if _d(p[THUMB_TIP], p[INDEX_TIP]) < 0.42 * palm:
            return "ok_sign" if n_ext >= 2 else "pinch"

        # -- grip family: ALL four fingers curled --------------------------
        if n_ext == 0:
            # A raised thumb is a thumbs-up even tilted: the distinctive part
            # is DISTANCE from the fist (4.0 palm vs fist 1.6, mouse 0.5),
            # not the angle — a 2-D camera cannot police tilt.
            if th_raised:
                return "thumbs_up"
            # fist: the thumb rides ON the folded fingertips; a mouse grip
            # rests lower on the side, clear of them.
            if _d(p[THUMB_TIP], p[INDEX_TIP]) < 1.0 * palm:
                return "fist"
            return "mouse_grip"

        # -- one finger (thumb posture names gun and call-me) --------------
        if n_ext == 1:
            if f_idx:
                return "gun" if th_raised else "point"
            if f_pky:
                return "call_me" if th_raised else "pinky"
            if f_mid or f_rng:
                return "single_mid"
            return "thumb_out"

        # -- two fingers ----------------------------------------------------
        if n_ext == 2:
            if f_idx and f_mid:
                return "victory"
            if f_idx and f_pky:
                return "rock"
            return "two_side"

        # -- three fingers: named by the one that stayed down ---------------
        if n_ext == 3:
            if not f_mid:
                # mid down, index+ring+pinky up: raised thumb = the W,
                # side thumb = the Spidey web-shooter sign
                return "w_hand" if th_raised else "web_shooter"
            if not f_idx or not f_rng:
                return "three"
            return "three_fwd"           # only the pinky stayed down

        # -- all four: thumb over the palm = four, else the open hand -------
        if th_centre:
            return "four"
        return "open"
    except Exception:
        return ""


# What JARVIS actually says. Deliberately the user's own vocabulary:
# a closed hand is "hand", the desk grip is "mouse".
SPOKEN = {
    "fist":        "hand",
    "mouse_grip":  "mouse",
    "point":       "pointing",
    "pinch":       "pinching",
    "ok_sign":     "OK sign",
    "open":        "open hand",
    "four":        "four",
    "victory":     "victory",
    "thumbs_up":   "thumbs up",
    "rock":        "rock sign",
    "gun":         "finger gun",
    "call_me":     "call me sign",
    "pinky":       "pinky",
    "thumb_out":   "thumb out",
    "single_mid":  "one finger",
    "two_side":    "two fingers",
    "three":       "three",
    "three_fwd":   "three",
    "w_hand":      "letter W",
    "web_shooter": "web shooter",
    # stock recogniser fallbacks, phrased the same way
    "Closed_Fist": "hand",
    "Open_Palm":   "open hand",
    "Pointing_Up": "pointing",
    "Thumb_Up":    "thumbs up",
    "Thumb_Down":  "thumbs down",
    "Victory":     "victory",
    "ILY":         "ily sign",
}


def spoken(label: str) -> str:
    return SPOKEN.get(label, "")
