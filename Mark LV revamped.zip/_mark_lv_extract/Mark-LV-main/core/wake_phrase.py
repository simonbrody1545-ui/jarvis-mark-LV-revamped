"""Custom spoken wake phrase — say whatever YOU choose to wake JARVIS.

The pretrained openwakeword model only knows "Hey Jarvis". This module adds a
phrase spotter that wakes on ANY configurable phrase — the user's own words,
by default "wake up daddy home" — using the vosk offline speech engine:

  • fully local — audio never leaves the machine; the only network use is the
    one-time ~40 MB English model download on first enable
  • zero cost when off — vosk is imported and the model is constructed ONLY
    when the spotter is started
  • zero cost on the audio path — feed() is a queue push from the mic
    callback; recognition runs in this module's own thread

Matching is deliberately forgiving: mumbled, fast or noisy speech still wakes
the house. Recognised words land in a rolling ~4.5 s tail; the phrase fires
when the tail contains it exactly, or a sliding window of words matches it
closely enough (difflib ratio >= 0.72). A 3 s cooldown plus queue drain stops
the same utterance firing twice.
"""
from __future__ import annotations

import difflib
import queue
import threading
import time

SAMPLE_RATE = 16000
_TAIL_SECONDS = 4.5
_FUZZY_RATIO = 0.72
_COOLDOWN = 3.0


def get_wake_phrase() -> str:
    """The phrase the user chose (default 'wake up daddy home'). Never raises."""
    try:
        from memory.config_manager import load_api_keys
        p = str(load_api_keys().get("wake_phrase") or "").strip().lower()
        return p or DEFAULT_PHRASE
    except Exception:
        return DEFAULT_PHRASE


DEFAULT_PHRASE = "wake up daddy home"


def set_wake_phrase(phrase: str) -> bool:
    """Persist a custom phrase (2+ words). Returns False on nonsense."""
    p = (phrase or "").strip().lower()
    if len(p.split()) < 2 or len(p) > 60:
        return False
    try:
        from memory.config_manager import load_api_keys, _save_flag
        _save_flag("wake_phrase", p)
        return True
    except Exception:
        return False


def is_available() -> bool:
    try:
        import importlib.util
        return importlib.util.find_spec("vosk") is not None
    except Exception:
        return False


class PhraseSpotter:
    """Runs vosk in a dedicated thread; feed() from the mic callback only."""

    def __init__(self, on_detect, phrase: str | None = None,
                 logger=print, notify=None):
        self._on_detect = on_detect
        self._phrase = (phrase or get_wake_phrase())
        self._logger = logger
        self._notify = notify or (lambda _m: None)
        self._q: queue.Queue = queue.Queue(maxsize=80)
        self._thread = None
        self._running = False
        self._model = None
        self._rec = None
        self._ready = False
        # rolling tail of (time, word)
        self._words: list[tuple[float, str]] = []
        self._last_partial = ""
        self._last_fire = 0.0

    # ── lifecycle ────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self._running:
            return True
        if not is_available():
            self._notify("Wake phrase: vosk is not installed — pip install vosk")
            return False
        try:
            import vosk
            vosk.SetLogLevel(-1)
            self._model = vosk.Model(lang="en-us")   # auto-downloads once
        except Exception as e:
            self._notify(f"Wake phrase: model unavailable — {e}")
            self._logger(f"Wake phrase: {e}")
            return False
        self._rec = None
        self._running = True
        self._ready = True
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="WakePhraseThread")
        self._thread.start()
        self._logger(f"Wake phrase: listening for '{self._phrase}'.")
        return True

    def stop(self) -> None:
        self._running = False
        try:
            self._q.put_nowait(None)
        except Exception:
            pass
        self._rec = None
        self._model = None
        self._ready = False

    @property
    def ready(self) -> bool:
        return self._ready

    def phrase(self) -> str:
        return self._phrase

    def set_phrase(self, phrase: str) -> None:
        self._phrase = (phrase or get_wake_phrase()).strip().lower()

    # ── audio in ─────────────────────────────────────────────────────────
    def feed(self, frame_int16) -> None:
        """Mic callback side: never blocks, never raises."""
        if not self._running:
            return
        try:
            data = (frame_int16[:, 0].copy()
                    if getattr(frame_int16, "ndim", 1) > 1
                    else frame_int16.copy())
            self._q.put_nowait(data)
        except queue.Full:
            pass
        except Exception:
            pass

    # ── recognition ──────────────────────────────────────────────────────
    def _loop(self) -> None:
        import numpy as np
        import json
        import vosk
        while self._running:
            try:
                frame = self._q.get()
                if frame is None or not self._running:
                    break
                if self._rec is None:
                    self._rec = vosk.KaldiRecognizer(
                        self._model, SAMPLE_RATE)
                if self._rec.AcceptWaveform(frame.tobytes()):
                    text = self._words_from(
                        json.loads(self._rec.Result()).get("text", ""))
                else:
                    text = self._words_from(
                        json.loads(self._rec.PartialResult()).get("partial", ""))
                if text:
                    now = time.monotonic()
                    for w in text:
                        self._words.append((now, w))
                    cutoff = now - _TAIL_SECONDS
                    self._words = [wt for wt in self._words if wt[0] >= cutoff]
                    self._check(now)
            except Exception as e:
                self._logger(f"Wake phrase: {e}")
                time.sleep(0.2)

    @staticmethod
    def _words_from(text: str) -> list[str]:
        new = text.strip().lower().split()
        # only the words we have not seen in the partial yet — vosk partials
        # grow prefix-wise, so the delta is the tail of the new list
        return new

    def _check(self, now: float) -> None:
        if now - self._last_fire < _COOLDOWN:
            return
        words = [w for _t, w in self._words]
        if not words:
            return
        target = self._phrase.split()
        n = len(target)
        hit = False
        # exact containment
        tail = " ".join(words)
        if self._phrase in tail:
            hit = True
        else:
            # sliding fuzzy windows of every length 2..n+2, the same ratio bar
            # throughout. Every length matters: a mumbled tail ("wake up
            # daddy", 3 of 4 words) lives in the n-1 window, and the phrase
            # spoken mid-sentence lives in the n+2 window — single-length
            # scanning misses both.
            for size in range(2, n + 3):
                if size > len(words):
                    break
                for i in range(0, len(words) - size + 1):
                    cand = " ".join(words[i:i + size])
                    if difflib.SequenceMatcher(
                            None, cand, self._phrase).ratio() >= _FUZZY_RATIO:
                        hit = True
                        break
                if hit:
                    break
        if not hit:
            return
        self._last_fire = now
        self._words.clear()
        try:
            while True:
                self._q.get_nowait()
        except Exception:
            pass
        self._on_detect()
