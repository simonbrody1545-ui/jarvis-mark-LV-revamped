"""Synthetic motion corpus — a thousand-plus labelled gesture SEQUENCES.

The static exam (core.gesture_corpus) proves the shape engine reads poses.
This proves the MOTION engine reads trajectories: each case is a procedurally
generated time-series — a hand moving the way a real wave, swipe, push, clap
moves — rendered frame by frame, fed to MotionTracker, and the fired label
must match. Rotations become direction variants here (a wave rightward or
leftward is still a wave; a swipe is named by its side); noise, jitter and
timing wobble make all thousand-plus sequences unique.

The negative class matters as much as the positives: idle hands, slow drifts,
taps and single open-close twitches must fire NOTHING — a gesture engine that
celebrates every twitch is worse than one that sees nothing.
"""
from __future__ import annotations

import math
import random

from core.dynamic_gestures import MotionTracker

FPS = 30
DT = 1.0 / FPS


# ── signal helpers ────────────────────────────────────────────────────────────
def _frames(n):
    return range(int(n * FPS))


def _noise(rng, amt):
    return rng.uniform(-amt, amt)


# ── motion generators. Each yields (t, cx, cy, size, n_open, second) samples ──
def _gen_wave(rng):
    t0, x0, y0 = 0.0, rng.uniform(0.3, 0.7), rng.uniform(0.35, 0.6)
    amp = rng.uniform(0.045, 0.075)
    freq = rng.uniform(2.2, 3.2)
    dur = rng.uniform(1.0, 1.6)
    phase = rng.choice((0.0, math.pi))
    size = rng.uniform(0.10, 0.13)
    n_open = rng.choice((4, 5))
    for i in _frames(dur + 0.6):
        t = i * DT
        x = x0 + amp * math.sin(2 * math.pi * freq * t + phase) + _noise(rng, 0.004)
        y = y0 + _noise(rng, 0.006)
        yield (t, x, y, size, n_open, 0.0)


def _gen_swipe(rng):
    side = rng.choice((-1, 1))
    y = rng.uniform(0.3, 0.65)
    travel = rng.uniform(0.20, 0.30)
    dur = rng.uniform(0.35, 0.7)
    n_open = rng.choice((2, 3, 5))
    size = rng.uniform(0.10, 0.13)
    for i in _frames(0.4 + dur + 0.6):
        t = i * DT
        if t < 0.4:
            x = 0.5 - side * 0.02 + _noise(rng, 0.003)
        elif t < 0.4 + dur:
            k = (t - 0.4) / dur
            x = 0.5 - side * 0.02 + side * travel * (k ** 0.8)
        else:
            x = 0.5 - side * 0.02 + side * travel + _noise(rng, 0.002)
        yield (t, x + _noise(rng, 0.004), y + _noise(rng, 0.005),
               size, n_open, 0.0)


def _gen_push(rng):
    x, y = rng.uniform(0.35, 0.65), rng.uniform(0.35, 0.6)
    s0, s1 = rng.uniform(0.07, 0.09), rng.uniform(0.16, 0.22)
    dur = rng.uniform(0.5, 0.9)
    n_open = rng.choice((4, 5))
    for i in _frames(0.3 + dur + 0.5):
        t = i * DT
        if t < 0.3:
            s = s0
        elif t < 0.3 + dur:
            k = (t - 0.3) / dur
            s = s0 + (s1 - s0) * (k ** 0.7)
        else:
            s = s1 + _noise(rng, 0.002)
        yield (t, x + _noise(rng, 0.005), y + _noise(rng, 0.005),
               s + _noise(rng, 0.003), n_open, 0.0)


def _gen_pull(rng):
    x, y = rng.uniform(0.35, 0.65), rng.uniform(0.35, 0.6)
    s0, s1 = rng.uniform(0.14, 0.18), rng.uniform(0.06, 0.08)
    dur = rng.uniform(0.5, 0.9)
    n_open = rng.choice((4, 5))
    for i in _frames(0.3 + dur + 0.5):
        t = i * DT
        if t < 0.3:
            s = s0
        elif t < 0.3 + dur:
            k = (t - 0.3) / dur
            s = s0 + (s1 - s0) * (k ** 0.7)
        else:
            s = s1 + _noise(rng, 0.002)
        yield (t, x + _noise(rng, 0.005), y + _noise(rng, 0.005),
               s + _noise(rng, 0.003), n_open, 0.0)


def _gen_come_here(rng):
    """Two pull cycles: hand approaches, retreats, approaches again."""
    x, y = rng.uniform(0.35, 0.65), rng.uniform(0.4, 0.6)
    base = rng.uniform(0.11, 0.13)
    lo, hi = base * 0.55, base * 1.15
    period = rng.uniform(0.55, 0.8)
    n_open = rng.choice((4, 5))
    for i in _frames(0.25 + period * 2.3 + 0.3):
        t = i * DT
        if t < 0.25:
            s = base
        else:
            k = (t - 0.25) / period
            # swing the FULL lo<->hi span — the approach/retreat of a real
            # "come here" beckon (an earlier formula only rose 15% above
            # base, a flat envelope no detector could read)
            s = lo + (hi - lo) * (0.5 + 0.5 * math.cos(2 * math.pi * k))
        yield (t, x + _noise(rng, 0.005), y + _noise(rng, 0.005),
               s + _noise(rng, 0.002), n_open, 0.0)


def _gen_circle(rng):
    cx0, cy0 = rng.uniform(0.35, 0.65), rng.uniform(0.35, 0.6)
    r = rng.uniform(0.06, 0.10)
    turns = rng.uniform(1.05, 1.5)
    dur = rng.uniform(0.9, 1.5)
    direct = rng.choice((1, -1))
    n_open = rng.choice((1, 2))
    size = rng.uniform(0.09, 0.12)          # constant: no fake size dips
    for i in _frames(0.3 + dur + 0.4):
        t = i * DT
        if t < 0.3:
            yield (t, cx0 + r + _noise(rng, 0.004), cy0 + _noise(rng, 0.004),
                   size, n_open, 0.0)
            continue
        k = (t - 0.3) / dur
        a = direct * 2 * math.pi * turns * k
        yield (t, cx0 + r * math.cos(a) + _noise(rng, 0.004),
               cy0 + r * math.sin(a) + _noise(rng, 0.004),
               size, n_open, 0.0)


def _gen_fist_pump(rng):
    x, y = rng.uniform(0.35, 0.65), rng.uniform(0.4, 0.55)
    dur_open = rng.uniform(0.28, 0.4)
    dur_closed = rng.uniform(0.25, 0.38)
    reps = 2
    n_open_hi, n_open_lo = 5, 0
    size = rng.uniform(0.10, 0.12)
    t = 0.0
    for rep in range(reps + 1):
        for _ in _frames(dur_open if rep else 0.3):
            yield (t, x + _noise(rng, 0.004), y + _noise(rng, 0.004),
                   size, n_open_hi if rep else rng.choice((4, 5)), 0.0)
            t += DT
        for _ in _frames(dur_closed):
            yield (t, x + _noise(rng, 0.004), y + _noise(rng, 0.004),
                   size, n_open_lo, 0.0)
            t += DT


def _gen_raise(rng):
    x = rng.uniform(0.3, 0.7)
    y0, y1 = rng.uniform(0.62, 0.72), rng.uniform(0.18, 0.3)
    dur = rng.uniform(0.45, 0.8)
    n_open = rng.choice((4, 5))
    size = rng.uniform(0.10, 0.13)
    for i in _frames(0.3 + dur + 0.5):
        t = i * DT
        if t < 0.3:
            y = y0
        elif t < 0.3 + dur:
            k = (t - 0.3) / dur
            y = y0 + (y1 - y0) * (k ** 0.8)
        else:
            y = y1 + _noise(rng, 0.003)
        yield (t, x + _noise(rng, 0.004), y + _noise(rng, 0.004),
               size, n_open, 0.0)


def _gen_clap(rng):
    cx0 = rng.uniform(0.4, 0.6)
    cy0 = rng.uniform(0.4, 0.55)
    far, near = rng.uniform(0.11, 0.14), rng.uniform(0.01, 0.03)
    dur = rng.uniform(0.3, 0.55)
    for i in _frames(0.4 + dur + 0.5):
        t = i * DT
        if t < 0.4:
            gap = far
        elif t < 0.4 + dur:
            k = (t - 0.4) / dur
            gap = far + (near - far) * k
        else:
            gap = near
        yield (t, cx0 + _noise(rng, 0.004), cy0 + _noise(rng, 0.004),
               rng.uniform(0.10, 0.12), 5, gap)


def _gen_zoom(rng):
    cx0, cy0 = rng.uniform(0.4, 0.6), rng.uniform(0.4, 0.55)
    gap = rng.uniform(0.05, 0.08)
    s0, s1 = rng.uniform(0.07, 0.09), rng.uniform(0.15, 0.2)
    dur = rng.uniform(0.5, 0.9)
    for i in _frames(0.4 + dur + 0.4):
        t = i * DT
        if t < 0.4:
            s = s0
        elif t < 0.4 + dur:
            k = (t - 0.4) / dur
            s = s0 + (s1 - s0) * k
        else:
            s = s1
        yield (t, cx0 + _noise(rng, 0.004), cy0 + _noise(rng, 0.004),
               s + _noise(rng, 0.003), 5, gap)


# ── negatives: things that must fire NOTHING ──────────────────────────────────
def _gen_idle(rng):
    x, y = rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)
    size = rng.uniform(0.10, 0.12)          # constant: no size envelope at all
    n_open = rng.choice((0, 5))
    for i in _frames(rng.uniform(1.2, 2.0)):
        t = i * DT
        yield (t, x + _noise(rng, 0.006), y + _noise(rng, 0.006),
               size, n_open, 0.0)


def _gen_drift(rng):
    x, y = rng.uniform(0.3, 0.6), rng.uniform(0.3, 0.6)
    vx, vy = rng.uniform(-0.02, 0.02), rng.uniform(-0.02, 0.02)
    size = rng.uniform(0.10, 0.12)
    for i in _frames(rng.uniform(1.5, 2.0)):
        t = i * DT
        x = min(0.9, max(0.1, x + vx * DT))
        y = min(0.9, max(0.1, y + vy * DT))
        yield (t, x, y, size, 5, 0.0)


def _gen_tap(rng):
    x, y = rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)
    size = rng.uniform(0.10, 0.12)
    n_open = rng.choice((0, 5))             # fixed per sequence, not per frame
    for i in _frames(1.4):
        t = i * DT
        yield (t, x + _noise(rng, 0.004), y + _noise(rng, 0.004),
               size, n_open, 0.0)


def _gen_small_jitter(rng):
    x, y = rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)
    size = rng.uniform(0.10, 0.12)
    for i in _frames(1.6):
        t = i * DT
        yield (t, x + _noise(rng, 0.015), y + _noise(rng, 0.015),
               size, 5, 0.0)


POSITIVES = [
    ("wave",       _gen_wave),
    ("swipe",      _gen_swipe),        # label normalised to swipe_left/right
    ("push",       _gen_push),
    ("pull",       _gen_pull),
    ("come_here",  _gen_come_here),
    ("circle",     _gen_circle),
    ("fist_pump",  _gen_fist_pump),
    ("raise_hand", _gen_raise),
    ("clap",       _gen_clap),
    ("zoom",       _gen_zoom),
]
NEGATIVES = [
    ("", _gen_idle), ("", _gen_drift), ("", _gen_tap), ("", _gen_small_jitter),
]


def _matches(expected: str, fired: str) -> bool:
    if expected == "swipe":
        return fired in ("swipe_left", "swipe_right")
    return fired == expected


def generate(n: int = 1100, seed: int = 11) -> list[tuple[str, list[tuple]]]:
    """n labelled motion sequences, every one unique."""
    rng = random.Random(seed)
    out: list[tuple[str, list[tuple]]] = []
    per = max(1, n // (len(POSITIVES) + len(NEGATIVES)))
    for label, gen in POSITIVES:
        for _ in range(per):
            out.append((label, list(gen(rng))))
    for label, gen in NEGATIVES:
        for _ in range(per * 2):        # negatives weighted heavier
            out.append((label, list(gen(rng))))
    rng.shuffle(out)
    return out


def run(n: int = 1100, seed: int = 11) -> dict:
    """Generate, feed, examine. Returns the scorecard."""
    seqs = generate(n, seed)
    total = len(seqs)
    ok = 0
    per_label: dict[str, list[int]] = {}
    fired_labels = set()
    for label, samples in seqs:
        tr = MotionTracker()
        got = ""
        for s in samples:
            tr.feed(*s)
            fired = tr.update()
            if fired:
                got = fired
                break
        if not got:
            # let the window settle: feed the tail again (real hands linger)
            last_t = samples[-1][0]
            for s in samples:
                if s[0] > last_t - 0.8:
                    tr.feed(*s)
                    fired = tr.update()
                    if fired:
                        got = fired
                        break
        good = _matches(label, got)
        fired_labels.add(got or "(none)")
        ok += good
        w = per_label.setdefault(label or "(negative)", [0, 0])
        w[0 if good else 1] += 1
    return {"total": total, "pass": ok, "fail": total - ok,
            "per_label": per_label, "fired": sorted(fired_labels)}


if __name__ == "__main__":
    r = run()
    print(f"dynamic exam: {r['pass']}/{r['total']} "
          f"({100 * r['pass'] / max(1, r['total']):.1f}%)")
    for k in sorted(r["per_label"]):
        w, f = r["per_label"][k]
        print(f"  {k:12s} {w:4d} ok {f:3d} fail")
