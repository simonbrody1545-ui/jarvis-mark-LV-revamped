"""Surroundings scan — the real data behind the radar dock.

Everything here runs in one daemon thread at a leisurely period (the RF
environment does not change faster than that, and each probe shells out to an
OS utility). The scan is best-effort by design: any probe that fails simply
contributes nothing, so a desktop without Wi-Fi still shows the LAN layer and
a machine with neither still gets a live sweep with the host at its centre.

Probes, per platform:
  Wi-Fi   Windows  `netsh wlan show networks mode=bssid`  (+ `show interfaces`
                   for the network we are actually on)
          Linux    `iw dev <dev> scan` (root usually required — falls through)
          macOS    the private `airport -s` helper, where it still exists
  LAN     `arp -a` — parsed identically on all three platforms.

Signal strength arrives as a 0–100 percentage from netsh (100 = closest).
Angles on the radar are derived deterministically from a hash of the BSSID so
a given network sits in the same direction on every scan — the display reads
as a stable picture of the room rather than random noise, which is the whole
difference between an instrument and a screensaver.
"""

from __future__ import annotations

import hashlib
import platform
import re
import subprocess
import threading
import time
from pathlib import Path

_OS = platform.system()

if _OS == "Windows":
    _HIDE = {"creationflags": subprocess.CREATE_NO_WINDOW}
else:
    _HIDE = {}


def _angle_for(seed: str) -> float:
    """A stable direction (radians) for an identifier — hash-derived so the
    same network always plots in the same direction."""
    digest = hashlib.md5(seed.encode("utf-8", "ignore")).digest()
    return int.from_bytes(digest[:4], "big") / 0xFFFFFFFF * 6.2831853


def _netsh_wifi() -> list[dict]:
    """Nearby Wi-Fi networks from netsh. Returns [] on any failure."""
    try:
        out = subprocess.run(
            ["netsh", "wlan", "show", "networks", "mode=bssid"],
            capture_output=True, text=True, timeout=12,
            errors="replace", **_HIDE).stdout
    except Exception:
        return []

    nets: list[dict] = []
    cur: dict | None = None
    cur_bssid: dict | None = None
    for line in out.splitlines():
        s = line.strip()
        m = re.match(r"SSID \d+\s*:\s*(.*)$", s)
        if m:
            cur = {"ssid": m.group(1).strip() or "(hidden)",
                   "auth": "", "bssids": []}
            nets.append(cur)
            cur_bssid = None
            continue
        if cur is None:
            continue
        m = re.match(r"Authentication\s*:\s*(.*)$", s)
        if m:
            cur["auth"] = m.group(1).strip()
            continue
        # "BSSID 1         : aa:bb:cc:dd:ee:ff" — signal/channel are INDENTED
        # SUBSEQUENT lines ("Signal : 100%", "Channel : 11"), not colon
        # fields on the BSSID line. Every Windows output variant puts them on
        # their own lines; the one-line form was assumed from an old format.
        m = re.match(r"BSSID \d+\s*:\s*([0-9a-fA-F:]{17})", s)
        if m:
            cur_bssid = {"bssid": m.group(1).lower(), "signal": 0,
                         "channel": 0}
            cur["bssids"].append(cur_bssid)
            continue
        if cur_bssid is not None:
            m = re.match(r"Signal\s*:\s*(\d+)%", s)
            if m:
                cur_bssid["signal"] = int(m.group(1))
                continue
            m = re.match(r"Channel\s*:\s*(\d+)", s)
            if m:
                cur_bssid["channel"] = int(m.group(1))
                continue
    # Flatten to one blip per BSSID (a repeater really is two radios).
    blips = []
    for n in nets:
        for b in n["bssids"]:
            blips.append({"kind": "wifi", "ssid": n["ssid"],
                          "auth": n["auth"], **b})
    return blips


def _connected_ssid() -> str:
    try:
        out = subprocess.run(
            ["netsh", "wlan", "show", "interfaces"],
            capture_output=True, text=True, timeout=8,
            errors="replace", **_HIDE).stdout
    except Exception:
        return ""
    m = re.search(r"^\s*SSID\s*:\s*(.+)$", out, re.M)
    return m.group(1).strip() if m else ""


def _linux_wifi() -> list[dict]:
    try:
        out = subprocess.run(["iw", "dev"], capture_output=True, text=True,
                             timeout=8, errors="replace", **_HIDE).stdout
        dev = (re.search(r"Interface\s+(\S+)", out) or [None, ""])[1]
        if not dev:
            return []
        out = subprocess.run(["iw", "dev", dev, "scan"], capture_output=True,
                             text=True, timeout=15, errors="replace", **_HIDE).stdout
    except Exception:
        return []
    blips, cur = [], None
    for line in out.splitlines():
        s = line.strip()
        m = re.match(r"BSS ([0-9a-fA-F:]{17})", s)
        if m:
            cur = {"kind": "wifi", "bssid": m.group(1).lower(), "ssid": "(hidden)",
                   "signal": 30, "channel": 0}
            blips.append(cur)
            continue
        if cur is None:
            continue
        m = re.match(r"SSID:\s*(.*)$", s)
        if m and m.group(1).strip():
            cur["ssid"] = m.group(1).strip()
        m = re.match(r"signal:\s*(-?\d+\.?\d*)\s*dBm", s)
        if m:
            dbm = float(m.group(1))
            cur["signal"] = int(max(2, min(100, 2 * (dbm + 100))))
        m = re.match(r"DS Parameter set:\s*channel\s*(\d+)", s)
        if m:
            cur["channel"] = int(m.group(1))
    return blips


def _mac_wifi() -> list[dict]:
    air = Path("/System/Library/PrivateFrameworks/Apple80211.framework/"
               "Versions/Current/Resources/airport")
    if not air.exists():
        return []
    try:
        out = subprocess.run([str(air), "-s"], capture_output=True, text=True,
                             timeout=12, errors="replace", **_HIDE).stdout
    except Exception:
        return []
    blips = []
    for line in out.splitlines()[1:]:
        cols = line.split()
        if len(cols) >= 4 and re.match(r"[0-9a-fA-F:]{17}", cols[1]):
            try:
                rssi = int(cols[2])
            except ValueError:
                continue
            blips.append({"kind": "wifi", "ssid": cols[0],
                          "bssid": cols[1].lower(),
                          "signal": max(2, min(100, 2 * (rssi + 100))),
                          "channel": 0})
    return blips


def _scan_wifi() -> list[dict]:
    if _OS == "Windows":
        return _netsh_wifi()
    if _OS == "Linux":
        return _linux_wifi()
    return _mac_wifi()


_MAC_RE = re.compile(r"([0-9a-fA-F]{1,2}(?::[0-9a-fA-F]{1,2}){5}|"
                     r"[0-9a-fA-F]{1,2}(?:-[0-9a-fA-F]{1,2}){5})")
_IP_RE = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3})")


# ── device-type fingerprint (privacy-safe) ───────────────────────────────
# The radar labels a contact by WHAT KIND OF DEVICE it is, never by who made
# it or where it lives. The OUI (first 3 MAC bytes) maps to a manufacturer,
# and the manufacturer bucket maps to a coarse type. The MAC itself never
# leaves this function — only the type word does.
_OUI_TYPES: dict[str, str] = {
    # Apple — could be laptop or phone; type reported as "apple device"
    "apple":     "apple device",
    # Phones (Android OEMs)
    "samsung":   "android phone", "huawei": "android phone",
    "xiaomi":    "android phone", "oppo": "android phone",
    "vivo":      "android phone", "oneplus": "android phone",
    "google":    "android phone", "honor": "android phone",
    "realme":    "android phone", "motorola": "android phone",
    "infinix":   "android phone", "tecno": "android phone",
    "nokia":     "android phone",
    # Routers / APs
    "tp-link":   "router", "d-link": "router", "netgear": "router",
    "asus":      "router", "linksys": "router", "tenda": "router",
    "routerboard": "router", "ubiquiti": "router", "huawei-h": "router",
    # Computers
    "dell": "pc", "hp": "pc", "lenovo": "pc", "msi": "pc",
    "gigabyte": "pc", "intel": "pc", "amd": "pc", "micro-star": "pc",
    # TVs / consoles / IoT
    "samsung-e": "tv or console", "lg": "tv or console",
    "sony": "tv or console", "panasonic": "tv or console",
    "esp": "smart iot device", "espressif": "smart iot device",
    "raspberry": "raspberry pi", "amazon": "smart iot device",
}
_OUI_TABLE: dict[str, str] = {
    # A compact OUI→key map of the most common manufacturers (not exhaustive;
    # unknown MACs fall back to a signal-based guess below).
    "3c:5a:b4": "google", "f4:f5:d8": "google", "dc:a6:32": "raspberry",
    "b8:27:eb": "raspberry", "e4:5f:01": "raspberry",
    "00:1a:11": "google", "30:fd:38": "esp", "24:0a:c4": "esp",
    "ec:fa:bc": "esp", "5c:cf:7f": "esp", "18:fe:34": "esp",
    "00:1e:06": "dell", "f8:db:88": "apple", "ac:87:a3": "apple",
    "f0:18:98": "apple", "a4:83:e7": "apple", "d0:03:4b": "apple",
    "40:9f:38": "samsung", "84:25:db": "samsung", "cc:fa:00": "samsung",
    "50:85:69": "huawei", "18:c5:8f": "huawei", "78:1d:ba": "xiaomi",
    "64:09:80": "xiaomi", "ac:c1:ee": "xiaomi", "40:b8:37": "xiaomi",
    "00:17:9a": "d-link", "14:cc:20": "tp-link", "50:c7:bf": "tp-link",
    "a4:2b:b0": "tp-link", "c0:25:e9": "tp-link", "b0:48:7a": "tp-link",
    "00:24:a5": "buffalo", "00:0f:66": "netgear", "a0:40:a0": "netgear",
    "9c:3d:cf": "netgear", "00:1f:33": "netgear", "00:26:f2": "netgear",
    "00:1b:63": "apple", "00:23:12": "apple", "00:25:00": "apple",
    "08:66:98": "sony", "30:f9:ed": "sony", "00:26:52": "sony",
    "64:a2:f9": "samsung-e", "00:e0:64": "samsung-e",
    "38:01:67": "lg", "cc:fa:0b": "lg", "f8:0c:f3": "htc",
    "00:0c:29": "vm virtual machine", "00:50:56": "vm virtual machine",
    "08:00:27": "vm virtual machine", "52:54:00": "vm virtual machine",
    "00:16:3e": "vm virtual machine",
    "00:1d:7e": "cisco", "00:23:04": "cisco", "f8:66:f2": "motorola",
    "44:23:7c": "oneplus", "38:a4:ed": "oppo", "c0:ee:fb": "oppo",
    "08:d2:9e": "vivo", "40:4e:36": "honor", "54:2f:6e": "honor",
    "84:d9:63": "lenovo", "00:21:5c": "lenovo", "7c:dd:90": "lenovo",
    "3c:97:0e": "hp", "00:1f:5b": "apple", "24:be:05": "hp",
    "b4:6d:83": "asus", "ac:22:0b": "asus", "00:0c:e7": "pentagram",
    "00:12:17": "cisco", "00:14:22": "dell", "00:13:72": "dell",
}


def _mac_vendor(mac: str) -> str:
    """Manufacturer key from the OUI prefix, or '' when unknown."""
    try:
        m = mac.lower().replace("-", ":")
        return _OUI_TABLE.get(m[:8], "")
    except Exception:
        return ""


def device_type(mac: str, signal: int = 60) -> str:
    """A coarse, non-identifying type word for a radar contact: 'android
    phone', 'router', 'pc', 'apple device', 'smart iot device', 'tv or
    console', 'unknown device'. Strong-signal unknowns on a phone-shaped
    vendor stay honest — no guess is made where the data can't back it."""
    v = _mac_vendor(mac or "")
    if v:
        return _OUI_TYPES.get(v, "unknown device")
    # No OUI match: the only honest signal is radio strength. Strong nearby
    # unknowns are likely personal devices; otherwise report the unknown.
    if (signal or 0) >= 90:
        return "nearby device"
    return "unknown device"


def _scan_lan() -> list[dict]:
    """LAN neighbours from the ARP table — addresses the machine is actually
    exchanging frames with right now."""
    try:
        out = subprocess.run(["arp", "-a"], capture_output=True, text=True,
                             timeout=10, errors="replace", **_HIDE).stdout
    except Exception:
        return []
    seen, devices = set(), []
    for line in out.splitlines():
        ip_m   = _IP_RE.search(line)
        mac_m  = _MAC_RE.search(line)
        if not ip_m or not mac_m:
            continue
        ip, mac = ip_m.group(1), mac_m.group(1).lower().replace("-", ":")
        if ip in seen or mac == "ff:ff:ff:ff:ff:ff":
            continue
        seen.add(ip)
        devices.append({"kind": "lan", "ip": ip, "mac": mac,
                        "signal": 55 + (hash(ip) % 25)})   # LAN has no RSSI; mid-ring
    return devices


class SurroundingsScan:
    """One daemon thread, one lock, one snapshot dict — the same shape as the
    system-metrics probe so the UI treats them identically."""

    PERIOD = 8.0          # seconds between full sweeps

    def __init__(self):
        self._lock = threading.Lock()
        self._wifi:    list[dict] = []
        self._lan:     list[dict] = []
        self._ssid     = ""
        self._updated  = 0.0
        self._err      = ""       # last probe failure, for the HUD caption
        self._running  = True
        self._cb       = None     # contact-set change callback (see set_scan_callback)
        self._last_fp  = None     # fingerprint of the last reported contact set
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def set_on_change(self, cb) -> None:
        self._cb = cb

    def _loop(self):
        # First sweep immediately so the radar is populated the moment the
        # dock is opened rather than one period later.
        while self._running:
            try:
                self._sweep()
            except Exception as e:
                with self._lock:
                    self._err = str(e)[:80]
            time.sleep(self.PERIOD)

    def _fingerprint(self) -> tuple:
        """Identity of the current contact set — angles are hash-stable per
        device, so this changes only when a device or network appears or
        leaves. Signal jitter does NOT retrigger the callback."""
        rows = [("w", round(b.get("angle", 0.0), 3)) for b in self._wifi]
        rows += [("h", round(d.get("angle", 0.0), 3)) for d in self._lan]
        return tuple(sorted(rows))

    def _sweep(self):
        wifi = _scan_wifi()
        if _OS == "Windows":
            ssid = _connected_ssid()
        else:
            ssid = ""
        lan  = _scan_lan()
        # PRIVACY GATE — the raw probe results (SSIDs, MACs, IPs) never leave
        # this function. The snapshot the UI ever sees carries only anonymous
        # labels, positions and a stable pseudonymous seed for the angle, so
        # the radar shows the shape of the room without doxxing it.
        wifi, lan = _anonymize(wifi, lan, ssid)
        with self._lock:
            self._wifi, self._lan = wifi, lan
            self._ssid = ""          # your network's name is not for display
            self._updated = time.time()
            self._err = "" if (wifi or lan) else \
                "no probes available on this platform"
            fp = self._fingerprint()
            changed = fp != self._last_fp
            self._last_fp = fp
            cb = self._cb
        # Outside the lock: a contact-set change is worth announcing — the UI
        # logs the new picture (first sweep announces itself too).
        if changed and cb:
            try:
                cb(self.snapshot())
            except Exception:
                pass

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "wifi":    [dict(b) for b in self._wifi],
                "lan":     [dict(b) for b in self._lan],
                "ssid":    "",
                "age":     time.time() - self._updated if self._updated else -1,
                "err":     self._err,
            }


def _anonymize(wifi: list[dict], lan: list[dict], our_ssid: str) -> tuple[list[dict], list[dict]]:
    """Strip every identifying field and relabel: networks become NET-1…,
    hosts HOST-1…, numbered by stable hash order so the labels don't shuffle
    between sweeps. The BSSID/IP/SSID only survive as a salted hash seed —
    enough to keep each device plotting in the same direction, not enough to
    read the address back. Your own network is flagged so the HUD can mark it
    without printing its name."""
    out_wifi = []
    for b in sorted(wifi, key=lambda x: _angle_for(x.get("bssid", x.get("ssid", "")))):
        seed = _angle_for(b.get("bssid", b.get("ssid", "")))
        out_wifi.append({
            "name":   f"NET-{len(out_wifi) + 1}",
            "signal": b.get("signal", 0),
            "channel": b.get("channel", 0),
            "angle":  seed,
            "ours":   bool(our_ssid) and b.get("ssid", "") == our_ssid,
        })
    out_lan = []
    for d in sorted(lan, key=lambda x: _angle_for(x.get("ip", x.get("mac", "")))):
        # The radar lists WHAT the device is, never WHO: the MAC is consumed
        # here, the type word is what survives.
        out_lan.append({
            "name":   f"HOST-{len(out_lan) + 1}",
            "type":   device_type(d.get("mac", ""), d.get("signal", 60)),
            "signal": d.get("signal", 60),
            "angle":  _angle_for(d.get("ip", d.get("mac", ""))),
        })
    return out_wifi, out_lan


_scan: SurroundingsScan | None = None
_scan_lock = threading.Lock()
_pending_cb = None          # callback registered before the scanner existed


def set_scan_callback(cb) -> None:
    """Register a callback fired (on the scanner thread) whenever a sweep ends
    with a DIFFERENT contact set than the one before — the UI uses this to log
    the anonymised contact list. Safe to call before the first scan."""
    global _scan, _pending_cb
    with _scan_lock:
        if _scan is None:
            _pending_cb = cb            # applied when the scanner is born
            return
        _scan.set_on_change(cb)


def get_surroundings(wait: bool = False, fresh: bool = False) -> dict:
    """Process-wide scanner, created lazily so merely importing this module
    costs nothing until a radar actually exists.

    wait=True  — block (bounded) until the FIRST sweep has landed, for callers
                 that need real data now. The background thread starts sweeping
                 on birth, but netsh takes a second or two; without the wait a
                 caller born a moment ago reads an empty room.
    fresh=True — run a synchronous sweep right now so the report reflects this
                 instant rather than the last periodic one. Only for executor-
                 thread callers (the spoken report); the UI timer must never
                 block the paint thread on a subprocess.
    """
    global _scan, _pending_cb
    with _scan_lock:
        if _scan is None:
            _scan = SurroundingsScan()
            if _pending_cb is not None:
                _scan.set_on_change(_pending_cb)
                _pending_cb = None
        scanner = _scan
    if wait:
        for _ in range(60):                     # bounded: ≤ 15 s, then give up
            if scanner._updated:
                break
            time.sleep(0.25)
    if fresh:
        try:
            scanner._sweep()
        except Exception:
            pass
    return scanner.snapshot()
