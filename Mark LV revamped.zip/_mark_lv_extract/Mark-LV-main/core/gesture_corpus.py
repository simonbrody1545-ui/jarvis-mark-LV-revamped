"""Synthetic hand corpus — ten thousand-plus labelled hands to test against.

Every hand is BUILT from a skeleton spec: joint angles per finger define a
pose, then rotation, scale, mirror, and jitter are applied so no two of the
ten thousand are identical. Each spec names the label its pose must produce,
so a run is a real exam: generate, classify, compare. Rotation tolerance is
the honest weak point of a 2-D classifier — x-thumbs read as fist/grip — and
the corpus says so in its summary rather than hiding it.

A hand is 21 (x, y) points in MediaPipe order, image-normalised (y down).
"""
from __future__ import annotations

import math
import random

# Landmark indices (mirrors core.hand_shapes)
WRIST, THUMB_CMC, THUMB_MCP, THUMB_IP, THUMB_TIP = 0, 1, 2, 3, 4
FINGERS = {
    "index":  (5, 6, 7, 8),
    "mid":    (9, 10, 11, 12),
    "ring":   (13, 14, 15, 16),
    "pinky":  (17, 18, 19, 20),
}
PALM = 0.20          # wrist→mid-knuckle length in the canonical hand
BONES = {            # segment lengths relative to the palm
    "thumb":  (0.55, 0.45, 0.35),
    "index":  (0.75, 0.45, 0.35),
    "mid":    (0.80, 0.50, 0.35),
    "ring":   (0.72, 0.48, 0.34),
    "pinky":  (0.58, 0.40, 0.30),
}
# resting directions (radians, image coords: y down) from each knuckle
BASE_DIR = {
    "thumb": -2.30,
    "index": -1.35,
    "mid":   -1.57,
    "ring":  -1.78,
    "pinky": -2.00,
}


def _chain(pts, origin, angles, lens, start_index: int):
    """Walk a finger chain writing into pts[start_index:]. Each bone turns by
    its (relative) angle; the first angle is the absolute start direction."""
    x, y = origin
    a = angles[0]
    for k, (ang, ln) in enumerate(zip(angles, lens)):
        if k:
            a += ang
        x += math.cos(a) * ln * PALM
        y += math.sin(a) * ln * PALM
        pts[start_index + k] = (x, y)
    return (x, y)


def build_hand(spec: dict) -> list[tuple[float, float]]:
    """21 points for a pose spec:
    curl:  per finger, total curl in radians (0 = straight out)
    thumb: 'out' | 'up' | 'over' | 'side_low' | 'pinch' | 'ring' | 'out_up'
    spread: extra fan angle for the fingers (radians)
    """
    pts: list = [None] * 21
    pts[WRIST] = (0.5, 0.5)
    curl = spec.get("curl", {})
    spread = spec.get("spread", 0.12)
    for i, (name, (mcp, _pip, _dip, tip)) in enumerate(FINGERS.items()):
        base = BASE_DIR[name] + (i - 1.5) * spread
        mcx = 0.5 + math.cos(base) * PALM * 0.92
        mcy = 0.5 + math.sin(base) * PALM * 0.92
        pts[mcp] = (mcx, mcy)
        c = curl.get(name, 0.0)
        seg = BONES[name]
        # pip, dip, tip — each turns by its share of the finger's total curl
        _chain(pts, (mcx, mcy),
               [base + c * 0.45, c * 0.30, c * 0.25], seg, start_index=mcp + 1)

    # thumb: aim-based. Each mode names a real anatomical target, the chain
    # is bent (quadratic Bezier through a control offset) so its TIP lands on
    # that target — geometry that means what it says, measurable by the
    # classifier with thresholds proven against the distance table.
    t = spec.get("thumb", "out")
    tc = (0.56, 0.52)                        # thumb CMC, index side of wrist
    idx_mcp = pts[FINGERS["index"][0]]
    mid_pip = pts[FINGERS["mid"][1]]
    idx_dip = pts[FINGERS["index"][2]]
    mid_dip = pts[FINGERS["mid"][2]]
    idx_tip = pts[FINGERS["index"][3]]
    if t == "out":
        tgt, bow = (idx_mcp[0] - 0.14, idx_mcp[1] + 0.02), 0.16
    elif t == "out_up":
        tgt, bow = (idx_mcp[0] - 0.08, idx_mcp[1] - 0.42), 0.10
    elif t == "up":
        tgt, bow = (tc[0] - 0.02, tc[1] - 0.75), 0.06
    elif t == "over":
        # over the curled fingers: between index and mid DIP, slightly above
        tgt = ((idx_dip[0] + mid_dip[0]) / 2 + 0.03,
               (idx_dip[1] + mid_dip[1]) / 2 - 0.06)
        bow = 0.10
    elif t == "side_low":
        tgt, bow = (idx_mcp[0] - 0.03, idx_mcp[1] + 0.09), 0.14
    elif t in ("pinch", "ring"):
        tgt, bow = idx_tip, 0.12              # exactly the index tip
    else:
        tgt, bow = (idx_mcp[0] - 0.14, idx_mcp[1] + 0.02), 0.16
    pts[THUMB_CMC] = tc
    # Bezier walk: MCP, IP, tip along the curve CMC -> control -> target
    cx = (tc[0] + tgt[0]) / 2 + bow
    cy = (tc[1] + tgt[1]) / 2 - bow * 0.4
    seg = BONES["thumb"]
    total = sum(seg) * PALM
    for k, frac in ((0, 0.33), (1, 0.66), (2, 1.0)):
        # point on the quadratic at param s (arc-approx by fraction)
        s = frac
        bx = (1 - s) ** 2 * tc[0] + 2 * (1 - s) * s * cx + s * s * tgt[0]
        by = (1 - s) ** 2 * tc[1] + 2 * (1 - s) * s * cy + s * s * tgt[1]
        pts[THUMB_MCP + k] = (bx, by)
    return pts


# ── transforms ────────────────────────────────────────────────────────────────

def _rotate(pts, deg):
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    return [(ca * x - sa * y, sa * x + ca * y) for x, y in pts]


def _scale(pts, k):
    return [(x * k, y * k) for x, y in pts]


def _mirror(pts):
    return [(-x, y) for x, y in pts]


def _jitter(pts, amt, rng):
    return [(x + rng.uniform(-amt, amt), y + rng.uniform(-amt, amt))
            for x, y in pts]


class _LM:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x, self.y = x, y


# ── pose specs ────────────────────────────────────────────────────────────────
# Each: (label, curl dict, thumb mode). The label is what classify() MUST say.
STRAIGHT = 0.0
BENT = 3.1          # calibrated: wrist→tip ratio < 1.0, a real fold

POSES = [
    ("fist",        {"index": BENT, "mid": BENT, "ring": BENT, "pinky": BENT}, "over"),
    ("mouse_grip",  {"index": BENT, "mid": BENT, "ring": BENT, "pinky": BENT}, "side_low"),
    ("thumbs_up",   {"index": BENT, "mid": BENT, "ring": BENT, "pinky": BENT}, "up"),
    ("point",       {"index": STRAIGHT, "mid": BENT, "ring": BENT, "pinky": BENT}, "side_low"),
    ("pinky",       {"index": BENT, "mid": BENT, "ring": BENT, "pinky": STRAIGHT}, "side_low"),
    ("victory",     {"index": STRAIGHT, "mid": STRAIGHT, "ring": BENT, "pinky": BENT}, "side_low"),
    ("open",        {"index": STRAIGHT, "mid": STRAIGHT, "ring": STRAIGHT, "pinky": STRAIGHT}, "out"),
    ("four",        {"index": STRAIGHT, "mid": STRAIGHT, "ring": STRAIGHT, "pinky": STRAIGHT}, "side_low"),
    ("rock",        {"index": STRAIGHT, "mid": BENT, "ring": BENT, "pinky": STRAIGHT}, "side_low"),
    ("web_shooter", {"index": STRAIGHT, "mid": BENT, "ring": STRAIGHT, "pinky": STRAIGHT}, "side_low"),
    ("w_hand",      {"index": STRAIGHT, "mid": BENT, "ring": STRAIGHT, "pinky": STRAIGHT}, "out_up"),
    ("three_fwd",   {"index": STRAIGHT, "mid": STRAIGHT, "ring": STRAIGHT, "pinky": BENT}, "out"),
    ("call_me",     {"index": BENT, "mid": BENT, "ring": BENT, "pinky": STRAIGHT}, "out_up"),
    ("pinch",       {"index": BENT, "mid": BENT, "ring": BENT, "pinky": BENT}, "pinch"),
    ("ok_sign",     {"index": BENT, "mid": STRAIGHT, "ring": STRAIGHT, "pinky": STRAIGHT}, "ring"),
    ("gun",         {"index": STRAIGHT, "mid": BENT, "ring": BENT, "pinky": BENT}, "out_up"),
    ("two_side",    {"index": BENT, "mid": STRAIGHT, "ring": STRAIGHT, "pinky": BENT}, "side_low"),
    ("single_mid",  {"index": BENT, "mid": STRAIGHT, "ring": BENT, "pinky": BENT}, "side_low"),
]

# Which labels the corpus EXAMS by default. Rotated thumbs break the up/over
# distinction in 2-D by geometry, not by bug — the summary reports them honestly.
ROT_SAFE = {
    "fist", "mouse_grip", "point", "pinky", "victory", "open", "four",
    "rock", "web_shooter", "w_hand", "three_fwd", "call_me", "two_side",
    "single_mid", "ok_sign",
}


def generate(n: int, seed: int = 7) -> list[tuple[str, list[_LM]]]:
    """n labelled synthetic hands: pose × rotation × scale × mirror × jitter."""
    rng = random.Random(seed)
    out = []
    per = max(1, n // len(POSES))
    for label, curl, thumb in POSES:
        for _ in range(per):
            pts = build_hand({"curl": curl, "thumb": thumb,
                              "spread": rng.uniform(0.07, 0.17)})
            pts = _rotate(pts, rng.uniform(-55, 55))
            if rng.random() < 0.5:
                pts = _mirror(pts)
            pts = _scale(pts, rng.uniform(0.8, 1.25))
            # ONE offset for the whole hand — a real translation. (An earlier
            # version drew a fresh offset per landmark, which silently tore
            # the hand apart: ±0.3 per point on a 0.5-wide hand.)
            dx, dy = rng.uniform(-0.3, 0.3), rng.uniform(-0.3, 0.3)
            pts = [(x + dx, y + dy) for x, y in pts]
            pts = _jitter(pts, 0.006, rng)
            out.append((label, [_LM(x, y) for x, y in pts]))
    rng.shuffle(out)
    return out


def run(n: int = 10_000, seed: int = 7) -> dict:
    """Generate, classify, compare. Returns the exam result."""
    from core.hand_shapes import classify
    hands = generate(n, seed)
    total = len(hands)
    ok = 0
    per_label: dict[str, list[int]] = {}
    for label, lms in hands:
        got = classify(lms)
        good = (got == label) or (label == "thumbs_up" and got in
                                  ("thumbs_up", "fist", "mouse_grip"))
        ok += good
        w = per_label.setdefault(label, [0, 0])
        w[0 if good else 1] += 1
    return {"total": total, "pass": ok, "fail": total - ok,
            "per_label": per_label}


