// STARK INDUSTRIES CAD COMPONENT: ARC REACTOR HOUSING
// Mark LIV Parametric OpenSCAD Source

$fn = 60;
r_outer = 45;
r_inner = 25;
height = 18;

module arc_reactor() {
    difference() {
        cylinder(r=r_outer, h=height, center=true);
        cylinder(r=r_inner, h=height + 2, center=true);
    }
    
    // Core ring
    cylinder(r=r_inner - 2, h=height + 6, center=true);
    
    // Magnetic damper coils
    for (i = [0:9]) {
        rotate([0, 0, i * 36])
        translate([r_outer - 4, 0, 0])
        cube([10, 7, height + 4], center=true);
    }
}

arc_reactor();
