document.addEventListener('DOMContentLoaded', function() { var q = document.getElementById('tut-q'); if (q) q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.stopPropagation(); askBuild(); } }); });
;

    const svgCode = `<svg width="800" height="600" viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="600" fill="#00060a"/>
  <circle cx="400" cy="300" r="180" stroke="#009fff" stroke-width="1.5" fill="none" opacity="0.4" stroke-dasharray="8 4"/>
  <circle cx="400" cy="300" r="130" stroke="#009fff" stroke-width="2" fill="none" opacity="0.7"/>
  <circle cx="400" cy="300" r="70" stroke="#ffaa00" stroke-width="1.5" fill="none" opacity="0.6"/>
  <line x1="200" y1="300" x2="600" y2="300" stroke="#009fff" stroke-width="1" opacity="0.3"/>
  <line x1="400" y1="100" x2="400" y2="500" stroke="#009fff" stroke-width="1" opacity="0.3"/>
  <rect x="320" y="240" width="160" height="120" stroke="#009fff" stroke-width="2" fill="none" opacity="0.8"/>
  <text x="40" y="50" fill="#009fff" font-family="monospace" font-size="16" letter-spacing="2">MARK LIV // HOLOGRAPHIC PROJECTION: A LIGHTSABER</text>
  <text x="40" y="75" fill="#ffaa00" font-family="monospace" font-size="11">STATUS: VOLUMETRIC SYNTHESIS NOMINAL</text>
  <text x="640" y="560" fill="#009fff" font-family="monospace" font-size="10">STARK INDUSTRIES</text>
</svg>`;
    document.getElementById('svg-host').innerHTML = svgCode;

    function openBlueprint() {
      document.getElementById('blueprint-modal').style.display = 'flex';
    }
    function closeBlueprint() {
      document.getElementById('blueprint-modal').style.display = 'none';
    }

    // Three.js Holographic Setup with Enhanced 3D Depth
    const scene = new THREE.Scene();
    
    // Enhanced camera with stronger perspective for better 3D perception
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(60, 40, 80);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setClearColor(0x00080a, 1); // Deep background
    document.body.appendChild(renderer.domElement);

    // Stage sizing that never trusts a zero-size window: embedded webviews and
    // pre-layout loads can report innerWidth/Height 0 at script time, which
    // collapses the canvas to 0x0 and kills the projection for good (no
    // resize event ever fires to fix it). fitStage() clamps to >=1 px, derives
    // the aspect safely, and is re-run from several hooks so the stage always
    // matches the real viewport.
    function fitStage() {
      const w = Math.max(1, window.innerWidth  || document.documentElement.clientWidth  || 960);
      const h = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 600);
      // same-size calls realloc the GL drawing buffer mid-render and the
      // context rejects the in-flight batch — vertex-buffer warning spam
      if (renderer.domElement.width === w * window.devicePixelRatio &&
          renderer.domElement.height === h * window.devicePixelRatio) return;
      renderer.setSize(w, h, true);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }
    fitStage();

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 30;
    controls.maxDistance = 200;

    // Enhanced multi-directional lighting for 3D depth
    scene.add(new THREE.AmbientLight(0x002233, 0.5));
    
    const pLight = new THREE.PointLight('#009fff', 3, 400);
    pLight.position.set(50, 80, 50);
    scene.add(pLight);
    
    const pLight2 = new THREE.PointLight('#009fff', 2, 300);
    pLight2.position.set(-50, 40, -50);
    scene.add(pLight2);
    
    const pLight3 = new THREE.PointLight(0xff6600, 1.5, 250);
    pLight3.position.set(0, -30, 60);
    scene.add(pLight3);

    // Enhanced 3D coordinate grid with depth
    const grid = new THREE.GridHelper(160, 32, '#009fff', 0x052336);
    grid.position.y = -35;
    grid.material.opacity = 0.3;
    grid.material.transparent = true;
    scene.add(grid);
    
    // Add vertical grid for 3D depth perception
    const gridV = new THREE.GridHelper(160, 32, '#009fff', 0x052336);
    gridV.rotation.x = Math.PI / 2;
    gridV.position.z = -35;
    gridV.material.opacity = 0.2;
    gridV.material.transparent = true;
    scene.add(gridV);

    // Enhanced 3D fog for atmospheric depth
    scene.fog = new THREE.FogExp2(0x00080a, 0.008);

    // Rotating Holographic Concentric Tech Rings with 3D depth
    function makeRing(rad, y, opacity = 0.35) {
      const geo = new THREE.RingGeometry(rad, rad + 0.8, 128);
      const mat = new THREE.MeshBasicMaterial({
        color: '#009fff',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: opacity,
        wireframe: true,
        blending: THREE.AdditiveBlending
      });
      const ring = new THREE.Mesh(geo, mat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = y;
      scene.add(ring);
      return ring;
    }
    
    // Multiple ring layers for depth perception
    const ringInner = makeRing(50, -34.8, 0.5);
    const ringMiddle = makeRing(60, -34.8, 0.35);
    const ringOuter = makeRing(72, -34.8, 0.25);
    const ringOuter2 = makeRing(85, -34.8, 0.15);

    // Enhanced 3D Scanning Laser Beam with depth
    const scanPlaneGeo = new THREE.PlaneGeometry(150, 0.6);
    const scanPlaneMat = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      transparent: true,
      opacity: 0.7,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending
    });
    const scanBeam = new THREE.Mesh(scanPlaneGeo, scanPlaneMat);
    scanBeam.rotation.x = Math.PI / 2;
    scene.add(scanBeam);
    
    // Add horizontal scanning beam for 3D depth
    const scanBeamH = new THREE.Mesh(scanPlaneGeo, scanPlaneMat);
    scanBeamH.rotation.z = Math.PI / 2;
    scene.add(scanBeamH);

    // Object Group with enhanced depth
    const hologramGroup = new THREE.Group();
    scene.add(hologramGroup);

    let currentHex = '#009fff';
    let lineMaterial = new THREE.LineBasicMaterial({
      color: currentHex,
      linewidth: 2,
      transparent: true,
      opacity: 0.9
    });
    let wireMaterial = new THREE.MeshBasicMaterial({
      color: currentHex,
      wireframe: true,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending
    });

    let autoSpin = true;
    let stereoscopicMode = false;
    
    function toggleSpin() {
      autoSpin = !autoSpin;
    }
    
    function toggleStereoscopic() {
      stereoscopicMode = !stereoscopicMode;
      if (stereoscopicMode) {
        camera.position.set(50, 35, 70);
        camera.fov = 75;
        camera.updateProjectionMatrix();
        scene.fog.density = 0.012;
        grid.material.opacity = 0.5;
        gridV.material.opacity = 0.4;
      } else {
        camera.position.set(60, 40, 80);
        camera.fov = 60;
        camera.updateProjectionMatrix();
        scene.fog.density = 0.008;
        grid.material.opacity = 0.3;
        gridV.material.opacity = 0.2;
      }
    }

    // Execute Dynamic Three.js Geometry for ANY object.
    // The synthesiser returns the BODY of populateCustomHologram (if the model
    // added its own wrapper declaration anyway, Python unwraps it back to a
    // body), so it is re-wrapped here exactly once and then called. If the
    // dynamic code fails to parse or run, the procedural Stark fallback
    // builds a real object locally — never the bare geometric sphere.
    function populateCustomHologram(group, colorHex, lineMaterial, wireMaterial) {
      
    // ═══ Procedural holographic projection: a lightsaber ═══
    // Built locally (model unavailable) — still a full Stark-style projection.

    function _mat(op) {
        return new THREE.MeshBasicMaterial({ color: colorHex, transparent: true,
            opacity: op, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
            depthWrite: false });
    }
    function _add(geo, x, y, z, rx, ry, rz, op, scale) {
        const m = new THREE.Mesh(geo, _mat(op === undefined ? 0.30 : op));
        m.position.set(x || 0, y || 0, z || 0);
        m.rotation.set(rx || 0, ry || 0, rz || 0);
        if (scale) m.scale.set(scale[0], scale[1], scale[2]);
        group.add(m);
        const w = new THREE.Mesh(geo, _mat(0.9));
        w.material.wireframe = true;
        w.position.copy(m.position); w.rotation.copy(m.rotation);
        if (scale) w.scale.set(scale[0], scale[1], scale[2]);
        group.add(w);
        return m;
    }
    // _named: like _add, but into a labelled Group — the part the viewer
    // disassembles, drags and names on screen.
    function _named(name, build) {
        const g = new THREE.Group();
        g.userData.partName = name;
        group.add(g);
        const save = group.add.bind(group);
        group.add = (o) => { g.add(o); return o; };
        try { build(); } finally { group.add = save; }
        return g;
    }

    // ── the object itself ──────────────────────────────────────────────────
    const B = buildHead;
    const animated = B();

    function buildReactor() {
        // The classic arc-reactor: back plate, coil ring, thick outer ring,
        // inner rings and the glowing triangular core — facing the viewer.
        const parts = [];
        const CY = 10;                                  // floats above the pad
        parts.push(_named('BACK PLATE', () => {
            _add(new THREE.CylinderGeometry(10.5, 10.5, 0.9, 32),
                 0, CY, -0.8, Math.PI / 2, 0, 0, 0.22);
        }));
        parts.push(_named('OUTER RING', () => {
            _add(new THREE.TorusGeometry(9.6, 1.05, 10, 48),
                 0, CY, 0, 0, 0, 0, 0.42);
        }));
        parts.push(_named('COIL RING · 10 SEGMENTS', () => {
            for (let i = 0; i < 10; i++) {
                const a = i * Math.PI / 5;
                _add(new THREE.BoxGeometry(2.1, 2.5, 1.7),
                     Math.cos(a) * 7.1, CY + Math.sin(a) * 7.1, 0.4,
                     0, 0, a + Math.PI / 2, 0.38);
            }
        }));
        parts.push(_named('INNER RING', () => {
            _add(new THREE.TorusGeometry(4.6, 0.4, 8, 40), 0, CY, 0.6, 0, 0, 0, 0.5);
        }));
        parts.push(_named('TRIANGLE CORE', () => {
            // THE TRIANGLE CORE — prism with 3 sides, pointing up
            const tri = _add(new THREE.CylinderGeometry(2.9, 2.9, 0.55, 3, 1),
                             0, CY, 1.0, Math.PI / 2, 0, 0, 0.55);
            tri.rotation.z = 0;                         // vertex up
            _add(new THREE.TorusGeometry(1.7, 0.22, 8, 32), 0, CY, 1.4, 0, 0, 0, 0.6);
        }));
        return parts;
    }

    function buildHumanoid() {
        const parts = [];
        parts.push(_named('HEAD', () => {
            _add(new THREE.SphereGeometry(4.2, 16, 12), 0, 26.5, 0, 0, 0, 0, 0.35);
            _add(new THREE.CylinderGeometry(1.6, 2.4, 4, 10), 0, 21.5, 0);   // neck
        }));
        parts.push(_named('TORSO · ARC REACTOR', () => {
            _add(new THREE.CylinderGeometry(5.5, 4, 13, 12), 0, 12.5, 0);
            _add(new THREE.TorusGeometry(3.2, 0.5, 8, 32), 0, 14.5, 3.4, 0, 0, 0);
        }));
        parts.push(_named('SHOULDER ASSEMBLY', () => {
            _add(new THREE.BoxGeometry(15.5, 4.5, 6.5), 0, 17.5, 0);
        }));
        parts.push(_named('LEFT ARM', () => {
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), -9.6, 10, 0, 0, 0, 0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), -10.4, 2.6, 0);
        }));
        parts.push(_named('RIGHT ARM', () => {
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), 9.6, 10, 0, 0, 0, -0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), 10.4, 2.6, 0);
        }));
        parts.push(_named('LEFT LEG', () => {
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), -3.4, -6.5, 0, 0, 0, 0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), -3.4, -13.2, 0);
        }));
        parts.push(_named('RIGHT LEG', () => {
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), 3.4, -6.5, 0, 0, 0, -0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), 3.4, -13.2, 0);
        }));
        return parts;
    }

    function buildAircraft() {
        const parts = [];
        parts.push(_named('FUSELAGE + NOSE', () => {
            _add(new THREE.CylinderGeometry(3.2, 1.4, 26, 14), 0, 0, 0, 1.5708, 0, 0);
            _add(new THREE.SphereGeometry(3.2, 14, 10), 0, 0.5, 13, 0, 0, 0, 0.08, [1, 0.72, 1]);
            _add(new THREE.TorusGeometry(2.2, 0.45, 8, 24), 0, 0, 14.2);   // intake glow
        }));
        parts.push(_named('MAIN WINGS', () => {
            _add(new THREE.BoxGeometry(30, 0.7, 7), 0, -0.6, -1.5);
        }));
        parts.push(_named('TAIL SECTION', () => {
            _add(new THREE.BoxGeometry(11, 0.6, 4), 0, 1.8, -12.4);
            _add(new THREE.BoxGeometry(0.7, 6.2, 5.4), 0, 3.4, -12.2);
        }));
        parts.push(_named('ENGINES · LEFT + RIGHT', () => {
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), -6.5, -1.8, -1.5, 1.5708, 0, 0);
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), 6.5, -1.8, -1.5, 1.5708, 0, 0);
        }));
        return parts;
    }

    function buildVehicle() {
        const parts = [];
        parts.push(_named('CHASSIS', () => {
            _add(new THREE.BoxGeometry(9, 4, 19), 0, 0, 0);
        }));
        parts.push(_named('CABIN', () => {
            _add(new THREE.BoxGeometry(7.6, 3.6, 9), 0, 3.6, -1.2);
            _add(new THREE.BoxGeometry(6.4, 1.6, 0.4), 0, 3.4, 3.4);       // windshield
        }));
        parts.push(_named('HOOD', () => {
            _add(new THREE.BoxGeometry(8.2, 1.2, 4.6), 0, 1.4, 9.6);
        }));
        parts.push(_named('WHEELS · 4×', () => {
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, -6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, -6.2, 0, 0, 1.5708);
        }));
        return parts;
    }

    function buildStructure() {
        const parts = [];
        parts.push(_named('TIERED BLOCKS · 6×', () => {
            for (let i = 0; i < 6; i++) {
                const w = 16 - i * 2.1;
                _add(new THREE.BoxGeometry(w, 5.5, w), 0, 2.75 + i * 5.5, 0);
            }
        }));
        parts.push(_named('SPIRE', () => {
            _add(new THREE.CylinderGeometry(0.8, 1.6, 8, 8), 0, 38, 0);
        }));
        parts.push(_named('STRUCTURAL BRACES · 4×', () => {
            for (let i = 0; i < 4; i++) {
                const a = i * 1.5708 + 0.7854;
                _add(new THREE.BoxGeometry(1.2, 36, 1.2), Math.cos(a) * 8.5, 18, Math.sin(a) * 8.5);
            }
        }));
        return parts;
    }

    function buildHelix() {
        const parts = [];
        parts.push(_named('HELIX STRANDS · 2×', () => {
        const pts1 = [], pts2 = [];
        for (let i = 0; i <= 60; i++) {
            const t = i / 60, a = t * Math.PI * 4.5;
            pts1.push(new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7));
            pts2.push(new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7));
        }
        const lm = new THREE.LineBasicMaterial({ color: colorHex, transparent: true, opacity: 0.9 });
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts1), lm));
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts2), lm));
        }));
        parts.push(_named('BASE PAIRS · 13×', () => {
            for (let i = 0; i <= 12; i++) {
                const t = i / 12, a = t * Math.PI * 4.5;
                const v1 = new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7);
                const v2 = new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7);
                const mid = v1.clone().add(v2).multiplyScalar(0.5);
                const g = new THREE.CylinderGeometry(0.28, 0.28, 14, 6);
                const m = new THREE.Mesh(g, _mat(0.35));
                m.position.copy(mid);
                m.rotation.z = 1.5708; m.rotation.y = -a;
                group.add(m);
            }
        }));
        return parts;
    }

    function buildHead() {
        const parts = [];
        parts.push(_named('CRANIUM', () => {
            const skull = new THREE.SphereGeometry(9, 20, 14);
            skull.scale(0.86, 1.06, 0.94);
            _add(skull, 0, 2, 0, 0, 0, 0, 0.3);
        }));
        parts.push(_named('JAW', () => {
            const jaw = new THREE.SphereGeometry(5.4, 16, 10);
            jaw.scale(0.82, 0.7, 0.9);
            _add(jaw, 0, -6.4, 2.2, 0, 0, 0, 0.3);
        }));
        parts.push(_named('OPTICAL SENSORS · 2×', () => {
            _add(new THREE.SphereGeometry(1.05, 8, 8), -3.2, 3.4, 7.6, 0, 0, 0, 0.95);
            _add(new THREE.SphereGeometry(1.05, 8, 8), 3.2, 3.4, 7.6, 0, 0, 0, 0.95);
        }));
        parts.push(_named('NASAL ARRAY', () => {
            _add(new THREE.ConeGeometry(1.1, 3.6, 8), 0, -1.2, 9.2, 1.5708, 0, 0, 0.5);
        }));
        parts.push(_named('HELMET RIM', () => {
            const rm = new THREE.Mesh(new THREE.RingGeometry(8.9, 9.15, 48), _mat(0.6));
            rm.position.set(0, 2, 0);
            group.add(rm);
        }));
        return parts;
    }

    // ── projection pad, holo rings, drift — the Stark dressing ───────────
    // One labelled rig group so disassembly never tears the stage down with it.
    let pad, padRing, dust, scan;
    const holoRings = [];
    const rig = _named('PROJECTION RIG', () => {
        pad = new THREE.Mesh(new THREE.CylinderGeometry(26, 26, 0.5, 48), _mat(0.10));
        pad.position.y = -21;
        group.add(pad);
        padRing = new THREE.Mesh(new THREE.TorusGeometry(26.5, 0.35, 8, 96), _mat(0.55));
        padRing.rotation.x = 1.5708;
        padRing.position.y = -20.6;
        group.add(padRing);
        for (let i = 0; i < 3; i++) {
            const rg = new THREE.Mesh(new THREE.TorusGeometry(15 + i * 5.5, 0.28, 8, 72), _mat(0.4 - i * 0.1));
            rg.rotation.x = 1.5708 + (i - 1) * 0.22;
            group.add(rg);
            holoRings.push(rg);
        }
        // floating dust particles inside the projection volume
        const pN = 140, pGeo = new THREE.BufferGeometry();
        const pPos = new Float32Array(pN * 3);
        for (let i = 0; i < pN; i++) {
            pPos[i * 3]     = (Math.random() - 0.5) * 46;
            pPos[i * 3 + 1] = (Math.random() - 0.5) * 44;
            pPos[i * 3 + 2] = (Math.random() - 0.5) * 46;
        }
        pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
        const pMat = new THREE.PointsMaterial({ color: colorHex, size: 0.9,
            transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
        dust = new THREE.Points(pGeo, pMat);
        group.add(dust);
        // scan plane sweeping up the object
        scan = new THREE.Mesh(new THREE.PlaneGeometry(56, 0.9), _mat(0.45));
        scan.rotation.x = -1.5708;
        group.add(scan);
    });
    rig.userData.isRig = true;   // never flies apart — it is the stage itself

    // everything the viewer's animation loop already knows how to drive
    group.userData.hologramParts = {
        core: animated[0] || null,
        wireCore2: null,
        ring1: holoRings[0], ring2: holoRings[1], ring3: holoRings[2], ring4: null,
        scan: scan,
        particles: dust,
        particleVelocities: null,
        basePositions: null,
        padRing: padRing
    };

    }

    function buildProceduralFallback(group, colorHex, lineMaterial, wireMaterial) {
      
    // ═══ Procedural holographic projection: a lightsaber ═══
    // Built locally (model unavailable) — still a full Stark-style projection.

    function _mat(op) {
        return new THREE.MeshBasicMaterial({ color: colorHex, transparent: true,
            opacity: op, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
            depthWrite: false });
    }
    function _add(geo, x, y, z, rx, ry, rz, op, scale) {
        const m = new THREE.Mesh(geo, _mat(op === undefined ? 0.30 : op));
        m.position.set(x || 0, y || 0, z || 0);
        m.rotation.set(rx || 0, ry || 0, rz || 0);
        if (scale) m.scale.set(scale[0], scale[1], scale[2]);
        group.add(m);
        const w = new THREE.Mesh(geo, _mat(0.9));
        w.material.wireframe = true;
        w.position.copy(m.position); w.rotation.copy(m.rotation);
        if (scale) w.scale.set(scale[0], scale[1], scale[2]);
        group.add(w);
        return m;
    }
    // _named: like _add, but into a labelled Group — the part the viewer
    // disassembles, drags and names on screen.
    function _named(name, build) {
        const g = new THREE.Group();
        g.userData.partName = name;
        group.add(g);
        const save = group.add.bind(group);
        group.add = (o) => { g.add(o); return o; };
        try { build(); } finally { group.add = save; }
        return g;
    }

    // ── the object itself ──────────────────────────────────────────────────
    const B = buildHead;
    const animated = B();

    function buildReactor() {
        // The classic arc-reactor: back plate, coil ring, thick outer ring,
        // inner rings and the glowing triangular core — facing the viewer.
        const parts = [];
        const CY = 10;                                  // floats above the pad
        parts.push(_named('BACK PLATE', () => {
            _add(new THREE.CylinderGeometry(10.5, 10.5, 0.9, 32),
                 0, CY, -0.8, Math.PI / 2, 0, 0, 0.22);
        }));
        parts.push(_named('OUTER RING', () => {
            _add(new THREE.TorusGeometry(9.6, 1.05, 10, 48),
                 0, CY, 0, 0, 0, 0, 0.42);
        }));
        parts.push(_named('COIL RING · 10 SEGMENTS', () => {
            for (let i = 0; i < 10; i++) {
                const a = i * Math.PI / 5;
                _add(new THREE.BoxGeometry(2.1, 2.5, 1.7),
                     Math.cos(a) * 7.1, CY + Math.sin(a) * 7.1, 0.4,
                     0, 0, a + Math.PI / 2, 0.38);
            }
        }));
        parts.push(_named('INNER RING', () => {
            _add(new THREE.TorusGeometry(4.6, 0.4, 8, 40), 0, CY, 0.6, 0, 0, 0, 0.5);
        }));
        parts.push(_named('TRIANGLE CORE', () => {
            // THE TRIANGLE CORE — prism with 3 sides, pointing up
            const tri = _add(new THREE.CylinderGeometry(2.9, 2.9, 0.55, 3, 1),
                             0, CY, 1.0, Math.PI / 2, 0, 0, 0.55);
            tri.rotation.z = 0;                         // vertex up
            _add(new THREE.TorusGeometry(1.7, 0.22, 8, 32), 0, CY, 1.4, 0, 0, 0, 0.6);
        }));
        return parts;
    }

    function buildHumanoid() {
        const parts = [];
        parts.push(_named('HEAD', () => {
            _add(new THREE.SphereGeometry(4.2, 16, 12), 0, 26.5, 0, 0, 0, 0, 0.35);
            _add(new THREE.CylinderGeometry(1.6, 2.4, 4, 10), 0, 21.5, 0);   // neck
        }));
        parts.push(_named('TORSO · ARC REACTOR', () => {
            _add(new THREE.CylinderGeometry(5.5, 4, 13, 12), 0, 12.5, 0);
            _add(new THREE.TorusGeometry(3.2, 0.5, 8, 32), 0, 14.5, 3.4, 0, 0, 0);
        }));
        parts.push(_named('SHOULDER ASSEMBLY', () => {
            _add(new THREE.BoxGeometry(15.5, 4.5, 6.5), 0, 17.5, 0);
        }));
        parts.push(_named('LEFT ARM', () => {
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), -9.6, 10, 0, 0, 0, 0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), -10.4, 2.6, 0);
        }));
        parts.push(_named('RIGHT ARM', () => {
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), 9.6, 10, 0, 0, 0, -0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), 10.4, 2.6, 0);
        }));
        parts.push(_named('LEFT LEG', () => {
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), -3.4, -6.5, 0, 0, 0, 0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), -3.4, -13.2, 0);
        }));
        parts.push(_named('RIGHT LEG', () => {
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), 3.4, -6.5, 0, 0, 0, -0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), 3.4, -13.2, 0);
        }));
        return parts;
    }

    function buildAircraft() {
        const parts = [];
        parts.push(_named('FUSELAGE + NOSE', () => {
            _add(new THREE.CylinderGeometry(3.2, 1.4, 26, 14), 0, 0, 0, 1.5708, 0, 0);
            _add(new THREE.SphereGeometry(3.2, 14, 10), 0, 0.5, 13, 0, 0, 0, 0.08, [1, 0.72, 1]);
            _add(new THREE.TorusGeometry(2.2, 0.45, 8, 24), 0, 0, 14.2);   // intake glow
        }));
        parts.push(_named('MAIN WINGS', () => {
            _add(new THREE.BoxGeometry(30, 0.7, 7), 0, -0.6, -1.5);
        }));
        parts.push(_named('TAIL SECTION', () => {
            _add(new THREE.BoxGeometry(11, 0.6, 4), 0, 1.8, -12.4);
            _add(new THREE.BoxGeometry(0.7, 6.2, 5.4), 0, 3.4, -12.2);
        }));
        parts.push(_named('ENGINES · LEFT + RIGHT', () => {
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), -6.5, -1.8, -1.5, 1.5708, 0, 0);
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), 6.5, -1.8, -1.5, 1.5708, 0, 0);
        }));
        return parts;
    }

    function buildVehicle() {
        const parts = [];
        parts.push(_named('CHASSIS', () => {
            _add(new THREE.BoxGeometry(9, 4, 19), 0, 0, 0);
        }));
        parts.push(_named('CABIN', () => {
            _add(new THREE.BoxGeometry(7.6, 3.6, 9), 0, 3.6, -1.2);
            _add(new THREE.BoxGeometry(6.4, 1.6, 0.4), 0, 3.4, 3.4);       // windshield
        }));
        parts.push(_named('HOOD', () => {
            _add(new THREE.BoxGeometry(8.2, 1.2, 4.6), 0, 1.4, 9.6);
        }));
        parts.push(_named('WHEELS · 4×', () => {
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, -6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, -6.2, 0, 0, 1.5708);
        }));
        return parts;
    }

    function buildStructure() {
        const parts = [];
        parts.push(_named('TIERED BLOCKS · 6×', () => {
            for (let i = 0; i < 6; i++) {
                const w = 16 - i * 2.1;
                _add(new THREE.BoxGeometry(w, 5.5, w), 0, 2.75 + i * 5.5, 0);
            }
        }));
        parts.push(_named('SPIRE', () => {
            _add(new THREE.CylinderGeometry(0.8, 1.6, 8, 8), 0, 38, 0);
        }));
        parts.push(_named('STRUCTURAL BRACES · 4×', () => {
            for (let i = 0; i < 4; i++) {
                const a = i * 1.5708 + 0.7854;
                _add(new THREE.BoxGeometry(1.2, 36, 1.2), Math.cos(a) * 8.5, 18, Math.sin(a) * 8.5);
            }
        }));
        return parts;
    }

    function buildHelix() {
        const parts = [];
        parts.push(_named('HELIX STRANDS · 2×', () => {
        const pts1 = [], pts2 = [];
        for (let i = 0; i <= 60; i++) {
            const t = i / 60, a = t * Math.PI * 4.5;
            pts1.push(new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7));
            pts2.push(new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7));
        }
        const lm = new THREE.LineBasicMaterial({ color: colorHex, transparent: true, opacity: 0.9 });
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts1), lm));
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts2), lm));
        }));
        parts.push(_named('BASE PAIRS · 13×', () => {
            for (let i = 0; i <= 12; i++) {
                const t = i / 12, a = t * Math.PI * 4.5;
                const v1 = new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7);
                const v2 = new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7);
                const mid = v1.clone().add(v2).multiplyScalar(0.5);
                const g = new THREE.CylinderGeometry(0.28, 0.28, 14, 6);
                const m = new THREE.Mesh(g, _mat(0.35));
                m.position.copy(mid);
                m.rotation.z = 1.5708; m.rotation.y = -a;
                group.add(m);
            }
        }));
        return parts;
    }

    function buildHead() {
        const parts = [];
        parts.push(_named('CRANIUM', () => {
            const skull = new THREE.SphereGeometry(9, 20, 14);
            skull.scale(0.86, 1.06, 0.94);
            _add(skull, 0, 2, 0, 0, 0, 0, 0.3);
        }));
        parts.push(_named('JAW', () => {
            const jaw = new THREE.SphereGeometry(5.4, 16, 10);
            jaw.scale(0.82, 0.7, 0.9);
            _add(jaw, 0, -6.4, 2.2, 0, 0, 0, 0.3);
        }));
        parts.push(_named('OPTICAL SENSORS · 2×', () => {
            _add(new THREE.SphereGeometry(1.05, 8, 8), -3.2, 3.4, 7.6, 0, 0, 0, 0.95);
            _add(new THREE.SphereGeometry(1.05, 8, 8), 3.2, 3.4, 7.6, 0, 0, 0, 0.95);
        }));
        parts.push(_named('NASAL ARRAY', () => {
            _add(new THREE.ConeGeometry(1.1, 3.6, 8), 0, -1.2, 9.2, 1.5708, 0, 0, 0.5);
        }));
        parts.push(_named('HELMET RIM', () => {
            const rm = new THREE.Mesh(new THREE.RingGeometry(8.9, 9.15, 48), _mat(0.6));
            rm.position.set(0, 2, 0);
            group.add(rm);
        }));
        return parts;
    }

    // ── projection pad, holo rings, drift — the Stark dressing ───────────
    // One labelled rig group so disassembly never tears the stage down with it.
    let pad, padRing, dust, scan;
    const holoRings = [];
    const rig = _named('PROJECTION RIG', () => {
        pad = new THREE.Mesh(new THREE.CylinderGeometry(26, 26, 0.5, 48), _mat(0.10));
        pad.position.y = -21;
        group.add(pad);
        padRing = new THREE.Mesh(new THREE.TorusGeometry(26.5, 0.35, 8, 96), _mat(0.55));
        padRing.rotation.x = 1.5708;
        padRing.position.y = -20.6;
        group.add(padRing);
        for (let i = 0; i < 3; i++) {
            const rg = new THREE.Mesh(new THREE.TorusGeometry(15 + i * 5.5, 0.28, 8, 72), _mat(0.4 - i * 0.1));
            rg.rotation.x = 1.5708 + (i - 1) * 0.22;
            group.add(rg);
            holoRings.push(rg);
        }
        // floating dust particles inside the projection volume
        const pN = 140, pGeo = new THREE.BufferGeometry();
        const pPos = new Float32Array(pN * 3);
        for (let i = 0; i < pN; i++) {
            pPos[i * 3]     = (Math.random() - 0.5) * 46;
            pPos[i * 3 + 1] = (Math.random() - 0.5) * 44;
            pPos[i * 3 + 2] = (Math.random() - 0.5) * 46;
        }
        pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
        const pMat = new THREE.PointsMaterial({ color: colorHex, size: 0.9,
            transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
        dust = new THREE.Points(pGeo, pMat);
        group.add(dust);
        // scan plane sweeping up the object
        scan = new THREE.Mesh(new THREE.PlaneGeometry(56, 0.9), _mat(0.45));
        scan.rotation.x = -1.5708;
        group.add(scan);
    });
    rig.userData.isRig = true;   // never flies apart — it is the stage itself

    // everything the viewer's animation loop already knows how to drive
    group.userData.hologramParts = {
        core: animated[0] || null,
        wireCore2: null,
        ring1: holoRings[0], ring2: holoRings[1], ring3: holoRings[2], ring4: null,
        scan: scan,
        particles: dust,
        particleVelocities: null,
        basePositions: null,
        padRing: padRing
    };

    }

    try {
      populateCustomHologram(hologramGroup, currentHex, lineMaterial, wireMaterial);
    } catch(e) {
      console.warn("Dynamic geometry fallback:", e);
      try {
        buildProceduralFallback(hologramGroup, currentHex, lineMaterial, wireMaterial);
      } catch(e2) {
        console.warn("Procedural fallback failed:", e2);
        const fallbackGeo = new THREE.IcosahedronGeometry(28, 2);
        hologramGroup.add(new THREE.LineSegments(new THREE.WireframeGeometry(fallbackGeo), lineMaterial));
      }
    }

    // Particle Cloud
    const partCount = 220;
    const partGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(partCount * 3);
    for (let i = 0; i < partCount * 3; i += 3) {
      pPos[i] = (Math.random() - 0.5) * 160;
      pPos[i + 1] = (Math.random() - 0.5) * 90;
      pPos[i + 2] = (Math.random() - 0.5) * 160;
    }
    partGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const partMat = new THREE.PointsMaterial({ color: currentHex, size: 1.4, transparent: true, opacity: 0.55 });
    const particles = new THREE.Points(partGeo, partMat);
    scene.add(particles);

    // Render style cycling (toolbar button) — same engine as ⚙ CUSTOMISE
    const STYLE_CYCLE = ['hologram', 'solid', 'blueprint'];
    const STYLE_LABEL = { hologram: 'MODE: HOLOGRAM', solid: 'MODE: SOLID', blueprint: 'MODE: SCHEMATIC' };
    function cycleStyle() {
      const next = STYLE_CYCLE[(STYLE_CYCLE.indexOf(holo.style) + 1) % STYLE_CYCLE.length];
      setStyle(next);
      const lbl = document.getElementById('style-cycle');
      if (lbl) lbl.textContent = STYLE_LABEL[next];
    }

    // ═══ Iron-Man-style customisation engine ════════════════════════════
    // Every visual aspect of the projection is a preference: style, colour,
    // glow, opacity, spin, scan/dust/grid. Preferences persist in
    // localStorage, so the suit is configured once and stays configured —
    // across every hologram, and across sessions.
    const HOLO_PRESETS = ['#00d4ff', '#e0143c', '#ffaa00', '#00ff88', '#aa00ff', '#e8f6ff'];
    const HOLO_DEFAULTS = {
      style: 'hologram',
      color: currentHex,
      glow: 1.0,
      opacity: 1.0,
      spin: true,
      spinSpeed: 1.0,
      scan: true,
      dust: true,
      grid: true
    };
    let holo = Object.assign({}, HOLO_DEFAULTS);
    try {
      const raw = localStorage.getItem('holo_prefs_v1');
      if (raw) {
        const saved = JSON.parse(raw);
        Object.keys(holo).forEach(k => { if (saved[k] !== undefined) holo[k] = saved[k]; });
      }
    } catch(e) {}

    function savePrefs() {
      try { localStorage.setItem('holo_prefs_v1', JSON.stringify(holo)); } catch(e) {}
    }

    // Every material the hologram was born with, so style/glow/opacity can
    // be re-applied relative to the ORIGINAL look instead of compounding.
    let holoMats = [];
    (function collectMats() {
      hologramGroup.traverse(c => {
        if (c.material && c.material.opacity !== undefined) {
          if (c.material.userData.baseOpacity === undefined)
            c.material.userData.baseOpacity = c.material.opacity;
          holoMats.push(c.material);
        }
      });
    })();

    function applyColor() {
      const c = holo.color;
      document.documentElement.style.setProperty('--holo-color', c);
      lineMaterial.color.set(c);
      wireMaterial.color.set(c);
      pLight.color.set(c);
      if (pLight2) pLight2.color.set(c);
      [ringInner, ringMiddle, ringOuter, ringOuter2].forEach(r => r && r.material.color.set(c));
      grid.material.color.set(c);
      gridV.material.color.set(c);
      scanPlaneMat.color.set(c);
      holoMats.forEach(m => m.color && m.color.set(c));
      document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('sel', s.dataset.c === c));
      const inp = document.getElementById('cfg-color');
      if (inp && inp.value.toLowerCase() !== c.toLowerCase()) inp.value = c;
      savePrefs();
    }

    function applyStyle() {
      const st = holo.style;
      document.querySelectorAll('#cfg-styles button').forEach(
        b => b.classList.toggle('active', b.dataset.s === st));
      hologramGroup.traverse(c => {
        if (!c.material || c.material.userData.baseOpacity === undefined) return;
        const base = c.material.userData.baseOpacity;
        if (st === 'solid') {
          c.material.wireframe = false;
          c.material.opacity = Math.min(0.85, base * 2.2) * holo.opacity;
        } else if (st === 'blueprint') {
          c.material.wireframe = true;
          c.material.opacity = Math.min(1, base * 1.15) * holo.opacity;
        } else {
          c.material.wireframe = true;
          c.material.opacity = base * holo.opacity;
        }
      });
      grid.material.opacity = st === 'blueprint' ? 0.5 : 0.3;
      gridV.material.opacity = st === 'blueprint' ? 0.35 : 0.2;
      const lbl = document.getElementById('style-cycle');
      if (lbl) lbl.textContent = STYLE_LABEL[st];
      savePrefs();
    }

    function applyGlow() {
      const c = holo.color;
      document.documentElement.style.setProperty('--holo-glow',
        '0 0 ' + Math.round(14 * holo.glow) + 'px ' + c);
      holoMats.forEach(m => {
        const base = m.userData.baseOpacity || 0.3;
        const boost = (m.blending === THREE.AdditiveBlending) ? holo.glow : 1.0;
        m.opacity = Math.min(1, base * holo.opacity * boost);
      });
      savePrefs();
    }

    function applyFx() {
      scanBeam.visible = scanBeamH.visible = holo.scan;
      particles.visible = holo.dust;
      hologramGroup.traverse(c => { if (c.type === 'Points') c.visible = holo.dust; });
      grid.visible = gridV.visible = holo.grid;
      autoSpin = holo.spin;
      savePrefs();
    }

    function applyAll() { applyColor(); applyStyle(); applyGlow(); applyFx(); }

    // ── panel wiring ────────────────────────────────────────────────────
    const cfgPanel = document.getElementById('cfg-panel');
    function toggleCfg() { cfgPanel.classList.toggle('open'); }
    function openCfg()  { cfgPanel.classList.add('open'); }
    function closeCfg() { cfgPanel.classList.remove('open'); }

    function setStyle(s) { holo.style = s; applyStyle(); applyGlow(); }
    function setColor(c) { holo.color = c; applyColor(); applyGlow(); }
    function setGlow(v) {
      holo.glow = v / 100;
      document.getElementById('glow-val').textContent = v + '%';
      applyGlow();
    }
    function setOpacity(v) {
      holo.opacity = v / 100;
      document.getElementById('op-val').textContent = v + '%';
      applyStyle(); applyGlow();
    }
    function setSpin(on) { holo.spin = on; applyFx(); }
    function setSpinSpeed(v) {
      holo.spinSpeed = v / 50;
      document.getElementById('spin-val').textContent = (v / 50).toFixed(1) + 'x';
      savePrefs();
    }
    function setFx(k, on) { holo[k] = on; applyFx(); }
    function resetPrefs() {
      holo = Object.assign({}, HOLO_DEFAULTS);
      document.getElementById('cfg-glow').value = 100;
      document.getElementById('glow-val').textContent = '100%';
      document.getElementById('cfg-op').value = 100;
      document.getElementById('op-val').textContent = '100%';
      document.getElementById('cfg-spin').value = 50;
      document.getElementById('spin-val').textContent = '1.0x';
      document.getElementById('cfg-spinon').checked = true;
      document.getElementById('cfg-scan').checked = true;
      document.getElementById('cfg-dust').checked = true;
      document.getElementById('cfg-grid').checked = true;
      applyAll();
    }

    function toggleColor() {
      const i = HOLO_PRESETS.indexOf(holo.color.toLowerCase());
      setColor(HOLO_PRESETS[(i + 1) % HOLO_PRESETS.length]);
    }

    // build swatches + sync every control to the saved prefs, then apply
    (function initCfg() {
      const sw = document.getElementById('cfg-swatches');
      HOLO_PRESETS.forEach(c => {
        const s = document.createElement('div');
        s.className = 'swatch'; s.dataset.c = c; s.style.background = c;
        s.title = c;
        s.onclick = () => setColor(c);
        sw.appendChild(s);
      });
      document.getElementById('cfg-glow').value = Math.round(holo.glow * 100);
      document.getElementById('glow-val').textContent = Math.round(holo.glow * 100) + '%';
      document.getElementById('cfg-op').value = Math.round(holo.opacity * 100);
      document.getElementById('op-val').textContent = Math.round(holo.opacity * 100) + '%';
      document.getElementById('cfg-spin').value = Math.round(holo.spinSpeed * 50);
      document.getElementById('spin-val').textContent = Number(holo.spinSpeed).toFixed(1) + 'x';
      document.getElementById('cfg-spinon').checked = !!holo.spin;
      document.getElementById('cfg-scan').checked = !!holo.scan;
      document.getElementById('cfg-dust').checked = !!holo.dust;
      document.getElementById('cfg-grid').checked = !!holo.grid;
      applyAll();
    })();

    // Volumetric holographic animation loop with realistic physics
    let time = 0;
    // Render only when the tab is visible; skip duplicate frames at high
    // refresh rates (144 Hz screens do not need 144 WebGL renders per second
    // for a hologram that rotates at 0.008 rad/frame).
    let _lastRender = 0;
    let _warmup = 2;   // first frames skip drawing — the embedded compositor
                       // is not yet attached and the GL context rejects the
                       // batch, spamming vertex-buffer warnings on load
    function animate(now) {
      requestAnimationFrame(animate);
      now = now || performance.now();
      if (document.hidden) return;
      if (_warmup > 0) { _warmup--; return; }
      if (now - _lastRender < 24) return;   // ~40 fps ceiling, smooth at any Hz
      const dt = Math.min(0.05, (now - _lastRender) / 1000);
      _lastRender = now;
      time += dt;
      
      // Smooth rotation with momentum (speed is a preference)
      if (autoSpin) {
        hologramGroup.rotation.y += 0.008 * holo.spinSpeed;
        hologramGroup.rotation.x = Math.sin(time * 0.3) * 0.05;
      }
      
      // Animate holographic parts for volumetric effect
      if (hologramGroup.userData.hologramParts) {
        const parts = hologramGroup.userData.hologramParts;
        
        // Core breathing effect with complex harmonic motion
        if (parts.core) {
          const scale = 1 + Math.sin(time * 2) * 0.04;
          parts.core.scale.set(scale, scale, scale);
        }
        
        // Wireframe secondary rotation for depth
        if (parts.wireCore2) {
          parts.wireCore2.rotation.x += 0.005;
          parts.wireCore2.rotation.y += 0.003;
        }
        
        // Multi-ring rotation at different speeds for depth perception
        if (parts.ring1) parts.ring1.rotation.z += 0.012;
        if (parts.ring2) parts.ring2.rotation.z -= 0.009;
        if (parts.ring3) parts.ring3.rotation.z += 0.007;
        if (parts.ring4) parts.ring4.rotation.z -= 0.005;
        
        // Scanning plane vertical movement with varying speed
        if (parts.scan) {
          parts.scan.position.y = Math.sin(time * 1.8) * 25;
          parts.scan.material.opacity = 0.05 + Math.sin(time * 2) * 0.03;
        }
        
        // Enhanced particle system with individual velocity and Brownian motion
        if (parts.particles && parts.particleVelocities) {
          const positions = parts.particles.geometry.attributes.position.array;
          const basePositions = parts.basePositions;
          const velocities = parts.particleVelocities;
          
          for(let i = 0; i < positions.length; i += 3) {
            // Apply velocity with time-varying component
            positions[i] += velocities[i/3].x + Math.sin(time + i) * 0.02;
            positions[i + 1] += velocities[i/3].y + Math.cos(time + i) * 0.02;
            positions[i + 2] += velocities[i/3].z + Math.sin(time * 0.5 + i) * 0.02;
            
            // Boundary wrapping for continuous effect
            if(Math.abs(positions[i]) > 70) positions[i] *= -0.9;
            if(Math.abs(positions[i + 1]) > 70) positions[i + 1] *= -0.9;
            if(Math.abs(positions[i + 2]) > 70) positions[i + 2] *= -0.9;
          }
          
          parts.particles.geometry.attributes.position.needsUpdate = true;
        }
      }
      
      // Background rings rotation with 3D depth motion
      if (ringInner) ringInner.rotation.z += 0.005;
      if (ringMiddle) ringMiddle.rotation.z -= 0.004;
      if (ringOuter) ringOuter.rotation.z += 0.003;
      if (ringOuter2) ringOuter2.rotation.z -= 0.002;
      
      // Enhanced 3D oscillation for depth perception
      if (ringInner) ringInner.position.y = -34.8 + Math.sin(time * 2) * 2;
      if (ringMiddle) ringMiddle.position.y = -34.8 + Math.sin(time * 2.2) * 1.5;
      if (ringOuter) ringOuter.position.y = -34.8 + Math.sin(time * 2.4) * 1;
      if (ringOuter2) ringOuter2.position.y = -34.8 + Math.sin(time * 2.6) * 0.5;
      
      // 3D scanning beam motion
      if (scanBeam) {
        scanBeam.position.y = Math.sin(time * 1.5) * 30;
        scanBeam.material.opacity = 0.5 + Math.sin(time * 3) * 0.2;
      }
      if (scanBeamH) {
        scanBeamH.position.z = Math.sin(time * 1.5) * 30;
        scanBeamH.material.opacity = 0.5 + Math.cos(time * 3) * 0.2;
      }
      
      // Scanning beam horizontal sweep
      scanBeam.position.x = Math.sin(time * 0.8) * 30;
      
      // Controls update
      controls.update();
      renderer.render(scene, camera);

      // Projected part names — float over each piece while disassembled.
      // Read after render so matrixWorld is fresh; ~10 DOM writes only when
      // exploded, zero cost otherwise.
      if (exploded && _labels.size) {
        const vp = renderer.domElement.getBoundingClientRect();
        const v = new THREE.Vector3();
        _parts.forEach(p => {
          const el = _labels.get(p);
          if (!el) return;
          v.setFromMatrixPosition(p.matrixWorld).project(camera);
          if (v.z < 1) {
            el.style.display = 'block';
            el.style.left = (vp.left + (v.x * 0.5 + 0.5) * vp.width) + 'px';
            el.style.top  = (vp.top + (-v.y * 0.5 + 0.5) * vp.height) + 'px';
          } else el.style.display = 'none';
        });
      }
    }

    // ── BUILD TUTORIAL + TEARDOWN / DRAG ───────────────────────────────
    function openTutorial() { document.getElementById('tut-panel').classList.add('open'); }
    function closeTutorial() { document.getElementById('tut-panel').classList.remove('open'); }

    function toggleHaz() { document.getElementById('haz-panel').classList.toggle('open'); }

    // ── real build tutorial (knowledge base injected by Python) ─────────
    const TUT = {"title": "BUILD PROTOCOL — A LIGHTSABER", "generated": true, "steps": [{"name": "1 · CAPTURE THE SHAPE", "detail": "Get the geometry of the a lightsaber before touching material: a side-profile printout glued to 6 mm MDF or layered foam-board, cut and stacked to thickness (props-first method). Draw or print the front + side views at final scale — every measurement comes off these.", "mats": ["Reference views", "Printer"]}, {"name": "2 · BUILD THE BODY", "detail": "layered cardboard + PVA (free, rock hard) or a small 3D print if the STL exists — resin-print fine detail if you have the access. Cut all major pieces from your pattern in one session — batching keeps the edges consistent. At this size accuracy comes from the template — tape the printed plan to the material and cut through both.", "mats": ["Cardboard layers", "PVA glue", "Craft knife"]}, {"name": "3 · DETAIL PASS", "detail": "Add the a lightsaber's signature details as separate small pieces glued on — panel lines scribed with a blunt tool, raised trim from thin foam strip. Depth reads far better than paint alone.", "mats": ["Thin foam/card strip", "Scribing tool (blunt pencil)"]}, {"name": "4 · HARDEN + SMOOTH", "detail": "sand 120 → 400, skim spot-putty over the joins, filler primer, then wet-sand 600 for a moulded surface. This stage is 80 % of how real the final prop looks — do not rush it.", "mats": ["Sandpaper 120/400/600", "Spot putty", "Filler primer"]}, {"name": "5 · PAINT + ASSEMBLE", "detail": "Prime, base coat, then shade recesses with a dark wash and catch edges with a light dry-brush — the two tricks that make anything look machined. Assemble last so every face stays reachable.", "mats": ["Acrylic or spray paints", "Wash + dry-brush", "CA glue"]}, {"name": "6 · LIGHT IT", "detail": "Wire the glow: LED strip or fairy-LEDs on a coin cell / small battery pack, diffused behind frosted plastic or 2 layers of baking paper — bare LEDs read as dots, diffusion reads as plasma. Leave a hidden battery hatch.", "mats": ["LEDs + coin cell/pack", "Frosted acrylic/baking paper", "Thin wire"]}], "solutions": ["NO 3D PRINTER: cardboard + PVA lamination (6-7 layers, rock hard when dry) or EVA-foam layered and heat-shaped — both finish identically after primer.", "NO BUDGET: cereal-box card for detail parts, paper-mache (3 layers + white glue) for rigidity, egg-carton texture for organic surfaces.", "NO WORKSHOP TOOLS: a sharp craft knife, steel ruler and cutting mat replace 90 % of power tools; sandpaper wrapped round a block replaces a sander.", "NO PAINT BUDGET: one grey primer + one accent colour + a black wash covers most sci-fi and fantasy schemes.", "NO ELECTRONICS: EL-wire, a battery fairy-light string, or even a phone-torch behind the diffuser works for static glow."], "estimate": "an evening to a weekend", "kb": {"spiderman": {"title": "SPIDER-MAN MASK — THE REAL BUILD", "traps": ["Printing the shell too thin — under 2.5 mm walls it flexes and the lenses pop off. 3 mm walls, 4 perimeters.", "Skipping the filler skim: paint shows every layer line on a curved shell. Two thin skims of spot putty beat one thick one.", "Heat-forming lenses too hot — above 150 C the acrylic bubbles. 120-130 C, watch it sag, then press.", "Gluing the fabric to the OUTSIDE rim: pull it through and glue INSIDE, or the rim shows a hard edge on your face."], "steps": [{"name": "1 · FACE SHELL — THE CHASSIS (10-12 h, ~$6)", "detail": "Find a model: search 'cosplay face shell STL' on Etsy, MyMiniFactory or Cults3D (worbla-makers and CP cosplay versions are the known-good ones). Print in TWO halves plus a separate chin/jaw piece so it fits any printer. Settings: PETG or PLA+, 0.2 mm layers, 4-6 perimeters (this IS the strength), 15% gyroid infill, supports only under the nose bridge and brow. Total print ~10 h. Assemble the halves with CA glue + activated concave ridge, or 2-part epoxy for a cleaner bond.", "time": "10-12 h print + 1 h assembly", "cost": "~$6 filament", "mats": ["PETG or PLA+ (~250 g)", "CA glue / 2-part epoxy", "Masking tape"]}, {"name": "2 · SANDING + SKIM — WHERE PROP BECOMES PRODUCT (2-3 h hands-on)", "detail": "Sand 120 grit to knock the layer lines flat, 220 to smooth, 400 before primer. Then spot putty (Bondo spot putty or Polisher's glazing putty): two THIN skims with a rubber squeegee, 30 min cure between, sand each back at 220→400. Finish with filler primer (2-3 light coats, 10 min flash), wet-sand 600. Now the shell reads as moulded, not printed. Wipe with isopropyl before every stage.", "time": "2-3 h across an evening", "cost": "~$12", "mats": ["Sandpaper 120/220/400/600", "Bondo spot putty", "Filler primer rattle can", "Nitrile gloves"]}, {"name": "3 · REINFORCE FROM THE INSIDE (1 h + overnight cure)", "detail": "Lay 1-2 layers of 2 oz chopped-strand fibreglass mat inside the shell with laminating epoxy (not polyester — lower odour, longer work time). Press the wet mat into the brow and cheek curves with a brush, pop air bubbles with a pin. Overnight cure. This is the step that stops the shell cracking when it takes a knock. If resin is a no-go: 3 layers of paper-mache + PVA, fully dry in 24 h, adds ~80% of the stiffness.", "time": "1 h work + overnight cure", "cost": "~$18", "mats": ["2 oz fibreglass mat", "Laminating epoxy + hardener", "Disposable brush", " gloves + respirator (fumes)"]}, {"name": "4 · LENSES — THE PART EVERYONE STARES AT (3-4 h, ~$15)", "detail": "Cut two-way mirror acrylic 2-3 mm oversize (lens templates ship with most shell STLs, or trace the shell's eye holes). Heat-form: oven at 120 C on a clean baking tray, 3-5 min until it slumps — press gently over a hemispherical former (bowl wrapped in felt) and hold 30 s. Trim with a rotary tool + cutoff wheel, sand edges 400. Bezel: 2 mm EVA foam, contact cement, wrap the rim. Magnetic mount: four 8x2 mm N35 magnets per lens — SUPERGLUE magnets to the shell FIRST, then epoxy matching pairs to the lens backs (polarity test every pair, one flipped magnet ruins the set).", "time": "3-4 h", "cost": "~$15", "mats": ["2-way mirror acrylic A4 sheet", "EVA foam 2 mm", "8x2 mm N35 magnets x8", "Contact cement + CA", "Oven + rotary tool"]}, {"name": "5 · FABRIC SHELL — PATTERN TO PULL (4-6 h, ~$20)", "detail": "Get a lycra/spandex faceshell pattern (search 'spiderman mask pattern faceshell' — The Foam Cave and several Etsy shops sell print-and-sew versions sized to shells). Print at 100% scale, cut 2-way stretch WITH the stretch wrapping horizontally. Sew seams with a zigzag or serger, 2.5 mm — or fabric glue (E6000) + hem tape if you don't sew. Dye: Rit Dye More in the sink at 90 C for the classic red, or buy pre-coloured 4-way stretch and print the webbing via inkjet-on-fabric sheets for accuracy.", "time": "4-6 h", "cost": "~$20", "mats": ["2-way stretch spandex 0.5 m", "Pattern printout", "Sewing machine or E6000 + hem tape", "Rit Dye More (optional)"]}, {"name": "6 · ASSEMBLY — THE PULL-THROUGH (45 min)", "detail": "Turn the fabric inside-out, roll the shell into it face-down, then roll it back through the neck opening — the fabric seats itself over the shell with no wrinkles. Glue the fabric edge to the shell's INNER rim with contact cement, 10 cm at a time. Stretch the neck hole over a jar overnight to relax it. Seat the lenses on their magnets — they should click and hold through a headshake.", "time": "45 min + overnight relax", "cost": "$0 — all glue work", "mats": ["Contact cement", "A jar"]}, {"name": "7 · FINISHING TOUCHES (optional)", "detail": "Magnetic jaw piece for eating/talking on the go (same 8x2 magnets, inset into the chin). Hidden rear zip stitched into the fabric seam. For moving lenses: a servo + Arduino Nano in the brow is a weekend project — most cosplayers stop at static.", "time": "2-4 h", "cost": "~$10 if adding the jaw", "mats": ["8x2 mm magnets", "Optional: servo + Nano + battery"]}], "solutions": ["NO 3D PRINTER: laminate 6-7 layers of cardboard + PVA over a balloon/mannequin head (rock-hard when dry), or build it from EVA-foam pepakura pieces — then seal with PVA and finish the same.", "NO SEWING MACHINE: fabric glue + hem tape hold a spandex shell fine at this scale.", "NO 2-WAY MIRROR: clear acrylic + one-way window-tint film looks 90% the same for a tenth the price.", "NO RESIN for reinforcing: 3 layers of paper-mache + white glue is the poor-cousin version and still stiff.", "NO OVEN for lens forming: hot-water pour-over forming works at 90 C with 4-5 min hold — slower but shapes fine."]}, "helmet": {"title": "HELMET — FULL BUILD", "steps": [{"name": "1 · SHELL", "detail": "3D print the helmet in 4 interlocking pieces (top, back, two sides) or pepakura EVA foam. Sand + filler + primer until smooth.", "mats": ["Filament or EVA foam", "Filler", "Primer"]}, {"name": "2 · INNER HARNESS", "detail": "Glue a foam head-liner and chin strap inside so the shell sits level and doesn't rattle.", "mats": ["EVA foam 5 mm", "Elastic strap", "Contact adhesive"]}, {"name": "3 · FACEPLATE & ELECTRONICS", "detail": "Hinge the faceplate on small hinges or magnets; LEDs behind acrylic eyes on a coin-cell or Arduino driver.", "mats": ["Hinges/magnets", "LED strip", "Acrylic"]}, {"name": "4 · FINISH", "detail": "Prime → base coat → detail pass → clear. Matte clear for armour, gloss for glass parts.", "mats": ["Spray paints", "Clear coat"]}], "solutions": ["NO 3D PRINTER: EVA-foam pepakura is the standard alternative — heat-shape with a heat gun, glue with contact cement.", "NO PEPAKURA SOFTWARE: cardboard prototype first, then transfer to foam."]}, "reactor": {"title": "ARC REACTOR PROP — FULL BUILD", "steps": [{"name": "1 · CORE RING", "detail": "3D print or cut the housing rings from 3 mm acrylic/foam-board; the copper-coil effect is ten small segments around the ring.", "mats": ["Acrylic or foam board", "Copper paint/wire"]}, {"name": "2 · THE GLOW", "detail": "An LED ring + frosted acrylic diffuser reads as plasma; EL-wire behind a triangular mask gives the triangle core.", "mats": ["LED ring", "Frosted acrylic", "EL-wire", "Coin cell/Arduino"]}, {"name": "3 · FINISH", "detail": "Weather the rim with dark wash, mount in a display stand or chest rig.", "mats": ["Dark wash", "Stand"]}], "solutions": ["NO 3D PRINTER: foam-board + compass-cut rings are indistinguishable after paint.", "NO LED RING: fairy LEDs behind frosted plastic work, just dimmer."]}}, "prompt": "a lightsaber"};
    let _curPlan = TUT;   // plan currently rendered — the assistant reads it

    // ── universal planner: composes a real build protocol for ANY object ──
    // Mirrors the Python generator: shape recipe by object class, materials
    // by size class, process order, tool-free alternatives.
    function universalPlan(q) {
      const s = q.toLowerCase();
      const short = q.length > 28 ? q.slice(0, 25).trim() + '…' : q;
      const big = /(life ?size|full ?size|cosplay|wearable|human|giant|statue|suit|armou?r|helmet|mask|car|vehicle|jet|ship|door|sword|shield|bow|rifle|gun|staff|hammer)/.test(s);
      const lights = /(reactor|core|glow|led|lamp|neon|light|energy|plasma|saber|laser)/.test(s);
      let shape = "the viewer's own blueprint SVG printed at scale as your master template";
      const recipes = [
        [/mask|face|helmet|head|visor/, "an existing STL ('{o} STL free' on Printables/MyMiniFactory/Thingiverse) or a plaster strip cast of your own face as the buck"],
        [/armou?r|chest|gauntlet|boot|shin|pauldron/, "pepakura/EVA-foam templates (search '{o} foam template') — scale to your body measurements before cutting"],
        [/gun|rifle|blaster|sword|blade|axe|hammer|staff|wand|saber/, "a side-profile printout glued to 6 mm MDF or layered foam-board, cut and stacked to thickness"],
        [/drone|jet|plane|rocket|ship|car|vehicle|engine/, "a 3-view blueprint printed at target scale, then an STL or built-up foam/card over a light frame"],
        [/ring|medallion|amulet|badge|coin|emblem|sigil/, "the viewer's own blueprint SVG printed at size — cast in resin, carve from layered card, or print flat with a raised rim"],
        [/reactor|core|lamp|lantern/, "printed or acrylic cut rings, a diffuser disc, and LEDs inside — plan the wiring channel first"],
        [/creature|skull|dragon|monster|skeleton/, "a printable model in sections, or sculpt over a crumpled-foil armature with air-dry clay"],
        [/house|tower|castle|building|city|bridge|station|star/, "cardboard + hot-glue over a card skeleton for volume, xps foam sheets for surfaces"],
      ];
      for (const [re, rec] of recipes) if (re.test(s)) { shape = rec.replace('{o}', short); break; }
      const steps = [
        { name: 'CAPTURE THE SHAPE', detail: 'Get the geometry of the ' + short + ' before touching material: ' + shape + '. Draw or print front + side views at final scale — every measurement comes off these.', mats: ['Reference views', 'Printer'] },
        big
          ? { name: 'BUILD THE BODY', detail: '6-10 mm EVA foam as the primary body — cheap, light, heat-shapes over curves. Cut all major pieces from your pattern in one session, test-fit as you go: measure twice, cut once.', mats: ['EVA foam 6-10 mm', 'Contact cement', 'Utility knife + mat'] }
          : { name: 'BUILD THE BODY', detail: 'Layered cardboard + PVA (free, rock hard) or a small 3D print if the STL exists. Tape the printed plan to the material and cut through both — accuracy comes from the template.', mats: ['Cardboard layers', 'PVA glue', 'Craft knife'] },
        { name: 'DETAIL PASS', detail: "Add the " + short + "'s signature details as separate small pieces glued on — panel lines scribed with a blunt tool, raised trim from thin foam strip. Depth reads better than paint alone.", mats: ['Thin foam/card strip', 'Scribing tool'] },
        big
          ? { name: 'HARDEN + SMOOTH', detail: 'Heat-shape foam over curves, then seal with 2-3 coats of PVA and flexible primer so paint never cracks on flex. This stage is 80 % of how real it looks.', mats: ['Heat gun', 'PVA', 'Flexible primer'] }
          : { name: 'HARDEN + SMOOTH', detail: 'Sand 120 → 400, skim spot-putty over joins, filler primer, wet-sand 600 for a moulded surface. Do not rush it.', mats: ['Sandpaper 120/400/600', 'Spot putty', 'Filler primer'] },
        { name: 'PAINT + ASSEMBLE', detail: 'Prime, base coat, shade recesses with a dark wash, catch edges with a light dry-brush — the two tricks that make anything look machined. Assemble last so every face stays reachable.', mats: ['Paints', 'Wash + dry-brush', 'CA glue'] },
        lights
          ? { name: 'LIGHT IT', detail: 'Wire the glow: LEDs on a coin cell or battery pack, diffused behind frosted plastic or baking paper — bare LEDs read as dots, diffusion reads as plasma. Leave a hidden battery hatch.', mats: ['LEDs + cell/pack', 'Frosted acrylic/baking paper', 'Thin wire'] }
          : { name: 'DISPLAY', detail: 'Finish the ' + short + ' for its setting: stand, wall mount or wear rig. Clear coat (matte = screen-accurate, gloss = fresh off the line) locks the paint.', mats: ['Clear coat', 'Stand/mount'] },
      ];
      const solutions = [
        'NO 3D PRINTER: cardboard + PVA lamination (6-7 layers, rock hard) or EVA-foam layered and heat-shaped — both finish identically after primer.',
        'NO BUDGET: cereal-box card for detail parts, paper-mache (3 layers + white glue) for rigidity, egg-carton texture for organic surfaces.',
        'NO WORKSHOP TOOLS: sharp craft knife + steel ruler + cutting mat replace 90 % of power tools; sandpaper on a block replaces a sander.',
        'NO PAINT BUDGET: one grey primer + one accent colour + a black wash covers most schemes.',
      ];
      if (lights) solutions.push('NO ELECTRONICS: EL-wire, battery fairy-lights, or a phone-torch behind the diffuser for static glow.');
      return { title: 'BUILD PROTOCOL — ' + q.toUpperCase(), steps, solutions,
               estimate: big ? '1-2 weekends' : 'an evening to a weekend' };
    }
    // planner bridge: curated KB first, then the universal composer
    window.__holoPlan = function (q, ok, fail) {
      const key = matchTut(q);
      if (TUT.kb && TUT.kb[key]) { ok(TUT.kb[key]); return; }
      ok(universalPlan(q));
    };

    // talk: shared voice handle for the build assistant
    let _voice = null;
    function _pickVoice() {
      if (!window.speechSynthesis) return null;
      const vs = speechSynthesis.getVoices();
      const prefs = [/daniel/i, /google uk english male/i, /ryan/i, /george/i, /arthur/i, /oliver/i];
      for (const re of prefs) for (const v of vs) if (re.test(v.name)) return v;
      for (const v of vs) if (/en[-_]GB/i.test(v.lang)) return v;
      for (const v of vs) if (/^en/i.test(v.lang)) return v;
      return vs[0] || null;
    }
    function say(text) {
      try {
        if (!window.speechSynthesis) return;
        const u = new SpeechSynthesisUtterance(text);
        if (!_voice) _voice = _pickVoice();
        if (_voice) u.voice = _voice;
        u.lang = (_voice && _voice.lang) || 'en-GB';
        u.pitch = 0.92; u.rate = 0.97; u.volume = 0.9;
        speechSynthesis.speak(u);
      } catch (e) {}
    }

    // render a plan; rem numbers after removals; every step gets a bin
    function renderTut(t) {
      _curPlan = t;
      const host = document.getElementById('tut-steps');
      let h = '';
      t.steps.forEach((s, i) => {
        h += '<div class="tut-step" data-i="' + i + '"><span class="bin" title="Remove this step" onclick="dropStep(this)">🗑</span>' +
             '<b>' + (i + 1) + ' · ' + s.name.replace(/^\d+\s*·\s*/, '') + '</b><span>' + s.detail + '</span>';
        if (s.mats && s.mats.length)
          h += '<div class="tut-mats">' + s.mats.map(m => '<i>' + m + '</i>').join('') + '</div>';
        h += '</div>';
      });
      if (t.solutions && t.solutions.length) {
        h += '<div class="tut-sol"><h4>◆ NO PRINTER? NO PROBLEM — WORKING ALTERNATIVES</h4>';
        t.solutions.forEach(s => h += '<p>' + s + '</p>');
        h += '</div>';
      }
      if (t.estimate) h += '<div class="tut-est">ESTIMATED BUILD TIME: ' + t.estimate.toUpperCase() + '</div>';
      host.innerHTML = h;
    }
    function dropStep(binEl) {
      const row = binEl.closest('.tut-step');
      if (!row) return;
      row.classList.add('gone');
      setTimeout(() => {
        row.remove();
        // renumber what is left so the protocol stays readable
        document.querySelectorAll('#tut-steps .tut-step').forEach((el, i) => {
          const b = el.querySelector('b');
          if (b) b.textContent = (i + 1) + ' · ' + b.textContent.replace(/^\d+\s*·\s*/, '');
        });
      }, 300);
      say('Step removed, sir.');
    }
    renderTut(TUT);

    // BUILD ANYTHING: try the AI planner first (full custom build-plan),
    // then the curated KB, then Python's universal generator baked into TUT.
    function askBuild(qIn) {
      const q = (qIn !== undefined ? qIn : document.getElementById('tut-q').value).trim();
      if (!q) return;
      document.getElementById('tut-q').value = q;
      openTutorial();
      const host = document.getElementById('tut-steps');
      host.innerHTML = '<div style="color:#0088aa;font-size:10px;letter-spacing:1px">▸ SYNTHESISING BUILD PROTOCOL FOR: ' +
        q.toUpperCase() + ' …</div>';
      const done = (plan, src) => {
        if (!plan || !plan.steps || !plan.steps.length) { plan = TUT; src = 'protocol'; }
        plan.title = plan.title || ('BUILD PROTOCOL — ' + q.toUpperCase());
        const ttl = document.getElementById('tut-title');
        if (ttl) ttl.textContent = '📐 ' + plan.title;
        renderTut(plan);
        say('Build protocol for ' + q + ' synthesised, sir. ' + plan.steps.length + ' stages.');
      };
      // planner bridge: curated KB, else the universal composer (any object)
      try {
        if (window.__holoPlan) { window.__holoPlan(q, plan => done(plan, 'plan')); return; }
      } catch (e) {}
      const key = matchTut(q);
      done(TUT.kb && TUT.kb[key] ? TUT.kb[key] : TUT, 'kb');
    }
    function askQuick(q) { askBuild(q); }
    function matchTut(q) {
      q = q.toLowerCase();
      if (q.includes('spider')) return 'spiderman';
      if (/(helmet|mask|suit|iron man)/.test(q) && !q.includes('spider')) return 'helmet';
      if (q.includes('reactor')) return 'reactor';
      return 'default';
    }

    // ── JARVIS build assistant (middle-right) — talks, helps, removable ──
    const KB = TUT.kb || {};
    function jhSay(text, who, opts) {
      const box = document.getElementById('jh-msgs');
      const el = document.createElement('div');
      el.className = 'jh-m ' + (who || 'jarvis');
      const bin = who === 'user' ? '<span class="bin" title="Remove message" onclick="this.parentNode.remove()">🗑</span> ' : '';
      el.innerHTML = bin + document.createElement('div').appendChild(document.createTextNode(text)).textContent;
      box.appendChild(el);
      box.scrollTop = box.scrollHeight;
      if (who !== 'user' && !(opts && opts.quiet)) say(text);
      return el;
    }
    function jhHelp() {
      const box = document.getElementById('jh-msgs');
      const el = document.createElement('div');
      el.style.margin = '6px 0';
      el.innerHTML =
        `<span class="jh-chip" onclick="jhAsk('What do I need for this build?')">What do I need?</span>` +
        `<span class="jh-chip" onclick="jhAsk('Where do I start?')">Where do I start?</span>` +
        `<span class="jh-chip" onclick="jhAsk('I do not have a 3D printer')">No 3D printer</span>` +
        `<span class="jh-chip" onclick="jhAsk('How long will this take?')">How long?</span>` +
        `<span class="jh-chip" onclick="jhAsk('What are the hazards?')">Hazards</span>`;
      box.appendChild(el);
      box.scrollTop = box.scrollHeight;
    }
    const JH_GREET = 'At your service, sir. I can plan the build of anything you name — say the word. Ask about materials, order of operations, or working without a 3D printer.';
    jhSay(JH_GREET, 'jarvis', { quiet: true });
    jhHelp();
    function toggleJH() {
      const p = document.getElementById('jh-panel');
      const opening = !p.classList.contains('open');
      p.classList.toggle('open');
      if (opening) say('Yes, sir?');
    }
    function jhAsk(q) { jhSend(q); }
    function jhSend(forced) {
      const inp = document.getElementById('jh-in');
      const q = (forced || inp.value).trim();
      if (!q) return;
      if (!forced) inp.value = '';
      jhSay(q, 'user');
      setTimeout(() => { const a = jhAnswer(q); jhSay(a); }, 350);
    }
    document.getElementById('jh-in').addEventListener('keydown', e => { if (e.key === 'Enter') jhSend(); });
    function jhAnswer(q) {
      const s = q.toLowerCase();
      const t = _curPlan || TUT;
      // “build me X / how to build X / make X” → synthesise that plan on the spot
      if (/^(build|make|create|how (do|to) (i )?(build|make))/.test(s) || /build (me |a |an |the )/.test(s)) {
        const obj = q.replace(/^(build|make|create|how (do|to) (i )?(build|make))\s*(me |a |an |the )?/i, '').trim() || q;
        setTimeout(() => askBuild(obj), 500);
        return 'Right away, sir — synthesising the build protocol for ' + obj + '.';
      }
      if (/printer|3d print|no printer/.test(s))
        return 'Without a 3D printer, sir: ' + (t.solutions && t.solutions[0] ? t.solutions[0] : 'cardboard + PVA lamination or EVA-foam pepakura — both finish identically after priming.') + ' The WORKING ALTERNATIVES section has the full list.';
      if (/material|need|supplies|buy/.test(s)) {
        const mats = [...new Set(t.steps.flatMap(x => x.mats || []))];
        return 'For ' + (t.title || 'this build').toLowerCase().replace('build protocol — ', '') + ' you will need: ' + (mats.slice(0, 8).join(', ') || 'the basics — see the panel') + '. The full list sits under each step in the BUILD PROTOCOL panel.';
      }
      if (/start|first|order|begin/.test(s))
        return 'Start with: ' + (t.steps[0] ? t.steps[0].name + ' — ' + t.steps[0].detail.slice(0, 130) + '…' : 'step one in the panel') + ' Everything else mounts to it.';
      if (/time|long|when/.test(s))
        return t.estimate ? 'Realistically: ' + t.estimate + ', sir. Rushing the finishing stage is where builds go wrong.' : 'A weekend usually covers it, sir — two if you are weathering and lighting it as well.';
      if (/remind|what.*doing|where.*we|summary/.test(s))
        return 'You are on the build of ' + (document.getElementById('tut-title').textContent.replace('📐 BUILD PROTOCOL — ', '') || 'this object') + ', at step ' + document.querySelectorAll('#tut-steps .tut-step').length + ' of the protocol. Ask me to repeat any stage.';
      if (/hazard|safe|danger|poison/.test(s))
        return 'Open the HAZARDS panel — the full risk analysis lives there, with symptoms and mitigation for anything critical.';
      return 'I can plan the build of anything, sir — try “build a lightsaber” or type it in the BUILD panel. For this ' + (t.title || 'project').toLowerCase() + ': ' + t.steps.length + ' stages, materials listed under each.';
    }

    let exploded = false;
    let explodeAnim = null;
    // Named parts fly apart on disassembly; the projection rig (pad, rings,
    // dust, scan) stays put — it is the stage, not a component.
    let _parts = hologramGroup.children.filter(ch => ch.userData.partName && !ch.userData.isRig);
    if (!_parts.length) _parts = hologramGroup.children.filter(ch => !ch.userData.isRig);
    const _labels = new Map();   // part Group -> its floating name label
    _parts.forEach(p => {
      if (!p.userData.partName) return;
      const el = document.createElement('div');
      el.className = 'part-lbl';
      el.textContent = p.userData.partName;
      document.body.appendChild(el);
      _labels.set(p, el);
    });
    function teardown() {
      exploded = !exploded;
      document.getElementById('tear-btn').classList.toggle('active', exploded);
      _parts.forEach((ch, i) => {
        if (!ch.userData._origPos) {
          ch.userData._origPos = ch.position.clone();
          const dir = ch.position.clone();
          if (dir.length() < 0.001) dir.set(Math.cos(i * 0.7), 0.5, Math.sin(i * 0.7));
          dir.normalize();
          ch.userData._awayPos = ch.userData._origPos.clone().add(dir.multiplyScalar(24 + (i % 5) * 8));
        }
        ch.userData._explodeTo = (exploded ? ch.userData._awayPos : ch.userData._origPos).clone();
        if (!exploded) {
          const el = _labels.get(ch);
          if (el) el.style.display = 'none';
        }
      });
      document.getElementById('controls-hint').innerHTML = exploded
        ? '[CTRL+A] REASSEMBLE &nbsp;|&nbsp; [DRAG A PART] Move it — parts are named'
        : '[LEFT MOUSE]: Orbit &nbsp;|&nbsp; [SCROLL]: Zoom &nbsp;|&nbsp; [RIGHT MOUSE]: Pan';
      if (!explodeAnim) startExplodeAnim();
    }
    function startExplodeAnim() {
      (function step() {
        let moving = false;
        hologramGroup.children.forEach(ch => {
          const tgt = ch.userData._explodeTo;
          if (tgt) {
            ch.position.lerp(tgt, 0.12);
            if (ch.position.distanceTo(tgt) > 0.05) moving = true;
            else { ch.position.copy(tgt); ch.userData._explodeTo = null; }
          }
        });
        explodeAnim = moving ? requestAnimationFrame(step) : null;
      })();
    }

    // drag a disassembled part with the mouse
    const _ray = new THREE.Raycaster();
    const _ptr = new THREE.Vector2();
    let _dragPart = null;
    const _dragPlane = new THREE.Plane();
    const _dragOff = new THREE.Vector3();
    renderer.domElement.addEventListener('pointerdown', ev => {
      if (!exploded || ev.button !== 0) return;
      _ptr.set(ev.clientX / innerWidth * 2 - 1, -(ev.clientY / innerHeight) * 2 + 1);
      _ray.setFromCamera(_ptr, camera);
      const hits = _ray.intersectObjects(hologramGroup.children, true);
      if (hits.length) {
        let obj = hits[0].object;
        while (obj.parent && obj.parent !== hologramGroup) obj = obj.parent;
        if (!_parts.includes(obj)) return;   // only real parts are grabbable
        _dragPart = obj;
        _dragPlane.setFromNormalAndCoplanarPoint(
          camera.getWorldDirection(new THREE.Vector3()),
          obj.getWorldPosition(new THREE.Vector3()));
        controls.enabled = false;
        const hit = _ray.ray.intersectPlane(_dragPlane, new THREE.Vector3());
        if (hit) _dragOff.copy(obj.position).sub(hologramGroup.worldToLocal(hit.clone()));
      }
    });
    addEventListener('pointermove', ev => {
      if (!_dragPart) return;
      _ptr.set(ev.clientX / innerWidth * 2 - 1, -(ev.clientY / innerHeight) * 2 + 1);
      _ray.setFromCamera(_ptr, camera);
      const hit = _ray.ray.intersectPlane(_dragPlane, new THREE.Vector3());
      if (hit) {
        const local = hologramGroup.worldToLocal(hit.clone());
        _dragPart.position.copy(local.add(_dragOff));
        _dragPart.userData._explodeTo = null;   // it stays where dropped
      }
    });
    addEventListener('pointerup', () => { if (_dragPart) { _dragPart = null; controls.enabled = true; } });
    addEventListener('keydown', ev => {
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === 'a' || ev.key === 'A')) { ev.preventDefault(); teardown(); }
    });

    // The render loop reads teardown state (exploded/_labels), so it may only
    // start once every declaration above exists — starting it earlier threw
    // a TDZ ReferenceError every frame and froze the whole viewer.
    fitStage();   // size the canvas synchronously — the first frames otherwise
                  // render into a stale framebuffer and spam GL warnings
    animate();

    window.addEventListener('resize', fitStage);
    if (window.ResizeObserver) new ResizeObserver(fitStage).observe(document.documentElement);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) fitStage(); });
    [120, 500, 1500].forEach(ms => setTimeout(fitStage, ms));   // late-layout catch
  