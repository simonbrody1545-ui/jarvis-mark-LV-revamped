"""
Website Shortcuts Plugin
Create custom shortcuts to open any website with voice or text commands.

Features:
- Add custom website shortcuts through Settings
- Set custom trigger phrases for each shortcut
- Works with both voice and text input
- Manage multiple shortcuts

Example:
- Name: "YouTube Studio"
- URL: "https://studio.youtube.com"
- Trigger: "ytsa"
"""
from __future__ import annotations

import json
import webbrowser
from typing import Dict, List

_NS = "website_shortcuts"

def _get_shortcuts() -> List[Dict]:
    """Get all configured shortcuts from config."""
    try:
        from memory.config_manager import get_plugin_config
        cfg = get_plugin_config(_NS)
        shortcuts = cfg.get("shortcuts", "[]")
        if isinstance(shortcuts, str):
            return json.loads(shortcuts)
        return shortcuts if isinstance(shortcuts, list) else []
    except Exception:
        return []

def _save_shortcuts(shortcuts: List[Dict]) -> bool:
    """Save shortcuts to config."""
    try:
        from memory.config_manager import save_plugin_config
        save_plugin_config(_NS, {"shortcuts": json.dumps(shortcuts)})
        return True
    except Exception:
        return False

def _open_website(url: str) -> str:
    """Open a website URL — Opera only."""
    try:
        from core.opera import open_url
        if open_url(url):
            return f"✅ Opening {url} in Opera..."
        return "❌ Opera not found — I only open Opera, sir."
    except Exception as e:
        return f"❌ Failed to open website: {e}"

def _find_and_open(trigger: str) -> str:
    """Find a shortcut by trigger phrase and open it."""
    trigger = trigger.lower().strip()
    shortcuts = _get_shortcuts()
    
    for shortcut in shortcuts:
        shortcut_trigger = shortcut.get("trigger", "").lower().strip()
        if shortcut_trigger == trigger:
            name = shortcut.get("name", "Website")
            url = shortcut.get("url", "")
            if url:
                return _open_website(url)
            else:
                return f"❌ No URL configured for '{name}'"
    
    return f"❌ No shortcut found for trigger: '{trigger}'"

def run(parameters: dict, player=None, session_memory=None) -> str:
    """Execute website shortcut command."""
    action = (parameters.get("action") or "").strip().lower()
    trigger = (parameters.get("trigger") or "").strip()
    url = (parameters.get("url") or "").strip()
    name = (parameters.get("name") or "").strip()
    
    if action == "list":
        """List all configured shortcuts."""
        shortcuts = _get_shortcuts()
        if not shortcuts:
            return "No shortcuts configured. Add them in Settings → Website Shortcuts."
        
        lines = ["📱 Configured Shortcuts:"]
        for i, s in enumerate(shortcuts, 1):
            lines.append(f"{i}. {s.get('name', 'Unknown')}")
            lines.append(f"   Trigger: '{s.get('trigger', 'N/A')}'")
            lines.append(f"   URL: {s.get('url', 'N/A')}")
        return "\n".join(lines)
    
    elif action == "open" and trigger:
        """Open a website by trigger phrase."""
        return _find_and_open(trigger)
    
    elif action == "add" and name and url and trigger:
        """Add a new shortcut (programmatic, mainly for internal use)."""
        shortcuts = _get_shortcuts()
        
        # Check if trigger already exists
        for s in shortcuts:
            if s.get("trigger", "").lower() == trigger.lower():
                return f"❌ Trigger '{trigger}' already exists. Use a different trigger."
        
        shortcuts.append({
            "name": name,
            "url": url,
            "trigger": trigger
        })
        
        if _save_shortcuts(shortcuts):
            return f"✅ Added shortcut '{name}' with trigger '{trigger}'"
        else:
            return "❌ Failed to save shortcut"
    
    elif action == "remove" and trigger:
        """Remove a shortcut by trigger."""
        shortcuts = _get_shortcuts()
        original_count = len(shortcuts)
        shortcuts = [s for s in shortcuts if s.get("trigger", "").lower() != trigger.lower()]
        
        if len(shortcuts) == original_count:
            return f"❌ No shortcut found with trigger '{trigger}'"
        
        if _save_shortcuts(shortcuts):
            return f"✅ Removed shortcut with trigger '{trigger}'"
        else:
            return "❌ Failed to remove shortcut"
    
    else:
        # If no action specified, try to open by trigger directly
        if trigger:
            return _find_and_open(trigger)
        return "Use 'list' to see shortcuts, or 'open' with a trigger. Configure shortcuts in Settings → Website Shortcuts."

PLUGIN_SETTINGS = {
    "namespace": _NS,
    "title": "🌐 WEBSITE SHORTCUTS",
    "fields": [
        {
            "key": "shortcuts",
            "label": "Shortcuts (JSON format)",
            "type": "text",
            "placeholder": '[{"name":"YouTube Studio","url":"https://studio.youtube.com","trigger":"ytsa"}]',
            "default": "[]",
        },
    ],
    "action": {
        "label": "LIST SHORTCUTS",
        "run": lambda values: run({"action": "list"})
    },
}

PLUGIN = {
    "name": "website_shortcuts",
    "description": (
        "Create custom shortcuts to open any website with voice or text commands. "
        "Configure shortcuts in Settings → Website Shortcuts by adding entries with "
        "name, URL, and trigger phrase. Say or type the trigger to open the website. "
        "Use 'list' to see all configured shortcuts. Example: trigger 'ytsa' opens YouTube Studio."
    ),
    "brief": "Opens websites via custom shortcuts",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "enum": ["list", "open", "add", "remove"],
                "description": "Action: 'list' to show shortcuts, 'open' with trigger to open, 'add' to create new, 'remove' to delete",
            },
            "trigger": {
                "type": "STRING",
                "description": "The trigger phrase for the shortcut (e.g., 'ytsa')",
            },
            "url": {
                "type": "STRING",
                "description": "The website URL to open (for 'add' action)",
            },
            "name": {
                "type": "STRING",
                "description": "The name of the shortcut (for 'add' action)",
            },
        },
        "required": [],
    },
}
