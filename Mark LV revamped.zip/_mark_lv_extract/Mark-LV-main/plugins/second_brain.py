"""
JARVIS Plugin: Second Brain (Multi-Provider AI: Groq, OpenAI, Anthropic)
Integrates a secondary AI brain (Groq, OpenAI, Anthropic, or Ollama) alongside
Gemini (Primary Brain). Deliberates on complex problems, provides second opinions,
synthesizes ideas, and orchestrates actions with ultra-fast external LLMs.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional, Tuple

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE_DIR = get_base_dir()
CONFIG_FILE = BASE_DIR / "config" / "api_keys.json"
BRAIN_STORAGE = BASE_DIR / "memory" / "second_brain_notes.json"

_NS = "second_brain"

PLUGIN = {
    "name": "second_brain",
    "description": (
        "Consults your secondary AI brain (Groq, OpenAI, or Anthropic) alongside Gemini. "
        "Use this whenever the user asks for a 'second opinion', asks to 'think with Groq / OpenAI / Claude', "
        "wants deep reasoning, or asks to consult their Second Brain. It routes queries to ultra-fast "
        "external AI models (e.g. Groq Llama 3.3, OpenAI GPT-4o, Anthropic Claude 3.5) with Gemini fallback."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "request": {
                "type": "STRING",
                "description": "The thought, question, reasoning problem, or objective for the Second Brain to process.",
            },
            "provider": {
                "type": "STRING",
                "description": "Optional AI provider override: 'groq' (default), 'openai', 'anthropic', 'ollama', or 'auto'.",
            },
            "model": {
                "type": "STRING",
                "description": "Optional model override (e.g. 'llama-3.3-70b-versatile', 'gpt-4o', 'claude-3-5-sonnet-20241022').",
            },
            "task": {
                "type": "STRING",
                "description": "Operation type: 'reason' (deep problem solving), 'second_opinion' (compare with Gemini), 'summarize', 'brainstorm'.",
            },
        },
        "required": ["request"],
    },
    "behavior": "NON_BLOCKING",
    "scheduling": "WHEN_IDLE",
}

# Settings exposed directly in MARK LIV's UI Settings Tab
PLUGIN_SETTINGS = {
    "namespace": _NS,
    "title": "SECOND BRAIN (GROQ / OPENAI / ANTHROPIC)",
    "fields": [
        {
            "key": "provider",
            "label": "Active AI Provider (groq | openai | anthropic | ollama)",
            "type": "text",
            "default": "groq",
            "placeholder": "groq",
        },
        {
            "key": "groq_api_key",
            "label": "Groq API Key (gsk_...)",
            "type": "password",
            "placeholder": "gsk_...",
        },
        {
            "key": "groq_model",
            "label": "Groq Model",
            "type": "text",
            "default": "llama-3.3-70b-versatile",
            "placeholder": "llama-3.3-70b-versatile, mixtral-8x7b-32768",
        },
        {
            "key": "openai_api_key",
            "label": "OpenAI API Key (sk-...)",
            "type": "password",
            "placeholder": "sk-...",
        },
        {
            "key": "openai_model",
            "label": "OpenAI Model",
            "type": "text",
            "default": "gpt-4o",
            "placeholder": "gpt-4o, gpt-4.1-mini, gpt-4o-mini",
        },
        {
            "key": "anthropic_api_key",
            "label": "Anthropic API Key (sk-ant-...)",
            "type": "password",
            "placeholder": "sk-ant-...",
        },
        {
            "key": "anthropic_model",
            "label": "Anthropic Model",
            "type": "text",
            "default": "claude-3-5-sonnet-20241022",
            "placeholder": "claude-sonnet-4-5, claude-3-5-sonnet-20241022",
        },
        {
            "key": "ollama_url",
            "label": "Ollama / Local LLM Base URL",
            "type": "text",
            "default": "http://localhost:11434",
            "placeholder": "http://localhost:11434",
        },
        {
            "key": "fallback_to_gemini",
            "label": "Fallback to Gemini if secondary provider is offline",
            "type": "toggle",
            "default": True,
        },
    ],
}


# ── Configuration Loader ─────────────────────────────────────────────────────

def _load_settings() -> dict:
    """Read second brain settings from config/api_keys.json or env vars."""
    cfg = {}
    try:
        if CONFIG_FILE.exists():
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            cfg = data.get("plugin_config", {}).get(_NS, {})
    except Exception:
        cfg = {}

    # Read environment variables if not set in config
    groq_k = cfg.get("groq_api_key") or os.environ.get("GROQ_API_KEY", "")
    openai_k = cfg.get("openai_api_key") or os.environ.get("OPENAI_API_KEY", "")
    anthropic_k = cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")

    provider = (cfg.get("provider") or "").strip().lower()
    if not provider or provider == "auto":
        if groq_k:
            provider = "groq"
        elif openai_k:
            provider = "openai"
        elif anthropic_k:
            provider = "anthropic"
        else:
            provider = "groq"

    return {
        "provider": provider,
        "groq_api_key": groq_k.strip(),
        "groq_model": cfg.get("groq_model", "llama-3.3-70b-versatile") or "llama-3.3-70b-versatile",
        "openai_api_key": openai_k.strip(),
        "openai_model": cfg.get("openai_model", "gpt-4o") or "gpt-4o",
        "anthropic_api_key": anthropic_k.strip(),
        "anthropic_model": cfg.get("anthropic_model", "claude-3-5-sonnet-20241022") or "claude-3-5-sonnet-20241022",
        "ollama_url": (cfg.get("ollama_url", "http://localhost:11434") or "http://localhost:11434").rstrip("/"),
        "fallback_to_gemini": cfg.get("fallback_to_gemini", True),
    }


# ── Provider HTTP Callers (Zero Dependency / Standard Library) ───────────────

# Model names age out faster than settings panels do. When a configured model
# is retired, the call is retried down this ladder until something live
# answers — the brain degrades to a working model instead of dying on a 404.
_MODEL_LADDERS = {
    "openai":    ["gpt-4.1-mini", "gpt-4o-mini", "gpt-4o"],
    "anthropic": ["claude-sonnet-4-5", "claude-3-7-sonnet-latest",
                  "claude-3-5-haiku-20241022"],
    "groq":      ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
}


def _is_model_error(text: str) -> bool:
    t = (text or "").lower()
    return ("404" in t or "model_not_found" in t or "not_found_error" in t
            or ("model" in t and "not found" in t))


def _retry_models(caller, *args, provider: str, model: str):
    """Try the requested model, then the ladder. Returns (ok, text, model_used)."""
    tried = set()
    for m in [model] + _MODEL_LADDERS.get(provider, []):
        m = (m or "").strip()
        if not m or m in tried:
            continue
        tried.add(m)
        ok, text = caller(*args, m)
        if ok or not _is_model_error(text):
            return ok, text, m
    return False, f"No working {provider} model found (tried {', '.join(tried)}).", model

def _call_groq_api(prompt: str, system_prompt: str, api_key: str, model: str) -> Tuple[bool, str]:
    """Execute query against Groq Cloud API."""
    if not api_key:
        return False, "No Groq API key configured."

    url = "https://api.groq.com/openai/v1/chat/completions"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.7,
        "max_tokens": 1024,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "MARK-LIV-JARVIS/54.0",
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ans = data["choices"][0]["message"]["content"]
            return True, ans.strip()
    except Exception as e:
        return False, f"Groq request error: {e}"


def _call_openai_api(prompt: str, system_prompt: str, api_key: str, model: str) -> Tuple[bool, str]:
    """Execute query against OpenAI API."""
    if not api_key:
        return False, "No OpenAI API key configured."

    url = "https://api.openai.com/v1/chat/completions"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.7,
        "max_tokens": 1024,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "MARK-LIV-JARVIS/54.0",
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ans = data["choices"][0]["message"]["content"]
            return True, ans.strip()
    except Exception as e:
        return False, f"OpenAI request error: {e}"


def _call_anthropic_api(prompt: str, system_prompt: str, api_key: str, model: str) -> Tuple[bool, str]:
    """Execute query against Anthropic Claude API."""
    if not api_key:
        return False, "No Anthropic API key configured."

    url = "https://api.anthropic.com/v1/messages"
    payload = {
        "model": model,
        "max_tokens": 1024,
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": prompt}
        ],
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
            "User-Agent": "MARK-LIV-JARVIS/54.0",
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ans = data["content"][0]["text"]
            return True, ans.strip()
    except Exception as e:
        return False, f"Anthropic request error: {e}"


def _call_ollama_api(prompt: str, system_prompt: str, base_url: str, model: str) -> Tuple[bool, str]:
    """Execute query against local Ollama instance."""
    url = f"{base_url}/api/chat"
    payload = {
        "model": model or "llama3",
        "stream": False,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ans = data.get("message", {}).get("content", "")
            return True, ans.strip()
    except Exception as e:
        return False, f"Ollama connection error: {e}"


# ── Second Brain Dispatcher ──────────────────────────────────────────────────

def _execute_second_brain(prompt: str, requested_provider: str = "", requested_model: str = "") -> Tuple[str, str, str]:
    """
    Executes reasoning with the Second Brain.
    Returns: (reply_text, provider_used, model_used)
    """
    settings = _load_settings()
    provider = requested_provider or settings["provider"]
    provider = provider.lower().strip()

    system_prompt = (
        "You are the Second Brain of JARVIS (MARK LIV). You act as a high-speed, "
        "deep-reasoning cognitive partner. Provide crisp, intellectually nuanced, "
        "accurate, and helpful responses. Keep your tone articulate, authentic, and direct."
    )

    success = False
    result_text = ""
    used_provider = provider
    used_model = ""

    if provider == "groq":
        used_model = requested_model or settings["groq_model"]
        success, result_text, used_model = _retry_models(
            _call_groq_api, prompt, system_prompt, settings["groq_api_key"],
            provider="groq", model=used_model)

    elif provider == "openai":
        used_model = requested_model or settings["openai_model"]
        success, result_text, used_model = _retry_models(
            _call_openai_api, prompt, system_prompt, settings["openai_api_key"],
            provider="openai", model=used_model)

    elif provider == "anthropic" or provider == "claude":
        used_provider = "anthropic"
        used_model = requested_model or settings["anthropic_model"]
        success, result_text, used_model = _retry_models(
            _call_anthropic_api, prompt, system_prompt, settings["anthropic_api_key"],
            provider="anthropic", model=used_model)

    elif provider == "ollama":
        used_model = requested_model or "llama3"
        success, result_text = _call_ollama_api(prompt, system_prompt, settings["ollama_url"], used_model)

    # Fallback to alternative keys if the primary provider has no key configured
    if not success and "No " in result_text and "API key" in result_text:
        if settings["groq_api_key"] and provider != "groq":
            used_provider = "groq"
            used_model = settings["groq_model"]
            success, result_text, used_model = _retry_models(
                _call_groq_api, prompt, system_prompt, settings["groq_api_key"],
                provider="groq", model=used_model)
        elif settings["openai_api_key"] and provider != "openai":
            used_provider = "openai"
            used_model = settings["openai_model"]
            success, result_text, used_model = _retry_models(
                _call_openai_api, prompt, system_prompt, settings["openai_api_key"],
                provider="openai", model=used_model)
        elif settings["anthropic_api_key"] and provider != "anthropic":
            used_provider = "anthropic"
            used_model = settings["anthropic_model"]
            success, result_text, used_model = _retry_models(
                _call_anthropic_api, prompt, system_prompt, settings["anthropic_api_key"],
                provider="anthropic", model=used_model)

    # Fallback to Gemini (Primary Brain) if secondary fails or no keys exist
    if not success and settings["fallback_to_gemini"]:
        try:
            from core import gemini
            gem_text = gemini.text(f"{system_prompt}\n\nUser Question: {prompt}", tier=gemini.SMART)
            if gem_text:
                notice = f"[{used_provider.upper()} key unset or offline — synthesized via Primary Brain Gemini]"
                return f"{gem_text}\n\n({notice})", "Gemini (Fallback)", "gemini-flash"
        except Exception as e:
            print(f"[SecondBrain] Gemini fallback error: {e}")

    if not success:
        return (
            f"Sir, your Second Brain ({used_provider.capitalize()}) requires an API key. "
            f"Please enter your {used_provider.capitalize()} API key in the MARK LIV Settings tab "
            f"or set {used_provider.upper()}_API_KEY.",
            used_provider,
            used_model
        )

    return result_text, used_provider, used_model


def _save_brain_note(title: str, content: str, provider: str) -> None:
    """Store note in memory/second_brain_notes.json."""
    notes = []
    if BRAIN_STORAGE.exists():
        try:
            notes = json.loads(BRAIN_STORAGE.read_text(encoding="utf-8"))
        except Exception:
            notes = []
    notes.insert(0, {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "title": title[:50],
        "content": content,
        "provider": provider
    })
    try:
        BRAIN_STORAGE.parent.mkdir(parents=True, exist_ok=True)
        BRAIN_STORAGE.write_text(json.dumps(notes[:200], indent=2), encoding="utf-8")
    except Exception:
        pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    """Execute Second Brain Consultation."""
    parameters = parameters or {}
    request = str(parameters.get("request", "")).strip()
    provider = str(parameters.get("provider", "")).strip()
    model = str(parameters.get("model", "")).strip()
    task = str(parameters.get("task", "reason")).strip()

    if not request:
        return "Sir, what topic or problem should I dispatch to your Second Brain?"

    def log(msg: str):
        print(f"[SecondBrain] {msg}")
        if player:
            try:
                player.write_log(f"BRAIN: {msg}")
            except Exception:
                pass

    log(f"Consulting Second Brain (Provider: {provider or 'default'})...")

    reply, used_provider, used_model = _execute_second_brain(request, requested_provider=provider, requested_model=model)

    _save_brain_note(title=request, content=reply, provider=used_provider)

    # Format telemetry card for right-hand HUD content panel
    hud_card = f"""══════════════════════════════════════════════════════════════
               SECOND BRAIN DELIBERATION READOUT
══════════════════════════════════════════════════════════════
• PRIMARY BRAIN:   Gemini Live (Voice & Vision Core)
• SECONDARY BRAIN: {used_provider.upper()} [{used_model or 'Default'}]
• TASK TYPE:       {task.upper()}
• INQUIRY:         {request}

DELIBERATION ANALYSIS:
{reply}
══════════════════════════════════════════════════════════════"""

    if player and hasattr(player, "show_content"):
        try:
            player.show_content(f"SECOND BRAIN — {used_provider.upper()}", hud_card)
        except Exception:
            pass

    log(f"Second Brain ({used_provider}) response delivered.")
    return reply
